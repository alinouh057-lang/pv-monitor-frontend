// app/alerts/page.tsx
'use client';

/**
 * ============================================================
 * PAGE DE GESTION DES ALERTES - PV MONITOR
 * ============================================================
 * Cette page permet de :
 * - Visualiser les alertes actives et l'historique
 * - Filtrer par sévérité (critique, warning, info)
 * - Accuser réception et résoudre les alertes
 * - Voir les statistiques détaillées
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect, useMemo, useCallback } from 'react';
import { useAlerts } from '@/hooks/useAlerts';
import { useDevice } from '@/contexts/DeviceContext';
import { fmtDateTime, severityColor } from '@/lib/api';

// Imports Lucide - UNIQUEMENT les icônes utilisées
import { 
  AlertCircle, AlertTriangle, Info, Bell, Clock, Smartphone, 
  Activity, Check, RefreshCw, CheckCircle, BarChart3, 
  X, Loader, Filter, Calendar, Wrench, Zap, WifiOff,
  Thermometer, Database, Eye, EyeOff, ArrowUp, ArrowDown
} from 'lucide-react';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// CONSTANTES MÉTIER
// ============================================================

/**
 * Libellés des types d'alertes pour l'affichage
 */
const typeLabels: Record<string, string> = {
  soiling: 'Ensablement',
  power_drop: 'Baisse production',
  device_offline: 'Hors ligne',
  low_production: 'Faible production',
  high_temperature: 'Température élevée',
  communication_error: 'Erreur communication',
  system: 'Système',
};

/**
 * Icônes par type d'alerte
 */
const typeIcons: Record<string, React.ReactNode> = {
  soiling: <Wrench size={14} />,
  power_drop: <Zap size={14} />,
  device_offline: <WifiOff size={14} />,
  low_production: <Activity size={14} />,
  high_temperature: <Thermometer size={14} />,
  communication_error: <AlertCircle size={14} />,
  system: <Database size={14} />,
};

/**
 * Couleurs par sévérité
 */
const severityColors = {
  critical: { bg: C.redL, color: C.red, border: C.red, icon: AlertTriangle },
  warning: { bg: C.amberL, color: C.amber, border: C.amber, icon: AlertCircle },
  info: { bg: C.blueL, color: C.blue, border: C.blue, icon: Info },
};

// ============================================================
// COMPOSANTS INTERNES
// ============================================================

/**
 * Carte de statistique rapide
 */
const StatCard = ({ icon: Icon, label, value, color, bgColor }: { 
  icon: React.ElementType; label: string; value: string | number; color: string; bgColor: string;
}) => (
  <div style={{
    background: bgColor,
    border: `1px solid ${color}`,
    borderRadius: 10,
    padding: '12px',
    textAlign: 'center',
  }}>
    <Icon size={24} color={color} style={{ marginBottom: 4 }} />
    <div style={{ fontSize: 20, fontWeight: 700, color }}>{value}</div>
    <div style={{ fontSize: 10, color }}>{label}</div>
  </div>
);

/**
 * Badge de sévérité
 */
const SeverityBadge = ({ severity }: { severity: string }) => {
  const config = severityColors[severity as keyof typeof severityColors] || severityColors.info;
  const Icon = config.icon;
  return (
    <span style={{
      background: config.bg,
      color: config.color,
      padding: '4px 8px',
      borderRadius: 4,
      fontSize: 10,
      fontWeight: 600,
      textTransform: 'uppercase',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
    }}>
      <Icon size={10} />
      {severity === 'critical' ? 'Critique' : severity === 'warning' ? 'Warning' : 'Info'}
    </span>
  );
};

/**
 * Type badge
 */
const TypeBadge = ({ type }: { type: string }) => (
  <span style={{
    background: C.surface2,
    color: C.text2,
    padding: '4px 8px',
    borderRadius: 4,
    fontSize: 10,
    display: 'inline-flex',
    alignItems: 'center',
    gap: 4,
  }}>
    {typeIcons[type] || <Activity size={12} />}
    {typeLabels[type] || type}
  </span>
);
// ============================================================
// FONCTION DE FORMATAGE LOCAL POUR LES ALERTES
// ============================================================
// Version alternative : ajouter 1 heure
const formatLocalDateTime = (timestamp: string | undefined) => {
  if (!timestamp) return '-';
  try {
    let date = new Date(timestamp);
    if (isNaN(date.getTime())) return 'Date invalide';
    
    // Ajouter 1 heure si le timestamp est sans timezone
    if (!timestamp.includes('+') && !timestamp.includes('Z')) {
      date = new Date(date.getTime() + 60 * 60 * 1000);
    }
    
    return date.toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  } catch (e) {
    return 'Date invalide';
  }
};
// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function AlertsPage() {
  // ==========================================================
  // ÉTATS
  // ==========================================================
  const [activeTab, setActiveTab] = useState<'active' | 'history' | 'stats'>('active');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterDevice, setFilterDevice] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  const { selectedDevice } = useDevice();
  
  const {
    alerts,
    activeAlerts: rawActiveAlerts,
    criticalAlerts,
    warningAlerts,
    infoAlerts,
    resolvedAlerts,
    loading,
    unacknowledgedCount,
    criticalCount,
    alertsByType,
    alertsByDevice,
    averageResponseTime,
    refreshAlerts,
    markAsAcknowledged,
    markAsResolved,
    acknowledgeAll,
    resolveAll,
  } = useAlerts(selectedDevice || undefined, true, activeTab === 'history');
    // ⬇️⬇️⬇️ AJOUTEZ LE LOG ICI (juste après useAlerts) ⬇️⬇️⬇️
  useEffect(() => {
    console.log('🔍 DIAGNOSTIC DES ALERTES:');
    console.log('   Nombre total d\'alertes:', alerts.length);
    console.log('   Alertes actives:', rawActiveAlerts.length);
    console.log('   Alertes résolues:', resolvedAlerts.length);
    
    if (alerts.length > 0) {
      const firstAlert = alerts[0];
      console.log('🔍 PREMIÈRE ALERTE:');
      console.log('   ID:', firstAlert.id);
      console.log('   Timestamp brut:', firstAlert.timestamp);
      console.log('   Type de timestamp:', typeof firstAlert.timestamp);
      
      const date = new Date(firstAlert.timestamp);
      console.log('   new Date():', date);
      console.log('   toISOString():', date.toISOString());
      console.log('   toLocaleString():', date.toLocaleString('fr-FR'));
    }
    
    if (resolvedAlerts.length > 0) {
      const firstResolved = resolvedAlerts[0];
      console.log('🔍 PREMIÈRE ALERTE RÉSOLUE:');
      console.log('   Timestamp brut:', firstResolved.timestamp);
      console.log('   new Date():', new Date(firstResolved.timestamp));
      console.log('   toLocaleString():', new Date(firstResolved.timestamp).toLocaleString('fr-FR'));
    }
  }, [alerts, rawActiveAlerts, resolvedAlerts]);
  useEffect(() => {
  console.log("🔍 DIAGNOSTIC DES ALERTES OFFLINE:");
  console.log("   Alertes actives:", rawActiveAlerts.length);
  console.log("   Alertes offline dans actives:", rawActiveAlerts.filter(a => a.type === 'device_offline'));
  console.log("   Toutes les alertes:", alerts.length);
  console.log("   Alertes offline totales:", alerts.filter(a => a.type === 'device_offline'));
  console.log("   activeTab:", activeTab);
}, [rawActiveAlerts, alerts, activeTab]);
  // ⬆️⬆️⬆️ FIN DU LOG ⬆️⬆️⬆️
/*useEffect(() => {
  console.log("🔍 DIAGNOSTIC ALERTES:");
  console.log("   Active alerts:", rawActiveAlerts.length);
  console.log("   Resolved alerts:", resolvedAlerts.length);
  console.log("   Total alerts:", alerts.length);
  console.log("   Active tab:", activeTab);
}, [rawActiveAlerts, resolvedAlerts, alerts, activeTab]);*/

  // ==========================================================
  // DONNÉES FILTRÉES
  // ==========================================================
  
  const filteredAlerts = useMemo(() => {
    let result = activeTab === 'active' ? rawActiveAlerts : resolvedAlerts;
    
    if (filterSeverity !== 'all') {
      result = result.filter(a => a.severity === filterSeverity);
    }
    
    if (filterDevice !== 'all') {
      result = result.filter(a => a.device_id === filterDevice);
    }
    
    return result;
  }, [rawActiveAlerts, resolvedAlerts, activeTab, filterSeverity, filterDevice]);

  // Liste unique des devices pour le filtre
  const deviceList = useMemo(() => {
    const devices = new Set<string>();
    alerts.forEach(a => devices.add(a.device_id));
    return Array.from(devices).sort();
  }, [alerts]);

  // ==========================================================
  // AUTO-REFRESH
  // ==========================================================
  useEffect(() => {
    const interval = setInterval(refreshAlerts, 30000);
    return () => clearInterval(interval);
  }, [refreshAlerts]);

  // ==========================================================
  // GESTIONNAIRES
  // ==========================================================
  const handleAcknowledge = useCallback(async (alertId: string) => {
    await markAsAcknowledged(alertId);
  }, [markAsAcknowledged]);

  const handleResolve = useCallback(async (alertId: string) => {
    const notes = prompt('Notes de résolution (optionnel):');
    await markAsResolved(alertId, notes || undefined);
  }, [markAsResolved]);

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <div>
      {/* ==================================================== */}
      {/* EN-TÊTE */}
      {/* ==================================================== */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
        flexWrap: 'wrap',
        gap: 12,
      }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
          <AlertTriangle size={24} color={C.amber} />
          Gestion des alertes
          {unacknowledgedCount > 0 && (
            <span style={{
              background: C.red,
              color: 'white',
              padding: '2px 10px',
              borderRadius: 99,
              fontSize: 12,
            }}>
              {unacknowledgedCount} non lues
            </span>
          )}
        </h1>
        
        <div style={{ display: 'flex', gap: 8 }}>
          {/* Bouton filtres */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            style={{
              padding: '8px 12px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: showFilters ? C.green : C.surface,
              color: showFilters ? 'white' : C.text2,
              fontSize: 13,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <Filter size={14} />
            Filtres
            {(filterSeverity !== 'all' || filterDevice !== 'all') && (
              <span style={{
                background: C.green,
                color: 'white',
                width: 18,
                height: 18,
                borderRadius: 99,
                fontSize: 10,
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                {(filterSeverity !== 'all' ? 1 : 0) + (filterDevice !== 'all' ? 1 : 0)}
              </span>
            )}
          </button>
          
          {/* Rafraîchir */}
          <button
            onClick={refreshAlerts}
            disabled={loading}
            style={{
              padding: '8px 12px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: C.surface,
              color: C.text,
              fontSize: 13,
              cursor: loading ? 'wait' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            {loading ? <Loader size={14} className="spin" /> : <RefreshCw size={14} />}
            Rafraîchir
          </button>
        </div>
      </div>

      {/* ==================================================== */}
      {/* FILTRES (expandables) */}
      {/* ==================================================== */}
      {showFilters && (
        <div style={{
          background: C.surface2,
          borderRadius: 10,
          padding: 16,
          marginBottom: 20,
          display: 'flex',
          gap: 20,
          flexWrap: 'wrap',
          alignItems: 'flex-end',
        }}>
          {/* Filtre par sévérité */}
          <div style={{ flex: 1, minWidth: 150 }}>
            <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
              <AlertCircle size={12} style={{ marginRight: 4 }} />
              Sévérité
            </label>
            <select
              value={filterSeverity}
              onChange={(e) => setFilterSeverity(e.target.value)}
              style={{
                width: '100%',
                padding: '8px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: C.surface,
                fontSize: 12,
              }}
            >
              <option value="all">Toutes</option>
              <option value="critical">Critique</option>
              <option value="warning">Warning</option>
              <option value="info">Info</option>
            </select>
          </div>
          
          {/* Filtre par dispositif */}
          <div style={{ flex: 1, minWidth: 150 }}>
            <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
              <Smartphone size={12} style={{ marginRight: 4 }} />
              Dispositif
            </label>
            <select
              value={filterDevice}
              onChange={(e) => setFilterDevice(e.target.value)}
              style={{
                width: '100%',
                padding: '8px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: C.surface,
                fontSize: 12,
              }}
            >
              <option value="all">Tous</option>
              {deviceList.map(device => (
                <option key={device} value={device}>{device}</option>
              ))}
            </select>
          </div>
          
          {/* Réinitialiser filtres */}
          {(filterSeverity !== 'all' || filterDevice !== 'all') && (
            <button
              onClick={() => {
                setFilterSeverity('all');
                setFilterDevice('all');
              }}
              style={{
                padding: '8px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: C.surface,
                color: C.text2,
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              <X size={12} />
              Réinitialiser
            </button>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* STATISTIQUES RAPIDES (5 cartes) */}
      {/* ==================================================== */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(5, 1fr)',
        gap: 12,
        marginBottom: 20,
      }}>
        <StatCard icon={Bell} label="Alertes actives" value={rawActiveAlerts.length} color={C.text} bgColor={C.surface} />
        <StatCard icon={AlertTriangle} label="Critiques" value={criticalCount} color={C.red} bgColor={C.redL} />
        <StatCard icon={AlertCircle} label="Warnings" value={warningAlerts.length} color={C.amber} bgColor={C.amberL} />
        <StatCard icon={Info} label="Informations" value={infoAlerts.length} color={C.blue} bgColor={C.blueL} />
        <StatCard icon={Clock} label="Temps réponse" value={`${averageResponseTime} min`} color={C.purple} bgColor={C.surface2} />
      </div>

      {/* ==================================================== */}
      {/* ONGLETS */}
      {/* ==================================================== */}
      <div style={{
        display: 'flex',
        gap: 8,
        marginBottom: 20,
        borderBottom: `1px solid ${C.border}`,
        paddingBottom: 8,
        flexWrap: 'wrap',
      }}>
        <button
          onClick={() => setActiveTab('active')}
          style={{
            padding: '8px 16px',
            borderRadius: 8,
            border: 'none',
            background: activeTab === 'active' ? C.green : 'transparent',
            color: activeTab === 'active' ? 'white' : C.text2,
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          Alertes actives
          {rawActiveAlerts.length > 0 && (
            <span style={{
              background: activeTab === 'active' ? 'white' : C.surface2,
              color: activeTab === 'active' ? C.green : C.text3,
              padding: '2px 8px',
              borderRadius: 99,
              fontSize: 11,
            }}>
              {rawActiveAlerts.length}
            </span>
          )}
        </button>
        
        <button
          onClick={() => setActiveTab('history')}
          style={{
            padding: '8px 16px',
            borderRadius: 8,
            border: 'none',
            background: activeTab === 'history' ? C.green : 'transparent',
            color: activeTab === 'history' ? 'white' : C.text2,
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          Historique
          {resolvedAlerts.length > 0 && (
            <span style={{
              background: activeTab === 'history' ? 'white' : C.surface2,
              color: activeTab === 'history' ? C.green : C.text3,
              padding: '2px 8px',
              borderRadius: 99,
              fontSize: 11,
            }}>
              {resolvedAlerts.length}
            </span>
          )}
        </button>
        
        <button
          onClick={() => setActiveTab('stats')}
          style={{
            padding: '8px 16px',
            borderRadius: 8,
            border: 'none',
            background: activeTab === 'stats' ? C.green : 'transparent',
            color: activeTab === 'stats' ? 'white' : C.text2,
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          Statistiques
        </button>

        {/* Actions groupées (visible seulement dans l'onglet actif) */}
        {activeTab === 'active' && rawActiveAlerts.length > 0 && (
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <button
              onClick={acknowledgeAll}
              style={{
                padding: '6px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: C.surface,
                color: C.text,
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              <Check size={12} />
              Tout marquer lu
            </button>
            <button
              onClick={resolveAll}
              style={{
                padding: '6px 12px',
                borderRadius: 6,
                border: `1px solid ${C.red}`,
                background: C.redL,
                color: C.red,
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              <CheckCircle size={12} />
              Tout résoudre
            </button>
          </div>
        )}
      </div>

      {/* ==================================================== */}
      {/* CONTENU DES ONGLETS */}
      {/* ==================================================== */}

      {/* ONGLET ACTIVES */}
      {activeTab === 'active' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {loading && filteredAlerts.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 60, color: C.text3 }}>
              <Loader size={32} className="spin" />
              <div style={{ marginTop: 12 }}>Chargement des alertes...</div>
            </div>
          ) : filteredAlerts.length === 0 ? (
            <div style={{
              textAlign: 'center',
              padding: '60px 20px',
              background: C.surface2,
              borderRadius: 10,
              color: C.text3,
            }}>
              <CheckCircle size={48} color={C.green} style={{ marginBottom: 16 }} />
              <div style={{ fontSize: 16, fontWeight: 500 }}>Aucune alerte active</div>
              <div style={{ fontSize: 13, marginTop: 8 }}>Tout est en ordre !</div>
            </div>
          ) : (
  filteredAlerts.map((alert, idx) => {
    const severity = severityColors[alert.severity as keyof typeof severityColors] || severityColors.info;
    const SeverityIcon = severity.icon;
    return (
      <div
        key={`active-${alert.id}-${idx}`}  // ← CLÉ UNIQUE
        style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderLeft: `4px solid ${severity.color}`,
          borderRadius: 8,
          padding: '16px',
          opacity: alert.acknowledged ? 0.8 : 1,
          transition: 'all 0.2s',
        }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
                    <div style={{ display: 'flex', gap: 12, flex: 1 }}>
                      <div style={{ marginTop: 2 }}>
                        <SeverityIcon size={20} color={severity.color} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
                          <SeverityBadge severity={alert.severity} />
                          <TypeBadge type={alert.type} />
                          {!alert.acknowledged && (
                            <span style={{
                              background: C.amberL,
                              color: C.amber,
                              padding: '2px 8px',
                              borderRadius: 99,
                              fontSize: 10,
                              fontWeight: 600,
                            }}>
                              NON LU
                            </span>
                          )}
                        </div>
                        
                        <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>
                          {alert.title}
                        </div>
                        <div style={{ fontSize: 13, color: C.text2, marginBottom: 8 }}>
                          {alert.message}
                        </div>
                        
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, fontSize: 11, color: C.text3 }}>
                          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                            <Clock size={12} /> {formatLocalDateTime(alert.timestamp)}
                          </span>
                          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                            <Smartphone size={12} /> {alert.device_id}
                          </span>
                          {alert.value && alert.threshold && (
                            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                              <Activity size={12} /> {alert.value.toFixed(1)} / seuil {alert.threshold.toFixed(1)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div style={{ display: 'flex', gap: 8 }}>
                      {!alert.acknowledged && (
                        <button
                          onClick={() => handleAcknowledge(alert.id)}
                          style={{
                            padding: '6px 12px',
                            borderRadius: 6,
                            border: 'none',
                            background: C.blueL,
                            color: C.blue,
                            fontSize: 11,
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4,
                          }}
                        >
                          <Check size={12} />
                          Marquer lu
                        </button>
                      )}
                      <button
                        onClick={() => handleResolve(alert.id)}
                        style={{
                          padding: '6px 12px',
                          borderRadius: 6,
                          border: 'none',
                          background: C.greenL,
                          color: C.green,
                          fontSize: 11,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                        }}
                      >
                        <CheckCircle size={12} />
                        Résoudre
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ONGLET HISTORIQUE */}
      {activeTab === 'history' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {loading && filteredAlerts.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 60, color: C.text3 }}>
              <Loader size={32} className="spin" />
              <div style={{ marginTop: 12 }}>Chargement...</div>
            </div>
          ) : filteredAlerts.length === 0 ? (
            <div style={{
              textAlign: 'center',
              padding: '60px 20px',
              background: C.surface2,
              borderRadius: 10,
              color: C.text3,
            }}>
              <Info size={48} color={C.text3} style={{ marginBottom: 16 }} />
              <div style={{ fontSize: 16, fontWeight: 500 }}>Aucun historique</div>
            </div>
          ) : (
  filteredAlerts.map((alert, idx) => {
    const severity = severityColors[alert.severity as keyof typeof severityColors] || severityColors.info;
    const SeverityIcon = severity.icon;
    return (
      <div
        key={`history-${alert.id}-${idx}`}  // ← CLÉ UNIQUE
        style={{
          background: C.surface2,
          border: `1px solid ${C.border}`,
          borderRadius: 8,
          padding: '12px',
          opacity: 0.8,
        }}
                >
                  <div style={{ display: 'flex', gap: 12 }}>
                    <SeverityIcon size={16} color={severity.color} />
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
                        <SeverityBadge severity={alert.severity} />
                        <TypeBadge type={alert.type} />
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 2 }}>
                        {alert.title}
                      </div>
                      <div style={{ fontSize: 12, color: C.text2, marginBottom: 4 }}>
                        {alert.message}
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, fontSize: 10, color: C.text3 }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          <Clock size={10} /> {formatLocalDateTime(alert.timestamp)}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          <CheckCircle size={10} /> Résolue: {alert.resolved_at ? formatLocalDateTime(alert.resolved_at) : '-'}
                        </span>
                        {alert.resolution_notes && (
                          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                            <Info size={10} /> {alert.resolution_notes}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ONGLET STATISTIQUES */}
      {activeTab === 'stats' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          
          {/* Alertes par type */}
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 10,
            padding: 20,
          }}>
            <h2 style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
              <BarChart3 size={16} color={C.blue} />
              Alertes par type
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {Object.entries(alertsByType).map(([type, count]) => (
                <div key={type}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, color: C.text2, display: 'flex', alignItems: 'center', gap: 4 }}>
                      {typeIcons[type] || <Activity size={12} />}
                      {typeLabels[type as keyof typeof typeLabels] || type}
                    </span>
                    <span style={{ fontSize: 12, fontWeight: 600, color: C.text }}>{count}</span>
                  </div>
                  <div style={{ height: 6, background: C.surface2, borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{
                      height: '100%',
                      width: `${(count / Math.max(Object.values(alertsByType).reduce((a, b) => a + b, 0), 1)) * 100}%`,
                      background: C.blue,
                      borderRadius: 3,
                    }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Alertes par dispositif */}
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 10,
            padding: 20,
          }}>
            <h2 style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Smartphone size={16} color={C.green} />
              Alertes par dispositif
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {Object.entries(alertsByDevice).slice(0, 5).map(([deviceId, count]) => (
                <div key={deviceId}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, color: C.text2 }}>{deviceId}</span>
                    <span style={{ fontSize: 12, fontWeight: 600, color: C.text }}>{count}</span>
                  </div>
                  <div style={{ height: 6, background: C.surface2, borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{
                      height: '100%',
                      width: `${(count / Math.max(Object.values(alertsByDevice).reduce((a, b) => a + b, 0), 1)) * 100}%`,
                      background: C.green,
                      borderRadius: 3,
                    }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Métriques globales */}
          <div style={{
            gridColumn: 'span 2',
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 10,
            padding: 20,
          }}>
            <h2 style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Activity size={16} color={C.amber} />
              Métriques de performance
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 700, color: C.green }}>{averageResponseTime} min</div>
                <div style={{ fontSize: 11, color: C.text3 }}>Temps de réponse moyen</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 700, color: C.blue }}>{resolvedAlerts.length}</div>
                <div style={{ fontSize: 11, color: C.text3 }}>Alertes résolues</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 700, color: C.amber }}>
                  {alerts.length > 0 ? ((resolvedAlerts.length / alerts.length) * 100).toFixed(0) : 0}%
                </div>
                <div style={{ fontSize: 11, color: C.text3 }}>Taux de résolution</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}