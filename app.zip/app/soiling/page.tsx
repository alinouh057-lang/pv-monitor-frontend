// app/soiling/page.tsx
'use client';

/**
 * ============================================================
 * PAGE D'ANALYSE D'ENSABLEMENT - PV MONITOR
 * ============================================================
 * Cette page est dédiée à l'analyse détaillée de l'ensablement :
 * - Visualisation en temps réel du niveau d'ensablement
 * - Graphique d'évolution avec seuils (Clean, Warning, Critical)
 * - Statistiques avancées (moyenne, min, max, écart-type)
 * - Calculs économiques (pertes énergétiques, ROI nettoyage)
 * - Recommandations de nettoyage basées sur les seuils
 * - Prédictions sur 7 jours
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect, useCallback } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Area, AreaChart, BarChart, Bar,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  fetchLatest, fetchHistory, fetchStats,
  fmtTime, fmtDateTime, statusColor,getPanelConfig, statusBg,
  type Measurement, type Stats,
} from '@/lib/api';
import { useRefresh } from '@/contexts/RefreshContext';
import { useDevice } from '@/contexts/DeviceContext';

// Imports Lucide
import { 
  Droplets, TrendingUp, TrendingDown, Calendar, Clock,
  AlertTriangle, AlertCircle, CheckCircle, Info, RefreshCw,
  Camera, BarChart3, PieChart as PieChartIcon, Download,
  Sun, Cloud, DollarSign, Gauge, Target, Award
} from 'lucide-react';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// Mapping des couleurs pour les statuts
const COLORS = {
  Clean: C.green,
  Warning: C.amber,
  Critical: C.red,
};

// ============================================================
// COMPOSANTS UI RÉUTILISABLES
// ============================================================

/**
 * Carte KPI pour les métriques d'ensablement
 */
function KpiCard({ icon: Icon, label, value, unit, badge, accentColor, subtext }: {
  icon: React.ElementType; label: string; value: string; unit: string;
  badge: string; accentColor: string; subtext?: string;
}) {
  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`,
      borderRadius: 14, padding: '18px 20px',
      boxShadow: '0 1px 3px rgba(13,82,52,.06), 0 4px 16px rgba(13,82,52,.05)',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Barre de couleur en haut */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: accentColor, borderRadius: '14px 14px 0 0' }} />
      
      {/* En-tête avec badge */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ fontSize: 20 }}>
          <Icon size={24} color={accentColor} />
        </div>
        <span style={{
          padding: '3px 9px', borderRadius: 99, fontSize: 10.5, fontWeight: 600,
          background: `${accentColor}18`, color: accentColor,
        }}>{badge}</span>
      </div>
      
      {/* Valeur principale */}
      <div style={{ marginTop: 8 }}>
        <span style={{ fontFamily: 'Sora, sans-serif', fontSize: 26, fontWeight: 800, color: C.text, letterSpacing: '-.5px' }}>
          {value}
        </span>
        <span style={{ fontSize: 12, color: C.text3, marginLeft: 3 }}>{unit}</span>
      </div>
      
      {/* Label et sous-texte optionnel */}
      <div style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>{label}</div>
      {subtext && <div style={{ fontSize: 10, color: C.text3, marginTop: 6 }}>{subtext}</div>}
    </div>
  );
}

/**
 * Jauge d'ensablement avec indicateur visuel
 */
function SoilingGauge({ level, status, confidence }: { level: number; status: string; confidence?: number }) {
  const color = statusColor(status);
  const segments = [
    { label: 'Clean',    max: 30,  color: C.green },
    { label: 'Warning',  max: 60,  color: C.amber },
    { label: 'Critical', max: 100, color: C.red   },
  ];

  const getStatusIcon = () => {
    switch(status) {
      case 'Clean': return <CheckCircle size={14} />;
      case 'Warning': return <AlertCircle size={14} />;
      case 'Critical': return <AlertTriangle size={14} />;
      default: return <Info size={14} />;
    }
  };

  // Sécurisation des valeurs (évite NaN)
  const safeLevel = typeof level === 'number' && !isNaN(level) ? level : 0;
  const safeConfidence = typeof confidence === 'number' && !isNaN(confidence) ? confidence : 0;

  return (
    <div>
      {/* En-tête avec valeur et statut */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <span style={{ fontFamily: 'Sora, sans-serif', fontSize: 28, fontWeight: 800, color }}>
          {safeLevel.toFixed(1)}%
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {confidence && (
            <span style={{ fontSize: 11, color: C.text3 }}>
              Confiance: {(safeConfidence * 100).toFixed(0)}%
            </span>
          )}
          <span style={{
            padding: '4px 12px', borderRadius: 99, fontSize: 12, fontWeight: 700,
            background: statusBg(status), color,
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            {getStatusIcon()} {status}
          </span>
        </div>
      </div>
      
      {/* Barre de progression */}
      <div style={{ height: 10, borderRadius: 99, background: C.surface2, overflow: 'hidden', position: 'relative' }}>
        <div style={{
          height: '100%', width: `${safeLevel}%`,
          background: `linear-gradient(90deg, ${C.green}, ${color})`,
          borderRadius: 99, transition: 'width .8s ease',
        }} />
        
        {/* Marqueurs de seuil */}
        {segments.map(s => (
          <div key={s.label} style={{
            position: 'absolute', top: 0, left: `${s.max}%`,
            height: '100%', width: 1, background: C.border,
            transform: 'translateX(-50%)',
          }} />
        ))}
      </div>
      
      {/* Labels des seuils */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5 }}>
        {segments.map(s => (
          <span key={s.label} style={{ fontSize: 10, color: C.text3 }}>{s.label}</span>
        ))}
      </div>
    </div>
  );
}

/**
 * Sélecteur de période (7j, 30j, 3 mois)
 */
function TimeRangeSelector({ value, onChange }: { value: string; onChange: (range: string) => void }) {
  const ranges = [
    { id: '7d', label: '7 jours' },
    { id: '30d', label: '30 jours' },
    { id: '90d', label: '3 mois' },
  ];

  return (
    <div style={{ display: 'flex', gap: 4, background: C.surface2, borderRadius: 6, padding: 2 }}>
      {ranges.map(range => (
        <button
          key={range.id}
          onClick={() => onChange(range.id)}
          style={{
            padding: '4px 12px',
            borderRadius: 4,
            border: 'none',
            background: value === range.id ? C.green : 'transparent',
            color: value === range.id ? 'white' : C.text2,
            fontSize: 11,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          {range.label}
        </button>
      ))}
    </div>
  );
}

/**
 * Tooltip personnalisé pour les graphiques
 */
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10,
      padding: '12px 16px', fontSize: 12, boxShadow: '0 4px 16px rgba(13,82,52,.10)',
    }}>
      <div style={{ fontWeight: 700, color: C.text, marginBottom: 8 }}>{label}</div>
      {payload.map((p: any) => (
        <div key={p.name} style={{ 
          display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4,
          color: p.color 
        }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: p.color }} />
          <span style={{ flex: 1 }}>{p.name}:</span>
          <b>{p.value?.toFixed(1)}{p.unit}</b>
        </div>
      ))}
    </div>
  );
};

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function SoilingPage() {
  // ==========================================================
  // CONTEXTES ET HOOKS
  // ==========================================================
  const { autoRefresh, setLastUpdate, refreshKey } = useRefresh();
  const { selectedDevice } = useDevice();
  
  // ==========================================================
  // ÉTATS
  // ==========================================================
  const [latest, setLatest] = useState<Measurement | null>(null);
  const [historyData, setHistoryData] = useState<Measurement[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('30d');
  const [showComparison, setShowComparison] = useState(false);
  const [panelConfig, setPanelConfig] = useState({
  area: 1.6,
  efficiency: 0.20
});
  const REFRESH_INTERVAL = 60_000; // 1 minute

  // ==========================================================
  // CHARGEMENT DES DONNÉES
  // ==========================================================

  const load = useCallback(async () => {
    try {
      const [l, h, s] = await Promise.all([
        fetchLatest(),
        fetchHistory(0, 200),
        fetchStats()
      ]);
      
      setLatest(l);
      if (h && Array.isArray(h.data)) setHistoryData(h.data);
      if (s) setStats(s);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('❌ Erreur chargement:', error);
    } finally {
      setLoading(false);
    }
  }, [setLastUpdate]);

  // Chargement initial et auto-refresh
  useEffect(() => { 
    load();
    let interval: NodeJS.Timeout | null = null;
    if (autoRefresh) interval = setInterval(load, REFRESH_INTERVAL);
    return () => { if (interval) clearInterval(interval); };
  }, [load, autoRefresh]);

  // Rechargement manuel
  useEffect(() => {
    if (refreshKey > 0) load();
  }, [refreshKey, load]);


  // ==========================================================
// CHARGEMENT DE LA CONFIGURATION DES PANNEAUX
// ==========================================================
useEffect(() => {
  const loadPanelConfig = async () => {
    try {
      const config = await getPanelConfig();
      if (config) {
        setPanelConfig({
          area: config.panel_area_m2 ?? 1.6,
          efficiency: config.panel_efficiency ?? 0.20
        });
        console.log('📐 Config panneaux chargée (soiling):', config);
      }
    } catch (error) {
      console.error('❌ Erreur chargement config panneaux:', error);
    }
  };
  loadPanelConfig();
}, []);


  // ==========================================================
  // TRAITEMENT DES DONNÉES
  // ==========================================================

  // Affichage du loader pendant le chargement
  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh', flexDirection: 'column', gap: 12 }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', border: `3px solid ${C.greenL}`, borderTop: `3px solid ${C.green}`, animation: 'spin 1s linear infinite' }} />
      <span style={{ color: C.text3, fontSize: 13 }}>Chargement des données d'ensablement...</span>
    </div>
  );

  // Valeurs par défaut sécurisées (évite les undefined)
  const ai = latest?.ai_analysis ?? { 
    soiling_level: 0, 
    status: 'Clean', 
    confidence: 0 
  };
  
  const ed = latest?.electrical_data ?? { 
    power_output: 0, 
    irradiance: 0 

  };

  // ==========================================================
  // CALCULS AVANCÉS
  // ==========================================================

  // Puissance théorique et ratio d'ensablement
  const pth = (ed.irradiance || 0) * panelConfig.area * panelConfig.efficiency;

  const soilingRatio = pth > 0 ? ((pth - (ed.power_output || 0)) / pth) * 100 : 0;
  
  // Pertes énergétiques
  const energyLostToday = ((ai.soiling_level || 0) / 100) * pth * 24 / 1000; // kWh perdus aujourd'hui
  
  // Paramètres économiques
  const cleaningCost = 50; // Coût estimé du nettoyage (DT)
  const energyPrice = 0.20; // Prix du kWh (DT)
  
  // Calcul sécurisé du ROI (Retour sur Investissement)
  const annualLoss = (energyLostToday * 365 * energyPrice) || 0;
  const roiValue = (annualLoss - cleaningCost).toFixed(2);
  const roiNum = parseFloat(roiValue);

  // ==========================================================
  // PRÉPARATION DES DONNÉES POUR LES GRAPHIQUES
  // ==========================================================

  // Données pour le graphique d'évolution
  const chartData = historyData
    .filter(d => d && d.timestamp)
    .map(d => ({
      time: fmtTime(d.timestamp),
      soiling: d.ai_analysis?.soiling_level || 0,
      date: new Date(d.timestamp).toLocaleDateString('fr-FR'),
      confidence: d.ai_analysis?.confidence || 0,
    }))
    .reverse();

  // Statistiques par statut pour le camembert
  const statusCounts = historyData.reduce((acc, d) => {
    const status = d.ai_analysis?.status || 'Unknown';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));

  // Statistiques sécurisées
  const avgSoiling = stats?.averages?.avg_soiling || 0;
  
  const soilingValues = historyData.map(d => d.ai_analysis?.soiling_level || 0);
  const minSoiling = soilingValues.length > 0 ? Math.min(...soilingValues) : 0;
  const maxSoiling = soilingValues.length > 0 ? Math.max(...soilingValues) : 0;
  
  // Calcul de l'écart-type sécurisé
  const variance = soilingValues.length > 0 
    ? soilingValues.reduce((acc, val) => acc + Math.pow(val - avgSoiling, 2), 0) / soilingValues.length 
    : 0;
  const stdDev = Math.sqrt(variance).toFixed(1);

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <div>
      {/* ==================================================== */}
      {/* EN-TÊTE DE LA PAGE */}
      {/* ==================================================== */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Droplets size={24} color={C.amber} />
            Analyse d'Ensablement
          </h1>
          {latest && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: C.surface2, padding: '4px 10px',
              borderRadius: 99, fontSize: 11, color: C.text2,
            }}>
              <Clock size={12} />
              Dernière mesure: {latest?.timestamp ? fmtDateTime(latest.timestamp) : ''}
            </div>
          )}
        </div>
        <TimeRangeSelector value={timeRange} onChange={setTimeRange} />
      </div>

      {/* ==================================================== */}
      {/* KPIS - CARTES DE MÉTRIQUES (4 CARTES) */}
      {/* ==================================================== */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 20 }}>
        
        {/* Carte 1 : Ensablement actuel */}
        <KpiCard icon={Droplets} label="ENSABLEMENT ACTUEL"
          value={ai.soiling_level?.toFixed(1) || '0'} unit="%"
          badge={ai.status || 'Clean'} accentColor={statusColor(ai.status || 'Clean')}
          subtext={`Confiance: ${((ai.confidence || 0) * 100).toFixed(0)}%`} />
        
        {/* Carte 2 : Soiling Ratio (perte par rapport à la théorie) */}
        <KpiCard icon={Target} label="SOILING RATIO"
          value={soilingRatio.toFixed(1)} unit="%"
          badge="Perte" accentColor={soilingRatio > 20 ? C.red : C.amber}
          subtext="Par rapport à la théorie" />
        
        {/* Carte 3 : Perte énergétique */}
        <KpiCard icon={DollarSign} label="PERTE ÉNERGÉTIQUE"
          value={energyLostToday.toFixed(2)} unit="kWh/jour"
          badge="Estimée" accentColor={C.purple}
          subtext={`Soit ${(energyLostToday * energyPrice).toFixed(2)} DT/jour`} />
        
        {/* Carte 4 : ROI Nettoyage */}
        <KpiCard icon={Award} label="ROI NETTOYAGE"
          value={roiValue} unit="DT/an"
          badge={roiNum > 0 ? 'Rentable' : 'Non rentable'}
          accentColor={roiNum > 0 ? C.green : C.red}
          subtext="Basé sur pertes annuelles estimées" />
      </div>

      {/* ==================================================== */}
      {/* GRAPHIQUE PRINCIPAL : ÉVOLUTION DE L'ENSABLEMENT */}
      {/* ==================================================== */}
      <div style={{
        background: C.surface,
        border: `1px solid ${C.border}`,
        borderRadius: 14,
        padding: 20,
        marginBottom: 20,
      }}>
        {/* En-tête du graphique avec contrôles */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.amber }} />
            <TrendingUp size={14} /> ÉVOLUTION DE L'ENSABLEMENT
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {/* Bouton pour afficher/masquer la confiance */}
            <button
              onClick={() => setShowComparison(!showComparison)}
              style={{
                padding: '4px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: showComparison ? C.greenL : 'transparent',
                color: showComparison ? C.green : C.text2,
                fontSize: 11,
                cursor: 'pointer',
              }}
            >
              Afficher confiance
            </button>
            {/* Bouton de rafraîchissement */}
            <button
              onClick={load}
              style={{
                padding: '4px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: 'transparent',
                color: C.text2,
                fontSize: 11,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              <RefreshCw size={12} />
              Rafraîchir
            </button>
          </div>
        </div>

        {/* Graphique */}
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
            <defs>
              <linearGradient id="colorSoiling" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={C.amber} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={C.amber} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
            <XAxis 
              dataKey="time" 
              stroke={C.text3} 
              tick={{ fontSize: 10 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              yAxisId="left"
              stroke={C.text3} 
              tick={{ fontSize: 10 }} 
              unit="%"
              domain={[0, 100]}
            />
            {showComparison && (
              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke={C.blue} 
                tick={{ fontSize: 10 }} 
                unit="%"
                domain={[0, 100]}
              />
            )}
            <Tooltip content={<CustomTooltip />} />
            <Area 
              yAxisId="left"
              type="monotone" 
              dataKey="soiling" 
              stroke={C.amber} 
              strokeWidth={2.5}
              fill="url(#colorSoiling)" 
              name="Ensablement" 
              unit="%" 
            />
            {showComparison && (
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="confidence" 
                stroke={C.blue} 
                strokeWidth={1.5}
                strokeDasharray="5 5"
                name="Confiance" 
                unit="%" 
                dot={false}
              />
            )}
          </AreaChart>
        </ResponsiveContainer>

        {/* Légende des seuils */}
        <div style={{ display: 'flex', gap: 16, marginTop: 12, justifyContent: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 12, height: 12, borderRadius: 4, background: C.green }} />
            <span style={{ fontSize: 11, color: C.text2 }}>Clean (&lt;30%)</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 12, height: 12, borderRadius: 4, background: C.amber }} />
            <span style={{ fontSize: 11, color: C.text2 }}>Warning (30-60%)</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 12, height: 12, borderRadius: 4, background: C.red }} />
            <span style={{ fontSize: 11, color: C.text2 }}>Critical (&gt;60%)</span>
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* STATISTIQUES AVANCÉES (2 COLONNES) */}
      {/* ==================================================== */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
        
        {/* ================================================ */}
        {/* COLONNE 1 : DISTRIBUTION PAR STATUT (CAMEMBERT) */}
        {/* ================================================ */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 14,
          padding: 20,
        }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.blue }} />
            <PieChartIcon size={14} /> DISTRIBUTION PAR STATUT
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            {/* Camembert */}
            <ResponsiveContainer width="60%" height={200}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[entry.name as keyof typeof COLORS] || C.text3} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            
            {/* Légende détaillée */}
            <div style={{ width: '35%' }}>
              {pieData.map((item, index) => (
                <div key={item.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: COLORS[item.name as keyof typeof COLORS] || C.text3 }} />
                    <span style={{ fontSize: 12, color: C.text2 }}>{item.name}</span>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 600, color: C.text }}>{item.value}</span>
                </div>
              ))}
              <div style={{ marginTop: 12, paddingTop: 8, borderTop: `1px solid ${C.border}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 11, color: C.text3 }}>Total mesures</span>
                  <span style={{ fontSize: 12, fontWeight: 600, color: C.text }}>{historyData.length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ================================================ */}
        {/* COLONNE 2 : STATISTIQUES QUOTIDIENNES */}
        {/* ================================================ */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 14,
          padding: 20,
        }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
            <BarChart3 size={14} /> STATISTIQUES QUOTIDIENNES
          </div>

          {/* Grille de 4 indicateurs */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
            {/* Moyenne */}
            <div style={{ background: C.surface2, borderRadius: 10, padding: 12 }}>
              <div style={{ fontSize: 11, color: C.text3, marginBottom: 4 }}>Moyenne</div>
              <div style={{ fontFamily: 'Sora', fontSize: 22, fontWeight: 700, color: C.text }}>
                {avgSoiling.toFixed(1)}<span style={{ fontSize: 12, color: C.text3, marginLeft: 2 }}>%</span>
              </div>
            </div>
            {/* Minimum */}
            <div style={{ background: C.surface2, borderRadius: 10, padding: 12 }}>
              <div style={{ fontSize: 11, color: C.text3, marginBottom: 4 }}>Minimum</div>
              <div style={{ fontFamily: 'Sora', fontSize: 22, fontWeight: 700, color: C.green }}>
                {minSoiling.toFixed(1)}<span style={{ fontSize: 12, color: C.text3, marginLeft: 2 }}>%</span>
              </div>
            </div>
            {/* Maximum */}
            <div style={{ background: C.surface2, borderRadius: 10, padding: 12 }}>
              <div style={{ fontSize: 11, color: C.text3, marginBottom: 4 }}>Maximum</div>
              <div style={{ fontFamily: 'Sora', fontSize: 22, fontWeight: 700, color: C.red }}>
                {maxSoiling.toFixed(1)}<span style={{ fontSize: 12, color: C.text3, marginLeft: 2 }}>%</span>
              </div>
            </div>
            {/* Écart-type */}
            <div style={{ background: C.surface2, borderRadius: 10, padding: 12 }}>
              <div style={{ fontSize: 11, color: C.text3, marginBottom: 4 }}>Écart-type</div>
              <div style={{ fontFamily: 'Sora', fontSize: 22, fontWeight: 700, color: C.amber }}>
                {stdDev}<span style={{ fontSize: 12, color: C.text3, marginLeft: 2 }}>%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* RECOMMANDATIONS DE NETTOYAGE (3 COLONNES) */}
      {/* ==================================================== */}
      <div style={{
        background: C.surface,
        border: `1px solid ${C.border}`,
        borderRadius: 14,
        padding: 20,
      }}>
        <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.purple }} />
          <AlertTriangle size={14} /> RECOMMANDATIONS DE NETTOYAGE
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          
          {/* ================================================ */}
          {/* COLONNE 1 : STATUT ACTUEL ET RECOMMANDATION */}
          {/* ================================================ */}
          <div style={{
            background: ai.soiling_level >= 60 ? C.redL : C.surface2,
            borderRadius: 10,
            padding: 16,
            borderLeft: `4px solid ${ai.soiling_level >= 60 ? C.red : 'transparent'}`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              {ai.soiling_level >= 60 ? <AlertTriangle size={20} color={C.red} /> : <CheckCircle size={20} color={C.green} />}
              <span style={{ fontWeight: 700, color: ai.soiling_level >= 60 ? C.red : C.green }}>
                {ai.soiling_level >= 60 ? 'Nettoyage urgent' : ai.soiling_level >= 30 ? 'Surveillance requise' : 'Panneau propre'}
              </span>
            </div>
            <p style={{ fontSize: 12, color: C.text2, marginBottom: 8 }}>
              {ai.soiling_level >= 60 
                ? `Ensablement critique (${ai.soiling_level.toFixed(1)}%). Nettoyage recommandé dans les 24h.`
                : ai.soiling_level >= 30
                ? `Ensablement modéré (${ai.soiling_level.toFixed(1)}%). Planifier un nettoyage dans la semaine.`
                : `Ensablement faible (${ai.soiling_level.toFixed(1)}%). Aucune action requise.`}
            </p>
            <div style={{ fontSize: 11, color: C.text3 }}>
              Perte estimée: {((ai.soiling_level / 100) * pth * 24 / 1000).toFixed(2)} kWh/jour
            </div>
          </div>

          {/* ================================================ */}
          {/* COLONNE 2 : PRÉDICTION 7 JOURS */}
          {/* ================================================ */}
          <div style={{ background: C.surface2, borderRadius: 10, padding: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <Calendar size={20} color={C.blue} />
              <span style={{ fontWeight: 700, color: C.text }}>Prédiction 7 jours</span>
            </div>
            <div style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: C.text2 }}>Ensablement estimé</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: C.amber }}>
                  {((ai.soiling_level || 0) * 1.1).toFixed(1)}%
                </span>
              </div>
              {/* Barre de progression prédictive */}
              <div style={{ height: 4, background: C.border, borderRadius: 2 }}>
                <div style={{
                  width: `${Math.min((ai.soiling_level || 0) * 1.1, 100)}%`,
                  height: '100%',
                  background: `linear-gradient(90deg, ${C.green}, ${C.amber})`,
                  borderRadius: 2,
                }} />
              </div>
            </div>
            <p style={{ fontSize: 11, color: C.text3 }}>
              ↗️ Tendance haussière due à l'absence de pluie prévue
            </p>
          </div>

          {/* ================================================ */}
          {/* COLONNE 3 : IMPACT ÉCONOMIQUE */}
          {/* ================================================ */}
          <div style={{ background: C.surface2, borderRadius: 10, padding: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <Sun size={20} color={C.amber} />
              <span style={{ fontWeight: 700, color: C.text }}>Impact économique</span>
            </div>
            <div style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: C.text2 }}>Coût nettoyage</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: C.text }}>50 DT</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: C.text2 }}>Gain annuel estimé</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: C.green }}>{roiValue} DT</span>
              </div>
            </div>
            <p style={{ fontSize: 11, color: C.text3 }}>
              ROI: {roiNum > 0 ? 'Rentable' : 'Non rentable'} sur 1 an
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}