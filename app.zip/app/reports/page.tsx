// frontend/app/reports/page.tsx
'use client';

/**
 * ============================================================
 * PAGE DES RAPPORTS ET ANALYSES - PV MONITOR
 * ============================================================
 * Cette page génère des rapports détaillés sur les performances :
 * - KPIs globaux (total mesures, puissance moyenne, etc.)
 * - Graphiques d'évolution de l'ensablement
 * - Répartition par statut (Clean/Warning/Critical)
 * - Export des données (CSV/Excel)
 * - Tableau des dernières mesures
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect } from 'react';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend 
} from 'recharts';
import { fetchHistory, fetchStats, fmtDateTime, type Stats } from '@/lib/api';
import ExportButtons from '@/components/ExportButtons';
import { Calendar, Download, FileText, BarChart3, PieChart as PieChartIcon } from 'lucide-react';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// FONCTIONS UTILITAIRES DE DATE
// ============================================================

/**
 * Parse les dates MongoDB (qui peuvent avoir différents formats)
 * Gère :
 * - Objets Date JavaScript
 * - Objets MongoDB { $date: "..." }
 * - Timestamps (secondes ou millisecondes)
 * - Chaînes ISO
 * - Format français "JJ/MM/AAAA HH:MM"
 * 
 * @param dateValue - La valeur de date à parser (peut être de plusieurs types)
 * @returns Un objet Date valide ou null si parsing échoue
 */
function parseDate(dateValue: any): Date | null {
  if (!dateValue) return null;
  
  // Si c'est déjà un objet Date
  if (dateValue instanceof Date) {
    return isNaN(dateValue.getTime()) ? null : dateValue;
  }
  
  // Si c'est un objet MongoDB { $date: "..." }
  if (typeof dateValue === 'object' && dateValue !== null) {
    if (dateValue.$date) {
      return parseDate(dateValue.$date);
    }
  }
  
  // Si c'est un nombre (timestamp)
  if (typeof dateValue === 'number') {
    // Si le nombre est > 10^10, c'est probablement en millisecondes
    if (dateValue > 10000000000) {
      return new Date(dateValue);
    } else {
      // Sinon c'est en secondes
      return new Date(dateValue * 1000);
    }
  }
  
  // Si c'est une chaîne ISO
  if (typeof dateValue === 'string') {
    const trimmed = dateValue.trim();
    if (trimmed === '') return null;
    
    // Essayer le format ISO standard
    let date = new Date(trimmed);
    if (!isNaN(date.getTime())) return date;
    
    // Essayer avec remplacement de l'espace par T (format "YYYY-MM-DD HH:MM")
    date = new Date(trimmed.replace(' ', 'T'));
    if (!isNaN(date.getTime())) return date;
    
    // Essayer le format français "JJ/MM/AAAA HH:MM"
    const frenchMatch = trimmed.match(/^(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})$/);
    if (frenchMatch) {
      const [_, day, month, year, hour, minute] = frenchMatch;
      return new Date(Date.UTC(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hour),
        parseInt(minute)
      ));
    }
    
    console.warn('⚠️ Format de date non reconnu:', dateValue);
    return null;
  }
  
  return null;
}

/**
 * Formate une date MongoDB en chaîne lisible (JJ/MM/AAAA HH:MM)
 * 
 * @param dateValue - La valeur de date à formater
 * @returns Une chaîne formatée ou 'Date invalide' si parsing échoue
 */
function formatDate(dateValue: any): string {
  const date = parseDate(dateValue);
  if (!date) return 'Date invalide';
  
  return date.toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function ReportsPage() {
  // ==========================================================
  // ÉTATS
  // ==========================================================
  const [stats, setStats] = useState<Stats | null>(null);        // Statistiques globales
  const [history, setHistory] = useState<any[]>([]);             // Historique des mesures
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d'); // Période sélectionnée
  const [loading, setLoading] = useState(true);                   // État de chargement

  // ==========================================================
  // CHARGEMENT DES DONNÉES
  // ==========================================================

  /**
   * Charge les données depuis l'API
   * Récupère à la fois les statistiques et l'historique
   */
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [h, s] = await Promise.all([
        fetchHistory(0, 300),  // Récupère les 200 dernières mesures
        fetchStats()
      ]);
      
      if (h?.data) setHistory(h.data);
      if (s) setStats(s);
    } catch (error) {
      console.error('❌ Erreur chargement rapports:', error);
    }
    setLoading(false);
  };

  // ==========================================================
  // PRÉPARATION DES DONNÉES
  // ==========================================================

  /**
   * Prépare les données pour l'export CSV/Excel
   * Applique le formatage correct des dates
   */
  const exportData = {
    headers: ['Date', 'Device', 'Statut', 'Ensablement (%)', 'Puissance (W)', 'Tension (V)', 'Courant (A)'],
    rows: history.map(d => [
      formatDate(d.timestamp),  // ← Utilisation de la fonction formatDate pour des dates correctes
      d.device_id,
      d.ai_analysis?.status || 'Inconnu',
      d.ai_analysis?.soiling_level?.toFixed(1) || '0',
      d.electrical_data?.power_output?.toFixed(1) || '0',
      d.electrical_data?.voltage?.toFixed(1) || '0',
      d.electrical_data?.current?.toFixed(2) || '0'
    ])
  };

  /**
   * Données pour le graphique en camembert (répartition par statut)
   */
  const pieData = stats ? [
    { name: 'Clean', value: stats.distribution?.Clean || 0, color: C.green },
    { name: 'Warning', value: stats.distribution?.Warning || 0, color: C.amber },
    { name: 'Critical', value: stats.distribution?.Critical || 0, color: C.red },
  ] : [];

  /**
   * Données pour le graphique d'évolution
   * Prend les 30 derniers jours et formate les dates
   */
  const chartData = (stats?.daily || [])
    .map(d => ({
      day: d.day ? new Date(d.day).toLocaleDateString('fr-FR', { 
        day: '2-digit', 
        month: '2-digit' 
      }) : '--/--',
      count: d.count || 0,
      soiling: d.avg_soiling || 0,
      power: d.avg_power || 0,
    }))
    .slice(-30); // Garde seulement les 30 derniers jours

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================

  // Affichage du loader pendant le chargement
  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}>
        <div style={{ 
          width: 40, 
          height: 40, 
          borderRadius: '50%', 
          border: '3px solid var(--green-l)', 
          borderTopColor: 'var(--green)', 
          animation: 'spin 1s linear infinite' 
        }} />
      </div>
    );
  }

  return (
    <div>
      {/* ==================================================== */}
      {/* EN-TÊTE DE LA PAGE */}
      {/* ==================================================== */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
          <FileText size={24} color={C.green} />
          Rapports & Analyses
        </h1>

        <div style={{ display: 'flex', gap: 12 }}>
          {/* Sélecteur de période */}
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value as any)}
            style={{
              padding: '8px 12px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: 'var(--surface)',
              color: C.text,
              fontSize: 13,
            }}
          >
            <option value="7d">7 derniers jours</option>
            <option value="30d">30 derniers jours</option>
            <option value="90d">3 derniers mois</option>
          </select>

        
      
        </div>
      </div>

      {/* ==================================================== */}
      {/* KPIS - CARTES DE STATISTIQUES */}
      {/* ==================================================== */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 20 }}>
        
        {/* Carte : Total mesures */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <div style={{ fontSize: 12, color: C.text2, marginBottom: 4 }}>Total mesures</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: C.text }}>{stats?.total || 0}</div>
        </div>

        {/* Carte : Puissance moyenne */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <div style={{ fontSize: 12, color: C.text2, marginBottom: 4 }}>Puissance moyenne</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: C.text }}>
            {stats?.averages?.avg_power?.toFixed(0) || 0} <span style={{ fontSize: 14, color: C.text2 }}>W</span>
          </div>
        </div>

        {/* Carte : Ensablement moyen */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <div style={{ fontSize: 12, color: C.text2, marginBottom: 4 }}>Ensablement moyen</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: C.text }}>
            {stats?.averages?.avg_soiling?.toFixed(1) || 0} <span style={{ fontSize: 14, color: C.text2 }}>%</span>
          </div>
        </div>

        {/* Carte : Taux de propreté */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <div style={{ fontSize: 12, color: C.text2, marginBottom: 4 }}>Taux de propreté</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: C.text }}>
            {(((stats?.distribution?.Clean || 0) / (stats?.total || 1)) * 100).toFixed(0)}%
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* GRAPHIQUES (2 colonnes) */}
      {/* ==================================================== */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20, marginBottom: 20 }}>
        
        {/* ================================================ */}
        {/* GRAPHIQUE : ÉVOLUTION DE L'ENSABLEMENT */}
        {/* ================================================ */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2 style={{ fontSize: 14, fontWeight: 600, color: C.text, display: 'flex', alignItems: 'center', gap: 6 }}>
              <BarChart3 size={16} color={C.blue} />
              Évolution de l'ensablement
            </h2>
            {/* Boutons d'export spécifiques au graphique */}

          </div>
          <div id="soiling-chart" style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis dataKey="day" stroke={C.text2} />
                <YAxis stroke={C.text2} unit="%" />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="soiling" stroke={C.amber} name="Ensablement" unit="%" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ================================================ */}
        {/* GRAPHIQUE : RÉPARTITION PAR STATUT (CAMEMBERT) */}
        {/* ================================================ */}
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <h2 style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
            <PieChartIcon size={16} color={C.purple} />
            Répartition par statut
          </h2>
          <div style={{ width: '100%', height: 250 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* Légende détaillée avec les valeurs */}
          <div style={{ marginTop: 16 }}>
            {pieData.map(item => (
              <div key={item.name} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: 12, color: C.text2 }}>{item.name}</span>
                <span style={{ fontSize: 12, fontWeight: 600, color: item.color }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* TABLEAU DES DERNIÈRES MESURES */}
      {/* ==================================================== */}
      <div style={{
        background: C.surface,
        border: `1px solid ${C.border}`,
        borderRadius: 10,
        padding: 20,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ fontSize: 14, fontWeight: 600, color: C.text }}>Dernières mesures</h2>
          <ExportButtons 
            data={exportData}
            filename="dernieres_mesures"
          />
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%' }}>
            <thead>
              <tr>
                {exportData.headers.map(h => (
                  <th key={h}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {/* Affiche seulement les 10 premières lignes */}
              {exportData.rows.slice(0, 10).map((row, i) => (
                <tr key={i}>
                  {row.map((cell, j) => (
                    <td key={j}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}