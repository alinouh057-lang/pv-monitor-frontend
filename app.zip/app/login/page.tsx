// frontend/app/login/page.tsx
'use client';

/**
 * ============================================================
 * PAGE DE CONNEXION - PV MONITOR
 * ============================================================
 * Cette page permet aux utilisateurs de s'authentifier :
 * - Formulaire de connexion (email + mot de passe)
 * - Option "Se souvenir de moi"
 * - Gestion des erreurs de connexion
 * - Redirection après connexion réussie
 * - Lien vers mot de passe oublié et inscription
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  Mail, Lock, LogIn, AlertCircle, CheckCircle, 
  Eye, EyeOff, Loader, Sun
} from 'lucide-react';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function LoginPage() {
  // ==========================================================
  // ÉTATS LOCAUX
  // ==========================================================
  const [email, setEmail] = useState('');                 // Email saisi
  const [password, setPassword] = useState('');           // Mot de passe saisi
  const [showPassword, setShowPassword] = useState(false); // Afficher/masquer mot de passe
  const [rememberMe, setRememberMe] = useState(false);     // Option "Se souvenir de moi"
  const [localError, setLocalError] = useState('');        // Erreur de validation locale
  const [success, setSuccess] = useState(false);           // État de succès (connexion réussie)
  const [redirectCountdown, setRedirectCountdown] = useState(3); // Compte à rebours avant redirection

  // ==========================================================
  // CONTEXTES ET HOOKS
  // ==========================================================
  const { login, loading, error, user } = useAuth();      // Hook d'authentification
  const router = useRouter();                               // Router Next.js pour navigation

  // ==========================================================
  // EFFETS DE BORD
  // ==========================================================

  /**
   * Redirige automatiquement vers le dashboard si l'utilisateur est déjà connecté
   */
useEffect(() => {
  if (user) {
    router.push('/');  // préserve l'état React
  }
}, [user, router]);

  /**
   * Gère le compte à rebours avant redirection après connexion réussie
   */
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (success) {
      if (redirectCountdown > 0) {
        timer = setTimeout(() => {
          setRedirectCountdown(redirectCountdown - 1);
        }, 1000);
      } else {
        router.push('/');
      }
    }
    
    return () => clearTimeout(timer);
  }, [success, redirectCountdown]);

  // ==========================================================
  // GESTION DE LA SOUMISSION DU FORMULAIRE
  // ==========================================================

  /**
   * Traite la soumission du formulaire de connexion
   * - Valide les champs
   * - Appelle la fonction login du contexte
   * - Gère le succès ou l'échec
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');
    
    // Validation des champs
    if (!email || !password) {
      setLocalError('Veuillez remplir tous les champs');
      return;
    }
    
    // Tentative de connexion
    const loginSuccess = await login(email, password);
    
    if (loginSuccess) {
      setSuccess(true);
      setRedirectCountdown(3);
    }
  };

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: `linear-gradient(135deg, ${C.green}10 0%, ${C.surface2} 100%)`,
      padding: '20px',
    }}>
      <div style={{
        maxWidth: 400,
        width: '100%',
      }}>
        
        {/* ================================================== */}
        {/* LOGO ET TITRE */}
        {/* ================================================== */}
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <div style={{
            width: 70,
            height: 70,
            background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
            borderRadius: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 15px',
            boxShadow: `0 10px 20px ${C.green}30`,
          }}>
            <Sun size={40} color="white" />
          </div>
          <h1 style={{
            fontSize: 28,
            fontWeight: 700,
            color: C.text,
            marginBottom: 5,
          }}>
            PV Monitor
          </h1>
          <p style={{
            fontSize: 14,
            color: C.text2,
          }}>
            Surveillance intelligente de panneaux solaires
          </p>
        </div>

        {/* ================================================== */}
        {/* CARTE DE CONNEXION */}
        {/* ================================================== */}
        <div style={{
          background: C.surface,
          borderRadius: 20,
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
          overflow: 'hidden',
          border: `1px solid ${C.border}`,
        }}>
          <div style={{ padding: 30 }}>
            
            {/* ============================================== */}
            {/* MESSAGES D'INFORMATION */}
            {/* ============================================== */}
            
            {/* Message de succès après connexion */}
            {success && (
              <div style={{
                marginBottom: 20,
                padding: '12px 16px',
                borderRadius: 8,
                background: C.greenL,
                color: C.green,
                fontSize: 13,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 8,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <CheckCircle size={16} />
                  Connexion réussie !
                </div>
                <span style={{
                  background: C.green,
                  color: 'white',
                  padding: '2px 8px',
                  borderRadius: 99,
                  fontSize: 12,
                  fontWeight: 600,
                }}>
                  {redirectCountdown}s
                </span>
              </div>
            )}

            {/* Message d'erreur (local ou du contexte) */}
            {(localError || error) && (
              <div style={{
                marginBottom: 20,
                padding: '12px 16px',
                borderRadius: 8,
                background: C.redL,
                color: C.red,
                fontSize: 13,
                display: 'flex',
                alignItems: 'center',
                gap: 8,
              }}>
                <AlertCircle size={16} />
                {localError || error || 'Identifiants invalides. Vérifiez votre email et mot de passe.'}
              </div>
            )}

            {/* ============================================== */}
            {/* FORMULAIRE DE CONNEXION */}
            {/* ============================================== */}
            <form onSubmit={handleSubmit}>
              
              {/* Champ EMAIL */}
              <div style={{ marginBottom: 20 }}>
                <label style={{
                  fontSize: 12,
                  color: C.text3,
                  display: 'block',
                  marginBottom: 6,
                }}>
                  Email
                </label>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '12px 14px',
                  background: C.surface2,
                  borderRadius: 10,
                  border: `1px solid ${C.border}`,
                }}>
                  <Mail size={18} color={C.text3} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="exemple@email.com"
                    disabled={success}
                    style={{
                      flex: 1,
                      border: 'none',
                      background: 'transparent',
                      outline: 'none',
                      fontSize: 14,
                      color: C.text,
                    }}
                  />
                </div>
              </div>

              {/* Champ MOT DE PASSE */}
              <div style={{ marginBottom: 20 }}>
                <label style={{
                  fontSize: 12,
                  color: C.text3,
                  display: 'block',
                  marginBottom: 6,
                }}>
                  Mot de passe
                </label>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '12px 14px',
                  background: C.surface2,
                  borderRadius: 10,
                  border: `1px solid ${C.border}`,
                }}>
                  <Lock size={18} color={C.text3} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    disabled={success}
                    style={{
                      flex: 1,
                      border: 'none',
                      background: 'transparent',
                      outline: 'none',
                      fontSize: 14,
                      color: C.text,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      color: C.text3,
                    }}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* ============================================== */}
              {/* OPTIONS DE CONNEXION */}
              {/* ============================================== */}
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: 25,
              }}>
                {/* Checkbox "Se souvenir de moi" */}
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  cursor: 'pointer',
                }}>
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    style={{ cursor: 'pointer' }}
                  />
                  <span style={{ fontSize: 12, color: C.text2 }}>Se souvenir de moi</span>
                </label>
                
                {/* Lien "Mot de passe oublié" */}
                <Link
                  href="/forgot-password"
                  style={{
                    fontSize: 12,
                    color: C.green,
                    textDecoration: 'none',
                    fontWeight: 500,
                  }}
                >
                  Mot de passe oublié ?
                </Link>
              </div>

              {/* ============================================== */}
              {/* BOUTON DE CONNEXION */}
              {/* ============================================== */}
              <button
                type="submit"
                disabled={loading || success}
                style={{
                  width: '100%',
                  padding: '14px',
                  borderRadius: 10,
                  border: 'none',
                  background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
                  color: 'white',
                  fontSize: 14,
                  fontWeight: 600,
                  cursor: loading || success ? 'wait' : 'pointer',
                  opacity: loading || success ? 0.7 : 1,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                  boxShadow: `0 4px 10px ${C.green}40`,
                }}
              >
                {loading ? (
                  <Loader size={18} className="spin" />
                ) : success ? (
                  <CheckCircle size={18} />
                ) : (
                  <LogIn size={18} />
                )}
                {loading ? 'Connexion...' : success ? 'Redirection...' : 'Se connecter'}
              </button>
            </form>

            {/* ============================================== */}
            {/* LIEN D'INSCRIPTION */}
            {/* ============================================== */}
            <p style={{
              marginTop: 20,
              fontSize: 12,
              color: C.text3,
              textAlign: 'center',
            }}>
              Pas encore de compte ?{' '}
              <Link
                href="/register"
                style={{
                  color: C.green,
                  textDecoration: 'none',
                  fontWeight: 600,
                }}
              >
                S'inscrire
              </Link>
            </p>
          </div>

          {/* ============================================== */}
          {/* FOOTER DE LA CARTE */}
          {/* ============================================== */}
          <div style={{
            padding: '15px 20px',
            background: C.surface2,
            borderTop: `1px solid ${C.border}`,
            fontSize: 11,
            color: C.text3,
            textAlign: 'center',
          }}>
            © 2026 PV Monitor · Version 1.0.0
          </div>
        </div>
      </div>
    </div>
  );
}