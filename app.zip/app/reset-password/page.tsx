// frontend/app/reset-password/page.tsx
'use client';

/**
 * ============================================================
 * PAGE DE RÉINITIALISATION DE MOT DE PASSE - PV MONITOR
 * ============================================================
 * Cette page permet à l'utilisateur de réinitialiser son mot de passe
 * après avoir cliqué sur le lien reçu par email.
 * 
 * Fonctionnalités :
 * - Récupération du token depuis l'URL
 * - Validation du token
 * - Saisie du nouveau mot de passe (avec confirmation)
 * - Appel API pour la réinitialisation
 * - Redirection vers la page de connexion après succès
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Lock, Eye, EyeOff, AlertCircle, CheckCircle, Loader, ArrowLeft } from 'lucide-react';
import { API_BASE } from '@/lib/api';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';
// ============================================================
// FORMULAIRE DE RÉINITIALISATION (COMPOSANT INTERNE)
// ============================================================
/**
 * Ce composant est séparé pour pouvoir utiliser useSearchParams
 * qui nécessite d'être enveloppé dans Suspense
 */
function ResetPasswordForm() {
  // ==========================================================
  // HOOKS ET ROUTER
  // ==========================================================
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token'); // Récupère le token depuis l'URL

  // ==========================================================
  // ÉTATS
  // ==========================================================
  const [password, setPassword] = useState('');           // Nouveau mot de passe
  const [confirmPassword, setConfirmPassword] = useState(''); // Confirmation
  const [showPassword, setShowPassword] = useState(false); // Afficher/masquer
  const [loading, setLoading] = useState(false);          // État de chargement
  const [error, setError] = useState('');                  // Message d'erreur
  const [success, setSuccess] = useState(false);           // Succès de l'opération

  // ==========================================================
  // EFFETS DE BORD
  // ==========================================================

  /**
   * Vérifie la présence du token dans l'URL
   * Si token manquant, affiche une erreur
   */
  useEffect(() => {
    if (!token) {
      setError('Lien de réinitialisation invalide');
    }
  }, [token]);

  // ==========================================================
  // GESTION DE LA SOUMISSION
  // ==========================================================

  /**
   * Soumet le formulaire de réinitialisation
   * - Valide les champs
   * - Envoie la requête à l'API
   * - Gère la réponse (succès/erreur)
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // ========================================================
    // VALIDATIONS
    // ========================================================
    
    // Vérification du token
    if (!token) {
      setError('Lien de réinitialisation invalide');
      return;
    }

    // Vérification du mot de passe
    if (!password) {
      setError('Veuillez entrer un mot de passe');
      return;
    }

    // Vérification de la longueur minimale
    if (password.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }

    // Vérification de la correspondance
    if (password !== confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }

    // ========================================================
    // APPEL API
    // ========================================================
    
    setLoading(true);

    try {
      console.log('📤 URL:', `${API_BASE}/api/v1/auth/reset-password`); // Log de debug
      
      // Appel à l'API de réinitialisation
      const response = await fetch(`${API_BASE}/api/v1/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, new_password: password }),
      });

      const data = await response.json();

      if (response.ok) {
        // Succès : affichage du message et redirection
        setSuccess(true);
        setTimeout(() => {
          router.push('/login');
        }, 3000);
      } else {
        // Erreur API
        setError(data.detail || 'Erreur lors de la réinitialisation');
      }
    } catch (err) {
      // Erreur réseau
      console.error('❌ Erreur:', err); // Log de debug
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  // ==========================================================
  // AFFICHAGE CONDITIONNEL
  // ==========================================================

  // Affichage d'un loader pendant la vérification du token
  if (!token && !error) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 0' }}>
        <Loader size={40} className="spin" color={C.green} />
      </div>
    );
  }

  // ==========================================================
  // RENDU DU FORMULAIRE
  // ==========================================================
  return (
    <div style={{
      background: C.surface,
      borderRadius: 20,
      boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
      padding: 30,
      border: `1px solid ${C.border}`,
    }}>
      
      
     
      {success ? (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <CheckCircle size={60} color={C.green} style={{ marginBottom: 20 }} />
          <h2 style={{ fontSize: 20, fontWeight: 600, color: C.green, marginBottom: 15 }}>
            Mot de passe modifié !
          </h2>
          <p style={{ color: C.text2, marginBottom: 20 }}>
            Votre mot de passe a été réinitialisé avec succès.
          </p>
          <p style={{ color: C.text3, fontSize: 13 }}>
            Redirection vers la page de connexion...
          </p>
        </div>
      ) : (
        
        
        <form onSubmit={handleSubmit}>
          
          {/* Message d'erreur */}
          {error && (
            <div style={{
              marginBottom: 20,
              padding: '12px',
              background: C.redL,
              color: C.red,
              borderRadius: 8,
              fontSize: 13,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
            }}>
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          {/* ================================================ */}
          {/* CHAMP : NOUVEAU MOT DE PASSE */}
          {/* ================================================ */}
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
              Nouveau mot de passe
            </label>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '12px',
              background: C.surface2,
              borderRadius: 10,
              border: `1px solid ${C.border}`,
            }}>
              <Lock size={18} color={C.text3} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                style={{
                  flex: 1,
                  border: 'none',
                  background: 'transparent',
                  outline: 'none',
                  fontSize: 14,
                  color: C.text,
                }}
              />
              {/* Bouton afficher/masquer */}
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
              >
                {showPassword ? <EyeOff size={18} color={C.text3} /> : <Eye size={18} color={C.text3} />}
              </button>
            </div>
          </div>

          {/* ================================================ */}
          {/* CHAMP : CONFIRMATION */}
          {/* ================================================ */}
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
              Confirmer le mot de passe
            </label>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '12px',
              background: C.surface2,
              borderRadius: 10,
              border: `1px solid ${C.border}`,
            }}>
              <Lock size={18} color={C.text3} />
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                style={{
                  flex: 1,
                  border: 'none',
                  background: 'transparent',
                  outline: 'none',
                  fontSize: 14,
                  color: C.text,
                }}
              />
            </div>
          </div>

          {/* ================================================ */}
          {/* BOUTON DE SOUMISSION */}
          {/* ================================================ */}
          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '14px',
              borderRadius: 10,
              border: 'none',
              background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
              color: 'white',
              fontSize: 14,
              fontWeight: 600,
              cursor: loading ? 'wait' : 'pointer',
              opacity: loading ? 0.7 : 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              marginBottom: 20,
            }}
          >
            {loading ? <Loader size={18} className="spin" /> : 'Réinitialiser'}
          </button>

          {/* ================================================ */}
          {/* LIEN DE RETOUR VERS LA CONNEXION */}
          {/* ================================================ */}
          <Link href="/login" style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 4,
            color: C.text2,
            textDecoration: 'none',
            fontSize: 13,
          }}>
            <ArrowLeft size={14} />
            Retour à la connexion
          </Link>
        </form>
      )}
    </div>
  );
}

// ============================================================
// COMPOSANT PRINCIPAL (AVEC SUSPENSE)
// ============================================================
export default function ResetPasswordPage() {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: `linear-gradient(135deg, ${C.green}10 0%, ${C.surface2} 100%)`,
      padding: '20px',
    }}>
      <div style={{ maxWidth: 400, width: '100%' }}>
        
        {/* ================================================== */}
        {/* LOGO ET TITRE */}
        {/* ================================================== */}
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <div style={{
            width: 70,
            height: 70,
            background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
            borderRadius: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 15px',
            boxShadow: `0 10px 20px ${C.green}30`,
          }}>
            <Lock size={40} color="white" />
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, color: C.text }}>
            Nouveau mot de passe
          </h1>
          <p style={{ fontSize: 14, color: C.text2, marginTop: 5 }}>
            Choisissez un nouveau mot de passe
          </p>
        </div>

        {/* ================================================== */}
        {/* SUSPENSE POUR LE FORMULAIRE (NÉCESSAIRE POUR useSearchParams) */}
        {/* ================================================== */}
        <Suspense fallback={
          <div style={{ textAlign: 'center', padding: '40px 0' }}>
            <Loader size={40} className="spin" color={C.green} />
          </div>
        }>
          <ResetPasswordForm />
        </Suspense>
      </div>
    </div>
  );
}