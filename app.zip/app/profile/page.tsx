// frontend/app/profile/page.tsx
'use client';

/**
 * ============================================================
 * PAGE DE PROFIL UTILISATEUR - PV MONITOR
 * ============================================================
 * Cette page permet à l'utilisateur de gérer son profil :
 * - Informations personnelles (nom, email, bio, etc.)
 * - Sécurité du compte (mot de passe, 2FA, sessions)
 * - Préférences utilisateur (thème, notifications, langue)
 * - Journal d'activité
 * - Gestion des clés API
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import {
  User, Mail, Shield, Calendar, Clock, Edit2,
  Save, X, Camera, Key, Bell, Globe, Moon,
  Sun, Smartphone, LogOut, AlertCircle, CheckCircle,
  Loader, Eye, EyeOff, Lock, RefreshCw, Award,
  MapPin, Phone, Link as LinkIcon, Github, Twitter,
  Linkedin, Copy, Check
} from 'lucide-react';
import { API_BASE, getAuthToken } from '@/lib/api';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// TYPES ET INTERFACES
// ============================================================

/**
 * Interface pour les logs d'activité
 
interface ActivityLog {
  id: string;
  action: string;
  timestamp: string;
  ip: string;
  device: string;
  status: 'success' | 'warning' | 'error';
}*/

/**
 * Interface pour les clés API
 */
interface ApiKey {
  id: number;
  name: string;
  key: string;
  lastUsed: string;
  created: string;
  status: 'active' | 'inactive';
}

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function ProfilePage() {
  // ==========================================================
  // CONTEXTES ET HOOKS
  // ==========================================================
  const { user, updateProfile, logout, isAdmin, isUser, isViewer } = useAuth();
  const router = useRouter();
  
  // ==========================================================
  // ÉTATS - INTERFACE
  // ==========================================================
  const [isEditing, setIsEditing] = useState(false);           // Mode édition du profil
  const [loading, setLoading] = useState(false);               // État de chargement général
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null); // Messages utilisateur
  const [copied, setCopied] = useState(false);                 // Indicateur de copie d'une clé
  const [showApiKey, setShowApiKey] = useState(false);         // Afficher/masquer les clés API
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'preferences' | 'activity' | 'api'>('profile'); // Onglet actif





  // ============================================================
// ÉTATS POUR LE CHANGEMENT DE MOT DE PASSE
// ============================================================
const [showPasswordModal, setShowPasswordModal] = useState(false);
const [currentPassword, setCurrentPassword] = useState('');
const [newPassword, setNewPassword] = useState('');
const [confirmPassword, setConfirmPassword] = useState('');
const [passwordLoading, setPasswordLoading] = useState(false);
const [passwordError, setPasswordError] = useState<string | null>(null);
const [passwordSuccess, setPasswordSuccess] = useState(false);
const [showChangePassword, setShowChangePassword] = useState(false);
const [error, setError] = useState<string | null>(null);
// Debug des états
console.log('📊 État du modal:', showPasswordModal);
console.log('📊 PasswordError:', passwordError);
console.log('📊 PasswordSuccess:', passwordSuccess);
console.log('📊 PasswordLoading:', passwordLoading);
  // ==========================================================
  // ÉTATS - DONNÉES SIMULÉES (À REMPLACER PAR APPELS API)
  // ==========================================================
  
  /**
   * Clés API (simulées)
   */
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([
    { id: 1, name: 'Clé publique', key: 'pk_live_abcdefghijklmnopqrstuvwxyz', lastUsed: '14/03/2026', created: '01/01/2026', status: 'active' },
    { id: 2, name: 'Clé admin', key: 'sk_live_1234567890abcdefghijklmn', lastUsed: '13/03/2026', created: '01/01/2026', status: 'active' },
  ]);
  
  /**
   * Journal d'activité (simulé)
   
    const [activityLog, setActivityLog] = useState<ActivityLog[]>([
    { id: '1', action: 'Connexion réussie', timestamp: '14/03/2026 10:30', ip: '192.168.1.42', device: 'Chrome / Windows', status: 'success' },
    { id: '2', action: 'Modification du profil', timestamp: '13/03/2026 15:20', ip: '192.168.1.42', device: 'Chrome / Windows', status: 'success' },
    { id: '3', action: 'Tentative de connexion échouée', timestamp: '12/03/2026 08:15', ip: '45.123.45.67', device: 'Firefox / Android', status: 'error' },
    { id: '4', action: 'Changement de mot de passe', timestamp: '10/03/2026 11:45', ip: '192.168.1.42', device: 'Chrome / Windows', status: 'success' },
    { id: '5', action: 'Nouvel appareil connecté', timestamp: '09/03/2026 18:30', ip: '78.234.56.78', device: 'Safari / iPhone', status: 'warning' },
  ]);*/

  // ==========================================================
  // ÉTATS - CHARGEMENT SPÉCIFIQUE
  // ==========================================================
  const [loadingKeys, setLoadingKeys] = useState(false);
  const [loadingActivity, setLoadingActivity] = useState(false);
  
  // ==========================================================
  // ÉTATS - FORMULAIRES
  // ==========================================================
  
  /**
   * Données du formulaire d'édition du profil
   */
  const [editedUser, setEditedUser] = useState({
    name: user?.name || '',
    email: user?.email || '',
    bio: (user as any)?.bio || 'Passionné par les énergies renouvelables',
    phone: (user as any)?.phone || '',
    //location: (user as any)?.location || '',
    website: (user as any)?.website || 'https://example.com',
    github: (user as any)?.github || 'github.com/username',
    twitter: (user as any)?.twitter || '@username',
    linkedin: (user as any)?.linkedin || 'linkedin.com/in/username',
  });

  /**
   * Préférences utilisateur
   */
  const [preferences, setPreferences] = useState({
    darkMode: false,
    emailNotifications: true,
    pushNotifications: true,
    autoRefresh: true,
    refreshInterval: 30,
    language: 'fr',
    timezone: 'Europe/Paris',
    twoFactorAuth: false,
  });

  /**
   * Statistiques utilisateur (simulées)
   
  const stats = {
    totalLogins: 156,
    lastLogin: '14/03/2026 10:30',
    devicesConnected: 3,
    alertsReceived: 24,
    reportsGenerated: 8,
    interventionsPlanned: 2,
  };*/

  // ==========================================================
  // FONCTIONS UTILITAIRES
  // ==========================================================

  /**
   * Retourne la couleur associée au rôle de l'utilisateur
   */
  const getRoleColor = () => {
    if (isAdmin) return C.green;
    if (isUser) return C.blue;
    return C.amber;
  };

  /**
   * Retourne le libellé du rôle de l'utilisateur
   */
  const getRoleLabel = () => {
    if (isAdmin) return 'Administrateur';
    if (isUser) return 'Technicien';
    return 'Observateur';
  };

  // ==========================================================
  // GESTIONNAIRES D'ÉVÉNEMENTS - PROFIL
  // ==========================================================

  /**
   * Sauvegarde les modifications du profil
   */
  const handleSave = async () => {
    setLoading(true);
    const success = await updateProfile(editedUser);
    if (success) {
      setMessage({ text: 'Profil mis à jour avec succès', type: 'success' });
      setIsEditing(false);
    } else {
      setMessage({ text: 'Erreur lors de la mise à jour', type: 'error' });
    }
    setLoading(false);
    setTimeout(() => setMessage(null), 3000);
  };

  // ==========================================================
  // GESTIONNAIRES D'ÉVÉNEMENTS - CLÉS API
  // ==========================================================

  /**
   * Génère une nouvelle clé API
   */
  const handleGenerateApiKey = () => {
    const name = prompt('Nom de la clé API:');
    if (!name) return;
    
    setLoadingKeys(true);
    setTimeout(() => {
      const newKey: ApiKey = {
        id: Date.now(),
        name,
        key: `sk_live_${Math.random().toString(36).substring(2, 15)}`,
        lastUsed: 'Jamais',
        created: new Date().toLocaleDateString('fr-FR'),
        status: 'active'
      };
      setApiKeys([...apiKeys, newKey]);
      setLoadingKeys(false);
      setMessage({ text: 'Clé API générée avec succès', type: 'success' });
      setTimeout(() => setMessage(null), 3000);
    }, 500);
  };

  /**
   * Révoque une clé API
   */
  const handleRevokeApiKey = (keyId: number) => {
    if (confirm('Révoquer cette clé API ? Cette action est irréversible.')) {
      setApiKeys(apiKeys.filter(k => k.id !== keyId));
      setMessage({ text: 'Clé API révoquée', type: 'success' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  /**
   * Copie une clé API dans le presse-papier
   */
  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ==========================================================
  // GESTIONNAIRES D'ÉVÉNEMENTS - PRÉFÉRENCES
  // ==========================================================

  /**
   * Sauvegarde les préférences utilisateur
   */
  const handleSavePreferences = () => {
    setLoading(true);
    setTimeout(() => {
      setMessage({ text: 'Préférences sauvegardées', type: 'success' });
      setLoading(false);
      setTimeout(() => setMessage(null), 3000);
    }, 500);
  };

  // ==========================================================
  // GESTIONNAIRES D'ÉVÉNEMENTS - SÉCURITÉ (À IMPLÉMENTER)
  // ==========================================================
  
// ============================================================
// FONCTION DE CHANGEMENT DE MOT DE PASSE
// ============================================================
const handleChangePassword = async () => {
  console.log('🟢 Fonction appelée');
  
  // Validation
  if (!currentPassword || !newPassword || !confirmPassword) {
    setPasswordError('Tous les champs sont requis');
    return;
  }

  if (newPassword !== confirmPassword) {
    setPasswordError('Les mots de passe ne correspondent pas');
    return;
  }

  if (newPassword.length < 8) {
    setPasswordError('Le mot de passe doit contenir au moins 8 caractères');
    return;
  }

  console.log('📝 Champs:', {
    currentPassword: currentPassword ? '✓' : '✗',
    newPassword: newPassword ? '✓' : '✗',
    confirmPassword: confirmPassword ? '✓' : '✗'
  });

  setPasswordLoading(true);
  setPasswordError(null);

  try {
    console.log('🔑 Récupération du token...');
    const token = getAuthToken();
    
    console.log('🔑 Token présent:', !!token);
    
    if (token) {
      // Affiche les premiers caractères du token
      console.log('🔑 Token (début):', token.substring(0, 30) + '...');
      
      // Essaie de décoder le token pour voir son contenu
      try {
        const base64Payload = token.split('.')[1];
        const payload = JSON.parse(atob(base64Payload));
        console.log('📦 Payload du token:', payload);
        console.log('👤 Contient sub (user_id)?', payload.sub ? 'Oui' : 'Non');
        console.log('👤 Contient device_id?', payload.device_id ? 'Oui' : 'Non');
        console.log('👤 Rôle:', payload.role || 'non spécifié');
      } catch (e) {
        console.log('❌ Impossible de décoder le token:', e);
      }
    } else {
      console.log('❌ Pas de token');
      setPasswordError('Vous devez être connecté');
      setPasswordLoading(false);
      return;
    }

    const url = `${API_BASE}/api/v1/auth/change-password`;
    console.log('🌐 URL:', url);
    console.log('📦 Body:', { 
      currentPassword: '***', 
      newPassword: '***' 
    });

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        currentPassword: currentPassword,
        newPassword: newPassword,
      }),
    });

    console.log('📥 Status:', response.status);
    
    // Lire la réponse seulement si elle existe
    let data;
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
      console.log('📥 Réponse JSON:', data);
    } else {
      data = await response.text();
      console.log('📥 Réponse texte:', data);
    }

    if (!response.ok) {
      // Gestion améliorée des erreurs
      let errorMessage = `Erreur ${response.status}`;
      
      if (data) {
        if (typeof data === 'string') {
          errorMessage = data;
        } else if (data.detail) {
          // Si detail est un tableau d'erreurs de validation (format Pydantic)
          if (Array.isArray(data.detail)) {
            errorMessage = data.detail.map((err: any) => {
              // Format Pydantic typique : { loc: [...], msg: "...", type: "..." }
              if (err.msg) return err.msg;
              if (err.message) return err.message;
              return JSON.stringify(err);
            }).join(', ');
          } else {
            errorMessage = data.detail;
          }
        } else if (data.message) {
          errorMessage = data.message;
        } else {
          // Dernier recours : afficher l'objet en JSON
          errorMessage = JSON.stringify(data);
        }
      }
      
      console.error('❌ Détail erreur:', data);
      throw new Error(errorMessage);
    }

    // Succès
    console.log('✅ Succès!', data);
    setPasswordSuccess(true);
    
    // Réinitialiser les champs après 2 secondes et fermer le modal
    setTimeout(() => {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setShowPasswordModal(false);
      setPasswordSuccess(false);
    }, 2000);

  } catch (err: any) {
    console.error('❌ Erreur:', err);
    setPasswordError(err instanceof Error ? err.message : 'Une erreur est survenue');
  } finally {
    setPasswordLoading(false);
  }
};
///////////////////////////////////////////////////////////////////////////

 

  const handleRevokeSession = (sessionId: string) => {
    alert(`Session ${sessionId} révoquée`);
  };

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <ProtectedRoute>
      <div>
        {/* ================================================== */}
        {/* EN-TÊTE DE LA PAGE */}
        {/* ================================================== */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 20,
        }}>
          <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
            <User size={24} color={getRoleColor()} />
            Mon Profil
          </h1>
          <div style={{ display: 'flex', gap: 8 }}>
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  border: 'none',
                  background: C.green,
                  color: 'white',
                  fontSize: 13,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                <Edit2 size={16} />
                Modifier le profil
              </button>
            ) : (
              <>
                <button
                  onClick={handleSave}
                  disabled={loading}
                  style={{
                    padding: '8px 16px',
                    borderRadius: 8,
                    border: 'none',
                    background: C.green,
                    color: 'white',
                    fontSize: 13,
                    cursor: loading ? 'wait' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  {loading ? <Loader size={16} className="spin" /> : <Save size={16} />}
                  Sauvegarder
                </button>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setEditedUser({
                      name: user?.name || '',
                      email: user?.email || '',
                      bio: 'Passionné par les énergies renouvelables',
                      phone: '',
                      //location: '',
                      website: 'https://example.com',
                      github: 'github.com/username',
                      twitter: '@username',
                      linkedin: 'linkedin.com/in/username',
                    });
                  }}
                  style={{
                    padding: '8px 16px',
                    borderRadius: 8,
                    border: `1px solid ${C.border}`,
                    background: 'transparent',
                    color: C.text2,
                    fontSize: 13,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  <X size={16} />
                  Annuler
                </button>
              </>
            )}
          </div>
        </div>

        {/* ================================================== */}
        {/* MESSAGE DE STATUT (SUCCÈS/ERREUR) */}
        {/* ================================================== */}
        {message && (
          <div style={{
            marginBottom: 20,
            padding: '12px 16px',
            borderRadius: 8,
            background: message.type === 'success' ? C.greenL : C.redL,
            color: message.type === 'success' ? C.green : C.red,
            fontSize: 13,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
          }}>
            {message.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
            {message.text}
          </div>
        )}

        {/* ================================================== */}
        {/* ONGLETS DE NAVIGATION */}
        {/* ================================================== */}
        <div style={{
          display: 'flex',
          gap: 8,
          marginBottom: 20,
          borderBottom: `1px solid ${C.border}`,
          paddingBottom: 8,
          overflowX: 'auto',
        }}>
          {[
            { id: 'profile', label: 'Profil', icon: User },
            { id: 'security', label: 'Sécurité', icon: Lock },
            { id: 'preferences', label: 'Préférences', icon: Moon },
           // { id: 'activity', label: 'Activité', icon: Clock },
            { id: 'api', label: 'API Keys', icon: Key },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  border: 'none',
                  background: activeTab === tab.id ? getRoleColor() : 'transparent',
                  color: activeTab === tab.id ? 'white' : C.text2,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  whiteSpace: 'nowrap',
                }}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* ================================================== */}
        {/* CONTENU DES ONGLETS */}
        {/* ================================================== */}

        {/* -------------------------------------------------- */}
        {/* TAB 1 : PROFIL */}
        {/* -------------------------------------------------- */}
        {activeTab === 'profile' && (
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 14,
            padding: 24,
          }}>
            <div style={{ display: 'flex', gap: 30, flexWrap: 'wrap' }}>
              {/* ============================================ */}
              {/* AVATAR */}
              {/* ============================================ */}
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: 120,
                  height: 120,
                  borderRadius: '50%',
                  background: `linear-gradient(135deg, ${getRoleColor()}, ${getRoleColor()}80)`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: 12,
                  position: 'relative',
                }}>
                  <span style={{ fontSize: 48, color: 'white', fontWeight: 600 }}>
                    {user?.name?.charAt(0).toUpperCase()}
                  </span>
                  {isEditing && (
                    <button style={{
                      position: 'absolute',
                      bottom: 0,
                      right: 0,
                      width: 32,
                      height: 32,
                      borderRadius: '50%',
                      background: C.surface,
                      border: `2px solid ${C.border}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                    }}>
                      <Camera size={16} color={C.text2} />
                    </button>
                  )}
                </div>
                <div style={{
                  padding: '4px 12px',
                  background: `${getRoleColor()}18`,
                  color: getRoleColor(),
                  borderRadius: 99,
                  fontSize: 12,
                  fontWeight: 600,
                  display: 'inline-block',
                }}>
                  {getRoleLabel()}
                </div>
              </div>

              {/* ============================================ */}
              {/* INFORMATIONS PERSONNELLES */}
              {/* ============================================ */}
              <div style={{ flex: 1 }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
                  {/* Nom complet */}
                  <div>
                    <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
                      Nom complet
                    </label>
                    {isEditing ? (
                      <input
                        value={editedUser.name}
                        onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          borderRadius: 6,
                          border: `1px solid ${C.border}`,
                          background: C.surface2,
                          color: C.text,
                          fontSize: 13,
                        }}
                      />
                    ) : (
                      <div style={{ fontSize: 14, fontWeight: 500, color: C.text }}>{user?.name}</div>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
                      Email
                    </label>
                    {isEditing ? (
                      <input
                        type="email"
                        value={editedUser.email}
                        onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          borderRadius: 6,
                          border: `1px solid ${C.border}`,
                          background: C.surface2,
                          color: C.text,
                          fontSize: 13,
                        }}
                      />
                    ) : (
                      <div style={{ fontSize: 14, color: C.text2 }}>{user?.email}</div>
                    )}
                  </div>

                  {/* Téléphone */}
                  <div>
                    <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
                      Téléphone
                    </label>
                    {isEditing ? (
                      <input
                        value={editedUser.phone}
                        onChange={(e) => setEditedUser({ ...editedUser, phone: e.target.value })}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          borderRadius: 6,
                          border: `1px solid ${C.border}`,
                          background: C.surface2,
                          color: C.text,
                          fontSize: 13,
                        }}
                      />
                    ) : (
                      <div style={{ fontSize: 14, color: C.text2 }}>{editedUser.phone || '-'}</div>
                    )}
                  </div>

                  {/* Localisation 
                  <div>
                    <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
                      Localisation
                    </label>
                    {isEditing ? (
                      <input
                        value={editedUser.location}
                        onChange={(e) => setEditedUser({ ...editedUser, location: e.target.value })}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          borderRadius: 6,
                          border: `1px solid ${C.border}`,
                          background: C.surface2,
                          color: C.text,
                          fontSize: 13,
                        }}
                      />
                    ) : (
                      <div style={{ fontSize: 14, color: C.text2 }}>{editedUser.location || '-'}</div>
                    )}
                  </div>*/}

                  {/* Bio (pleine largeur) 
                  <div style={{ gridColumn: 'span 2' }}>
                    <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>
                      Bio
                    </label>
                    {isEditing ? (
                      <textarea
                        value={editedUser.bio}
                        onChange={(e) => setEditedUser({ ...editedUser, bio: e.target.value })}
                        rows={3}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          borderRadius: 6,
                          border: `1px solid ${C.border}`,
                          background: C.surface2,
                          color: C.text,
                          fontSize: 13,
                          resize: 'vertical',
                        }}
                      />
                    ) : (
                      <div style={{ fontSize: 14, color: C.text2, lineHeight: 1.5 }}>
                        {editedUser.bio}
                      </div>
                    )}
                  </div>*/}
                </div>

                {/* ========================================== */}
                {/* RÉSEAUX SOCIAUX */}
                {/* ========================================== */}
                <div style={{ marginTop: 20 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 12 }}>
                    Réseaux sociaux
                  </div>
                  <div style={{ display: 'flex', gap: 16 }}>
                    {isEditing ? (
                      <>
                        <input
                          value={editedUser.github}
                          onChange={(e) => setEditedUser({ ...editedUser, github: e.target.value })}
                          placeholder="GitHub"
                          style={{
                            flex: 1,
                            padding: '8px 12px',
                            borderRadius: 6,
                            border: `1px solid ${C.border}`,
                            background: C.surface2,
                            color: C.text,
                            fontSize: 12,
                          }}
                        />
                        <input
                          value={editedUser.twitter}
                          onChange={(e) => setEditedUser({ ...editedUser, twitter: e.target.value })}
                          placeholder="Twitter"
                          style={{
                            flex: 1,
                            padding: '8px 12px',
                            borderRadius: 6,
                            border: `1px solid ${C.border}`,
                            background: C.surface2,
                            color: C.text,
                            fontSize: 12,
                          }}
                        />
                        <input
                          value={editedUser.linkedin}
                          onChange={(e) => setEditedUser({ ...editedUser, linkedin: e.target.value })}
                          placeholder="LinkedIn"
                          style={{
                            flex: 1,
                            padding: '8px 12px',
                            borderRadius: 6,
                            border: `1px solid ${C.border}`,
                            background: C.surface2,
                            color: C.text,
                            fontSize: 12,
                          }}
                        />
                      </>
                    ) : (
                      <>
                        <a href="#" style={{ color: C.text2, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <Github size={16} />
                          <span style={{ fontSize: 12 }}>{editedUser.github}</span>
                        </a>
                        <a href="#" style={{ color: C.text2, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <Twitter size={16} />
                          <span style={{ fontSize: 12 }}>{editedUser.twitter}</span>
                        </a>
                        <a href="#" style={{ color: C.text2, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <Linkedin size={16} />
                          <span style={{ fontSize: 12 }}>{editedUser.linkedin}</span>
                        </a>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* ================================================ */}
            {/* STATISTIQUES */}
            {/* ================================================ */}
          {/*  <div style={{
              marginTop: 24,
              padding: 16,
              background: C.surface2,
              borderRadius: 10,
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: 16,
            }}>
              <div>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.green }}>{stats.totalLogins}</div>
                <div style={{ fontSize: 11, color: C.text3 }}>Connexions totales</div>
              </div>
              <div>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.blue }}>{stats.devicesConnected}</div>
                <div style={{ fontSize: 11, color: C.text3 }}>Appareils connectés</div>
              </div>
              <div>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.amber }}>{stats.alertsReceived}</div>
                <div style={{ fontSize: 11, color: C.text3 }}>Alertes reçues</div>
              </div>
              <div>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.purple }}>{stats.reportsGenerated}</div>
                <div style={{ fontSize: 11, color: C.text3 }}>Rapports générés</div>
              </div>
            </div>
            */}
          </div>
        )}

        {/* -------------------------------------------------- */}
        {/* TAB 2 : SÉCURITÉ */}
        {/* -------------------------------------------------- */}
        {activeTab === 'security' && (
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 14,
            padding: 24,
          }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 20 }}>
              Sécurité du compte
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              
             {/* ============================================ */}
{/* MOT DE PASSE */}
{/* ============================================ */}
<div style={{
  padding: 16,
  background: C.surface2,
  borderRadius: 10,
}}>
  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
    <div>
      <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>Mot de passe</div>
      <div style={{ fontSize: 11, color: C.text3, marginTop: 2 }}>
        Dernière modification : il y a 30 jours
      </div>
    </div>
    <button
      onClick={() => setShowPasswordModal(true)}
      style={{
        padding: '6px 12px',
        borderRadius: 6,
        border: `1px solid ${C.border}`,
        background: C.surface,
        color: C.text,
        fontSize: 12,
        cursor: 'pointer',
        transition: 'all 0.2s',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = C.green;
        e.currentTarget.style.color = 'white';
        e.currentTarget.style.borderColor = C.green;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = C.surface;
        e.currentTarget.style.color = C.text;
        e.currentTarget.style.borderColor = C.border;
      }}
    >
      Modifier
    </button>
  </div>
</div>

{/* ============================================ */}
{/* MODAL DE CHANGEMENT DE MOT DE PASSE */}
{/* ============================================ */}
{showPasswordModal && (
  <div style={{
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  }}>
    <div style={{
      background: C.surface,
      borderRadius: 14,
      padding: 24,
      width: 400,
      maxWidth: '90%',
      boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
    }}>
      <h3 style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 20 }}>
        Changer le mot de passe
      </h3>

      {/* Message de succès */}
      {passwordSuccess && (
        <div style={{
          background: C.greenL,
          color: C.green,
          padding: 12,
          borderRadius: 8,
          marginBottom: 16,
          fontSize: 13,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}>
          <CheckCircle size={16} />
          Mot de passe modifié avec succès !
        </div>
      )}

      {/* Message d'erreur */}
      {passwordError && (
        <div style={{
          background: C.redL,
          color: C.red,
          padding: 12,
          borderRadius: 8,
          marginBottom: 16,
          fontSize: 13,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}>
          <AlertCircle size={16} />
          {passwordError}
        </div>
      )}

      {/* Formulaire */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        
        {/* Mot de passe actuel */}
        <div>
          <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
            Mot de passe actuel
          </label>
          <input
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            disabled={passwordLoading || passwordSuccess}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: C.surface2,
              color: C.text,
              fontSize: 13,
              outline: 'none',
              transition: 'border-color 0.2s',
            }}
            onFocus={(e) => e.target.style.borderColor = C.green}
            onBlur={(e) => e.target.style.borderColor = C.border}
          />
        </div>

        {/* Nouveau mot de passe */}
        <div>
          <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
            Nouveau mot de passe
          </label>
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            disabled={passwordLoading || passwordSuccess}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: C.surface2,
              color: C.text,
              fontSize: 13,
              outline: 'none',
              transition: 'border-color 0.2s',
            }}
            onFocus={(e) => e.target.style.borderColor = C.green}
            onBlur={(e) => e.target.style.borderColor = C.border}
          />
          <div style={{ fontSize: 10, color: C.text3, marginTop: 4 }}>
            Minimum 8 caractères, avec majuscule, minuscule et chiffre
          </div>
        </div>

        {/* Confirmation */}
        <div>
          <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
            Confirmer le nouveau mot de passe
          </label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            disabled={passwordLoading || passwordSuccess}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: C.surface2,
              color: C.text,
              fontSize: 13,
              outline: 'none',
              transition: 'border-color 0.2s',
            }}
            onFocus={(e) => e.target.style.borderColor = C.green}
            onBlur={(e) => e.target.style.borderColor = C.border}
          />
        </div>
      </div>

      {/* Boutons */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 24 }}>
        <button
          onClick={() => {
            setShowPasswordModal(false);
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
            setPasswordError(null);
          }}
          disabled={passwordLoading}
          style={{
            padding: '10px 16px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: 'transparent',
            color: C.text2,
            fontSize: 13,
            cursor: passwordLoading ? 'not-allowed' : 'pointer',
            opacity: passwordLoading ? 0.5 : 1,
          }}
        >
          Annuler
        </button>
        <button
          onClick={handleChangePassword}
          disabled={passwordLoading || passwordSuccess}
          style={{
            padding: '10px 16px',
            borderRadius: 8,
            border: 'none',
            background: passwordLoading ? C.surface2 : C.green,
            color: passwordLoading ? C.text3 : 'white',
            fontSize: 13,
            fontWeight: 600,
            cursor: passwordLoading ? 'wait' : 'pointer',
            opacity: passwordLoading ? 0.7 : 1,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}
        >
          {passwordLoading ? (
            <>
              <Loader size={14} className="spin" />
              Modification...
            </>
          ) : (
            'Changer le mot de passe'
          )}
        </button>
      </div>
    </div>
  </div>
)}
              {/* ============================================ */}
              {/* DOUBLE AUTHENTIFICATION */}
              {/* ============================================ */}
             {/* <div style={{
                padding: 16,
                background: C.surface2,
                borderRadius: 10,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>Authentification à deux facteurs</div>
                    <div style={{ fontSize: 11, color: C.text3, marginTop: 2 }}>
                      Ajoutez une couche de sécurité supplémentaire
                    </div>
                  </div>
                  <button
                    onClick={handleEnable2FA}
                    style={{
                      padding: '6px 12px',
                      borderRadius: 6,
                      border: 'none',
                      background: C.blue,
                      color: 'white',
                      fontSize: 12,
                      cursor: 'pointer',
                    }}
                  >
                    Activer
                  </button>
                </div>
              </div>*/}

              {/* ============================================ */}
              {/* SESSIONS ACTIVES */}
              {/* ============================================ */}
            {/*  <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 12 }}>
                  Sessions actives
                </div>
                {[
                  { id: '1', device: 'Chrome sur Windows', ip: '192.168.1.42', lastActive: 'Maintenant', current: true },
                  { id: '2', device: 'Safari sur iPhone', ip: '78.234.56.78', lastActive: 'Il y a 2 heures', current: false },
                  { id: '3', device: 'Firefox sur Android', ip: '45.123.45.67', lastActive: 'Il y a 1 jour', current: false },
                ].map((session) => (
                  <div
                    key={session.id}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '12px 16px',
                      background: session.current ? C.greenL : (session.id === '1' ? C.surface2 : 'transparent'),
                      borderRadius: 8,
                      marginBottom: 4,
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Smartphone size={14} color={session.current ? C.green : C.text3} />
                        <span style={{ fontSize: 13, fontWeight: session.current ? 600 : 400, color: C.text }}>
                          {session.device}
                          {session.current && (
                            <span style={{
                              marginLeft: 8,
                              padding: '2px 6px',
                              background: C.greenL,
                              color: C.green,
                              borderRadius: 4,
                              fontSize: 9,
                            }}>
                              Actuelle
                            </span>
                          )}
                        </span>
                      </div>
                      <div style={{ fontSize: 11, color: C.text3, marginTop: 2 }}>
                        IP: {session.ip} · Dernière activité: {session.lastActive}
                      </div>
                    </div>
                    {!session.current && (
                      <button
                        onClick={() => handleRevokeSession(session.id)}
                        style={{
                          padding: '4px 8px',
                          borderRadius: 4,
                          border: `1px solid ${C.red}`,
                          background: 'transparent',
                          color: C.red,
                          fontSize: 11,
                          cursor: 'pointer',
                        }}
                      >
                        Révoquer
                      </button>
                    )}
                  </div>
                ))}
              </div>*/}
            </div>
          </div>
        )}

        {/* -------------------------------------------------- */}
        {/* TAB 3 : PRÉFÉRENCES */}
        {/* -------------------------------------------------- */}
        {activeTab === 'preferences' && (
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 14,
            padding: 24,
          }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 20 }}>
              Préférences utilisateur
            </h2>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
              
              {/* ============================================ */}
              {/* APPARENCE (THÈME) */}
              {/* ============================================ */}
              <div style={{
                padding: 16,
                background: C.surface2,
                borderRadius: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <Moon size={16} color={C.purple} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>Apparence</span>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    onClick={() => setPreferences({ ...preferences, darkMode: false })}
                    style={{
                      flex: 1,
                      padding: '8px',
                      borderRadius: 6,
                      border: preferences.darkMode ? `1px solid ${C.border}` : 'none',
                      background: !preferences.darkMode ? C.green : 'transparent',
                      color: !preferences.darkMode ? 'white' : C.text2,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 4,
                    }}
                  >
                    <Sun size={14} />
                    Clair
                  </button>
                  <button
                    onClick={() => setPreferences({ ...preferences, darkMode: true })}
                    style={{
                      flex: 1,
                      padding: '8px',
                      borderRadius: 6,
                      border: !preferences.darkMode ? `1px solid ${C.border}` : 'none',
                      background: preferences.darkMode ? C.green : 'transparent',
                      color: preferences.darkMode ? 'white' : C.text2,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 4,
                    }}
                  >
                    <Moon size={14} />
                    Sombre
                  </button>
                </div>
              </div>

              {/* ============================================ */}
              {/* LANGUE ET FUSEAU HORAIRE */}
              {/* ============================================ */}
              <div style={{
                padding: 16,
                background: C.surface2,
                borderRadius: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <Globe size={16} color={C.blue} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>Langue & région</span>
                </div>
                <select
                  value={preferences.language}
                  onChange={(e) => setPreferences({ ...preferences, language: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '8px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface,
                    color: C.text,
                    fontSize: 12,
                    marginBottom: 8,
                  }}
                >
                  <option value="fr">Français</option>
                  <option value="en">English</option>
                  <option value="es">Español</option>
                </select>
                <select
                  value={preferences.timezone}
                  onChange={(e) => setPreferences({ ...preferences, timezone: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '8px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface,
                    color: C.text,
                    fontSize: 12,
                  }}
                >
                  <option value="Europe/Paris">Europe/Paris (UTC+1)</option>
                  <option value="Europe/London">Europe/London (UTC+0)</option>
                  <option value="America/New_York">America/New_York (UTC-5)</option>
                </select>
              </div>

              {/* ============================================ */}
              {/* NOTIFICATIONS */}
              {/* ============================================ */}
              <div style={{
                padding: 16,
                background: C.surface2,
                borderRadius: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <Bell size={16} color={C.amber} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>Notifications</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <input
                      type="checkbox"
                      checked={preferences.emailNotifications}
                      onChange={(e) => setPreferences({ ...preferences, emailNotifications: e.target.checked })}
                    />
                    <span style={{ fontSize: 12, color: C.text2 }}>Notifications par email</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <input
                      type="checkbox"
                      checked={preferences.pushNotifications}
                      onChange={(e) => setPreferences({ ...preferences, pushNotifications: e.target.checked })}
                    />
                    <span style={{ fontSize: 12, color: C.text2 }}>Notifications push</span>
                  </label>
                </div>
              </div>

              {/* ============================================ */}
              {/* RAFRAÎCHISSEMENT AUTOMATIQUE */}
              {/* ============================================ */}
              <div style={{
                padding: 16,
                background: C.surface2,
                borderRadius: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <RefreshCw size={16} color={C.green} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>Rafraîchissement auto</span>
                </div>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <input
                    type="checkbox"
                    checked={preferences.autoRefresh}
                    onChange={(e) => setPreferences({ ...preferences, autoRefresh: e.target.checked })}
                  />
                  <span style={{ fontSize: 12, color: C.text2 }}>Activer le rafraîchissement automatique</span>
                </label>
                <select
                  value={preferences.refreshInterval}
                  onChange={(e) => setPreferences({ ...preferences, refreshInterval: Number(e.target.value) })}
                  disabled={!preferences.autoRefresh}
                  style={{
                    width: '100%',
                    padding: '8px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface,
                    color: C.text,
                    fontSize: 12,
                    opacity: preferences.autoRefresh ? 1 : 0.5,
                  }}
                >
                  <option value={15}>15 secondes</option>
                  <option value={30}>30 secondes</option>
                  <option value={60}>1 minute</option>
                  <option value={300}>5 minutes</option>
                </select>
              </div>
            </div>

            {/* ================================================ */}
            {/* BOUTON DE SAUVEGARDE DES PRÉFÉRENCES */}
            {/* ================================================ */}
            <div style={{ marginTop: 20, textAlign: 'right' }}>
              <button
                onClick={handleSavePreferences}
                disabled={loading}
                style={{
                  padding: '8px 24px',
                  borderRadius: 8,
                  border: 'none',
                  background: C.green,
                  color: 'white',
                  fontSize: 13,
                  cursor: loading ? 'wait' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                  marginLeft: 'auto',
                }}
              >
                {loading ? <Loader size={14} className="spin" /> : <Save size={14} />}
                Sauvegarder les préférences
              </button>
            </div>
          </div>
        )}

        {/* -------------------------------------------------- */}
        {/* TAB 4 : JOURNAL D'ACTIVITÉ */}
        {/* -------------------------------------------------- */}
       {/* {activeTab === 'activity' && (
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 14,
            padding: 24,
          }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 20 }}>
              Journal d'activité
            </h2>

            {loadingActivity ? (
              <div style={{ textAlign: 'center', padding: 40 }}>
                <Loader size={32} className="spin" color={C.green} />
              </div>
            ) : (
              <> 

                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={{ borderBottom: `2px solid ${C.border}` }}>
                        <th style={{ textAlign: 'left', padding: '12px 8px' }}>Action</th>
                        <th style={{ textAlign: 'left', padding: '12px 8px' }}>Date</th>
                        <th style={{ textAlign: 'left', padding: '12px 8px' }}>IP</th>
                        <th style={{ textAlign: 'left', padding: '12px 8px' }}>Appareil</th>
                        <th style={{ textAlign: 'left', padding: '12px 8px' }}>Statut</th>
                      </tr>
                    </thead>
                    <tbody>
                      {activityLog.length === 0 ? (
                        <tr>
                          <td colSpan={5} style={{ padding: 40, textAlign: 'center', color: C.text3 }}>
                            Aucune activité récente
                          </td>
                        </tr>
                      ) : (
                        activityLog.map((log) => (
                          <tr key={log.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                            <td style={{ padding: '12px 8px' }}>{log.action}</td>
                            <td style={{ padding: '12px 8px', fontSize: 12 }}>{log.timestamp}</td>
                            <td style={{ padding: '12px 8px', fontFamily: 'monospace', fontSize: 11 }}>{log.ip}</td>
                            <td style={{ padding: '12px 8px', fontSize: 12 }}>{log.device}</td>
                            <td style={{ padding: '12px 8px' }}>
                              <span style={{
                                padding: '2px 8px',
                                borderRadius: 99,
                                fontSize: 11,
                                background: log.status === 'success' ? C.greenL :
                                           log.status === 'warning' ? C.amberL : C.redL,
                                color: log.status === 'success' ? C.green :
                                       log.status === 'warning' ? C.amber : C.red,
                              }}>
                                {log.status === 'success' && 'Succès'}
                                {log.status === 'warning' && 'Attention'}
                                {log.status === 'error' && 'Erreur'}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                <div style={{ marginTop: 20, textAlign: 'center' }}>
                  <button
                    onClick={() => setLoadingActivity(!loadingActivity)}
                    style={{
                      padding: '8px 16px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: 'transparent',
                      color: C.text2,
                      fontSize: 12,
                      cursor: 'pointer',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6,
                    }}
                  >
                    <RefreshCw size={14} />
                    Rafraîchir
                  </button>
                </div>
              </>
            )}
          </div>
        )}*/}

        {/* -------------------------------------------------- */}
        {/* TAB 5 : CLÉS API */}
        {/* -------------------------------------------------- */}
        {activeTab === 'api' && (
          <div style={{
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 14,
            padding: 24,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text }}>
                Clés API
              </h2>
              <button
                onClick={handleGenerateApiKey}
                disabled={loadingKeys}
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  border: 'none',
                  background: C.green,
                  color: 'white',
                  fontSize: 13,
                  cursor: loadingKeys ? 'wait' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  opacity: loadingKeys ? 0.7 : 1,
                }}
              >
                {loadingKeys ? <Loader size={14} className="spin" /> : <Key size={16} />}
                Générer une clé
              </button>
            </div>

            {loadingKeys ? (
              <div style={{ textAlign: 'center', padding: 40 }}>
                <Loader size={32} className="spin" color={C.green} />
              </div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ borderBottom: `2px solid ${C.border}` }}>
                      <th style={{ textAlign: 'left', padding: '12px 8px' }}>Nom</th>
                      <th style={{ textAlign: 'left', padding: '12px 8px' }}>Clé</th>
                      <th style={{ textAlign: 'left', padding: '12px 8px' }}>Créée le</th>
                      <th style={{ textAlign: 'left', padding: '12px 8px' }}>Dernière utilisation</th>
                      <th style={{ textAlign: 'left', padding: '12px 8px' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {apiKeys.length === 0 ? (
                      <tr>
                        <td colSpan={5} style={{ padding: 40, textAlign: 'center', color: C.text3 }}>
                          Aucune clé API
                        </td>
                      </tr>
                    ) : (
                      apiKeys.map((key) => (
                        <tr key={key.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                          <td style={{ padding: '12px 8px' }}>{key.name}</td>
                          <td style={{ padding: '12px 8px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                              <code style={{
                                background: C.surface2,
                                padding: '4px 8px',
                                borderRadius: 4,
                                fontSize: 11,
                                fontFamily: 'monospace',
                              }}>
                                {showApiKey ? key.key : `${key.key.slice(0, 8)}...${key.key.slice(-4)}`}
                              </code>
                              <button
                                onClick={() => setShowApiKey(!showApiKey)}
                                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                                title={showApiKey ? 'Masquer' : 'Afficher'}
                              >
                                {showApiKey ? <EyeOff size={14} color={C.text3} /> : <Eye size={14} color={C.text3} />}
                              </button>
                              <button
                                onClick={() => handleCopyKey(key.key)}
                                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                                title="Copier"
                              >
                                {copied ? <Check size={14} color={C.green} /> : <Copy size={14} color={C.text3} />}
                              </button>
                            </div>
                          </td>
                          <td style={{ padding: '12px 8px', fontSize: 12 }}>{key.created}</td>
                          <td style={{ padding: '12px 8px', fontSize: 12 }}>{key.lastUsed}</td>
                          <td style={{ padding: '12px 8px' }}>
                            <button
                              onClick={() => handleRevokeApiKey(key.id)}
                              style={{
                                padding: '4px 8px',
                                borderRadius: 4,
                                border: `1px solid ${C.red}`,
                                background: 'transparent',
                                color: C.red,
                                fontSize: 11,
                                cursor: 'pointer',
                              }}
                            >
                              Révoquer
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* ================================================ */}
            {/* CONSEILS DE SÉCURITÉ */}
            {/* ================================================ */}
            <div style={{ marginTop: 20, background: C.blueL, borderRadius: 8, padding: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                <AlertCircle size={14} color={C.blue} />
                <span style={{ fontSize: 11, fontWeight: 600, color: C.blue }}>Bonnes pratiques</span>
              </div>
              <p style={{ fontSize: 11, color: C.text2, marginLeft: 22 }}>
                Ne partagez jamais vos clés API. Utilisez des clés différentes pour le développement et la production.
                Régénérez régulièrement vos clés pour plus de sécurité.
              </p>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}