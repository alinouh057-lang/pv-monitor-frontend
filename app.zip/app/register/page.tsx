// frontend/app/register/page.tsx
'use client';

/**
 * ============================================================
 * PAGE D'INSCRIPTION - PV MONITOR
 * ============================================================
 * Cette page gère l'inscription en 3 étapes :
 * 
 * ÉTAPE 1 - EMAIL : Saisie de l'email et envoi du code de vérification
 * ÉTAPE 2 - CODE : Vérification du code à 6 chiffres reçu par email
 * ÉTAPE 3 - MOT DE PASSE : Création du compte avec nom et mot de passe
 * 
 * Le flux complet :
 * 1. L'utilisateur entre son email → envoi d'un code
 * 2. L'utilisateur entre le code reçu → vérification
 * 3. L'utilisateur crée son compte (nom + mot de passe) → redirection vers le dashboard
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  UserPlus, Mail, Lock, User, AlertCircle, CheckCircle, 
  Eye, EyeOff, Loader, ArrowLeft, Send, KeyRound 
} from 'lucide-react';
import { sendVerificationCode, verifyCode, completeRegistration } from '@/lib/api';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// TYPES
// ============================================================

/**
 * Les 3 étapes du processus d'inscription
 */
type Step = 'email' | 'code' | 'password';

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function RegisterPage() {
  // ==========================================================
  // ÉTAT DE L'ÉTAPE COURANTE
  // ==========================================================
  const [step, setStep] = useState<Step>('email');
  
  // ==========================================================
  // ÉTATS - ÉTAPE 1 : EMAIL
  // ==========================================================
  const [email, setEmail] = useState('');
  
  // ==========================================================
  // ÉTATS - ÉTAPE 2 : CODE DE VÉRIFICATION
  // ==========================================================
  const [code, setCode] = useState(['', '', '', '', '', '']); // Code à 6 chiffres
  const [countdown, setCountdown] = useState(60);             // Compte à rebours (60s)
  const [canResend, setCanResend] = useState(false);          // Peut-on renvoyer le code ?
  
  // ==========================================================
  // ÉTATS - ÉTAPE 3 : MOT DE PASSE
  // ==========================================================
  const [name, setName] = useState('');                        // Nom complet
  const [password, setPassword] = useState('');                // Mot de passe
  const [confirmPassword, setConfirmPassword] = useState('');  // Confirmation
  const [showPassword, setShowPassword] = useState(false);     // Afficher/masquer le mot de passe
  
  // ==========================================================
  // ÉTATS COMMUNS
  // ==========================================================
  const [loading, setLoading] = useState(false);               // État de chargement
  const [error, setError] = useState('');                       // Message d'erreur
  const [success, setSuccess] = useState(false);                // Succès (compte créé)
  const [tempToken, setTempToken] = useState('');               // Token temporaire (après vérification)
  
  // ==========================================================
  // HOOKS ET RÉFÉRENCES
  // ==========================================================
  const router = useRouter();
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);   // Références pour les inputs du code

  // ==========================================================
  // EFFETS DE BORD
  // ==========================================================

  /**
   * Gestion du compte à rebours pour le renvoi du code
   * Décrémente countdown chaque seconde, active canResend quand countdown atteint 0
   */
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'code' && countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    } else if (countdown === 0) {
      setCanResend(true);
    }
    return () => clearTimeout(timer);
  }, [step, countdown]);

  // ============================================================
  // FONCTIONS - ÉTAPE 1 : ENVOI DU CODE
  // ============================================================

  /**
   * Envoie le code de vérification à l'email saisi
   * - Valide le format de l'email
   * - Appelle l'API sendVerificationCode
   * - Passe à l'étape 2 si succès
   */
  const handleSendCode = async () => {
    // Validation : champ non vide
    if (!email) {
      setError('Veuillez entrer votre email');
      return;
    }
    
    // Validation : format email valide
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Format d\'email invalide');
      return;
    }
    
    setLoading(true);
    setError('');
    
    console.log('📤 Envoi du code pour:', email);  // Log de debug
    
    try {
      const result = await sendVerificationCode(email);
      console.log('📥 Résultat:', result);  // Log de debug
      
      if (result) {
        // Passage à l'étape 2 (code)
        setStep('code');
        setCountdown(60);
        setCanResend(false);
        setError('');
      } else {
        setError('Erreur lors de l\'envoi du code');
      }
    } catch (err) {
      console.error('❌ Exception:', err);
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // FONCTIONS - ÉTAPE 2 : VÉRIFICATION DU CODE
  // ============================================================

  /**
   * Gère la saisie dans les champs du code
   * - Limite à 1 caractère par champ
   * - Auto-focus sur le champ suivant
   */
  const handleCodeChange = (index: number, value: string) => {
    // Limiter à 1 caractère
    if (value.length > 1) value = value[0];
    // Accepter uniquement les chiffres
    if (!/^\d*$/.test(value)) return;
    
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);
    
    // Auto-focus sur le champ suivant
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  /**
   * Gère les touches du clavier pour les champs du code
   * - Retour arrière : focus sur le champ précédent
   */
  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  /**
   * Vérifie le code saisi
   * - Vérifie que le code fait 6 chiffres
   * - Appelle l'API verifyCode
   * - Passe à l'étape 3 si succès
   */
  const handleVerifyCode = async () => {
    const fullCode = code.join('');
    if (fullCode.length !== 6) {
      setError('Veuillez entrer le code à 6 chiffres');
      return;
    }
    
    setLoading(true);
    setError('');
    
    console.log('📤 Vérification du code pour:', email, fullCode);  // Log de debug
    
    try {
      const result = await verifyCode(email, fullCode);
      console.log('📥 Résultat vérification:', result);  // Log de debug
      
      if (result?.verified) {
        setTempToken(result.temp_token || '');
        setStep('password');
      } else {
        setError('Code invalide');
        // Réinitialiser les champs et remettre le focus sur le premier
        setCode(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      }
    } catch (err) {
      console.error('❌ Exception:', err);
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Renvoie un nouveau code
   * - Réactive le compte à rebours
   * - Réinitialise les champs
   */
  const handleResendCode = async () => {
    if (!canResend) return;
    
    setLoading(true);
    setError('');
    
    try {
      const result = await sendVerificationCode(email);
      if (result) {
        setCountdown(60);
        setCanResend(false);
        setCode(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      } else {
        setError('Erreur lors du renvoi');
      }
    } catch (err) {
      setError('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // FONCTIONS - ÉTAPE 3 : CRÉATION DU COMPTE
  // ============================================================

  /**
   * Finalise l'inscription
   * - Valide le nom et le mot de passe
   * - Appelle l'API completeRegistration
   * - Redirige vers le dashboard si succès
   */
  const handleCompleteRegistration = async () => {
    // Validation : nom requis
    if (!name) {
      setError('Veuillez entrer votre nom');
      return;
    }
    
    // Validation : mot de passe requis
    if (!password) {
      setError('Veuillez entrer un mot de passe');
      return;
    }
    
    // Validation : longueur minimale
    if (password.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }
    
    // Validation : confirmation correspondante
    if (password !== confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }
    
    setLoading(true);
    setError('');
    
    const fullCode = code.join('');
    console.log('📤 Création du compte pour:', email, name);  // Log de debug
    
    try {
      const result = await completeRegistration(email, fullCode, name, password, tempToken);
      console.log('📥 Résultat création:', result);  // Log de debug
      
      if (result) {
        setSuccess(true);
        // Redirection après 2 secondes
        setTimeout(() => {
          router.push('/');
        }, 2000);
      } else {
        setError('Erreur lors de la création du compte');
      }
    } catch (err) {
      console.error('❌ Exception:', err);
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // FONCTIONS DE NAVIGATION
  // ============================================================

  /**
   * Retour à l'étape précédente
   */
  const goBack = () => {
    if (step === 'code') {
      setStep('email');
      setCode(['', '', '', '', '', '']);
    } else if (step === 'password') {
      setStep('code');
      setName('');
      setPassword('');
      setConfirmPassword('');
    }
    setError('');
  };

  // ============================================================
  // RENDU DU COMPOSANT
  // ============================================================
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: `linear-gradient(135deg, ${C.green}10 0%, ${C.surface2} 100%)`,
      padding: '20px',
    }}>
      <div style={{ maxWidth: 400, width: '100%' }}>
        
        {/* ================================================== */}
        {/* LOGO ET TITRE */}
        {/* ================================================== */}
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <div style={{
            width: 70,
            height: 70,
            background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
            borderRadius: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 15px',
            boxShadow: `0 10px 20px ${C.green}30`,
          }}>
            {/* Icône change selon l'étape */}
            {step === 'email' && <Mail size={40} color="white" />}
            {step === 'code' && <KeyRound size={40} color="white" />}
            {step === 'password' && <UserPlus size={40} color="white" />}
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, color: C.text }}>
            {step === 'email' && 'Créer un compte'}
            {step === 'code' && 'Vérification'}
            {step === 'password' && 'Finaliser'}
          </h1>
          <p style={{ fontSize: 14, color: C.text2, marginTop: 5 }}>
            {step === 'email' && 'Entrez votre email pour commencer'}
            {step === 'code' && `Un code a été envoyé à ${email}`}
            {step === 'password' && 'Choisissez vos identifiants'}
          </p>
        </div>

        {/* ================================================== */}
        {/* CARTE PRINCIPALE */}
        {/* ================================================== */}
        <div style={{
          background: C.surface,
          borderRadius: 20,
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
          padding: 30,
          border: `1px solid ${C.border}`,
        }}>
          
          {/* ================================================ */}
          {/* ÉTAT DE SUCCÈS (COMPTE CRÉÉ) */}
          {/* ================================================ */}
          {success ? (
            <div style={{
              padding: '40px 20px',
              textAlign: 'center',
            }}>
              <CheckCircle size={60} color={C.green} style={{ marginBottom: 20 }} />
              <h2 style={{ fontSize: 20, fontWeight: 600, color: C.green, marginBottom: 10 }}>
                Compte créé !
              </h2>
              <p style={{ color: C.text2, marginBottom: 20 }}>
                Vous allez être redirigé...
              </p>
            </div>
          ) : (
            <>
              {/* ============================================ */}
              {/* BOUTON RETOUR (sauf étape 1) */}
              {/* ============================================ */}
              {step !== 'email' && (
                <button
                  onClick={goBack}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    border: 'none',
                    background: 'none',
                    color: C.text2,
                    fontSize: 12,
                    marginBottom: 20,
                    cursor: 'pointer',
                    padding: 0,
                  }}
                >
                  <ArrowLeft size={14} />
                  Retour
                </button>
              )}

              {/* ============================================ */}
              {/* MESSAGE D'ERREUR */}
              {/* ============================================ */}
              {error && (
                <div style={{
                  marginBottom: 20,
                  padding: '12px',
                  background: C.redL,
                  color: C.red,
                  borderRadius: 8,
                  fontSize: 13,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                }}>
                  <AlertCircle size={16} />
                  {error}
                </div>
              )}

              {/* ============================================ */}
              {/* ÉTAPE 1 : SAISIE DE L'EMAIL */}
              {/* ============================================ */}
              {step === 'email' && (
                <div>
                  <div style={{ marginBottom: 20 }}>
                    <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
                      Adresse email
                    </label>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '12px',
                      background: C.surface2,
                      borderRadius: 10,
                      border: `1px solid ${C.border}`,
                    }}>
                      <Mail size={18} color={C.text3} />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="exemple@email.com"
                        style={{
                          flex: 1,
                          border: 'none',
                          background: 'transparent',
                          outline: 'none',
                          fontSize: 14,
                          color: C.text,
                        }}
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleSendCode}
                    disabled={loading}
                    style={{
                      width: '100%',
                      padding: '14px',
                      borderRadius: 10,
                      border: 'none',
                      background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
                      color: 'white',
                      fontSize: 14,
                      fontWeight: 600,
                      cursor: loading ? 'wait' : 'pointer',
                      opacity: loading ? 0.7 : 1,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 8,
                    }}
                  >
                    {loading ? <Loader size={18} className="spin" /> : <Send size={18} />}
                    {loading ? 'Envoi...' : 'Envoyer le code'}
                  </button>
                </div>
              )}

              {/* ============================================ */}
              {/* ÉTAPE 2 : SAISIE DU CODE DE VÉRIFICATION */}
              {/* ============================================ */}
              {step === 'code' && (
                <div>
                  <p style={{ fontSize: 13, color: C.text2, marginBottom: 20, textAlign: 'center' }}>
                    Entrez le code à 6 chiffres reçu par email
                  </p>

                  {/* Champs pour le code à 6 chiffres */}
                  <div style={{
                    display: 'flex',
                    gap: 8,
                    justifyContent: 'center',
                    marginBottom: 20,
                  }}>
                    {code.map((digit, index) => (
                      <input
                        key={index}
                        ref={el => { inputRefs.current[index] = el; }}
                        type="text"
                        value={digit}
                        onChange={(e) => handleCodeChange(index, e.target.value)}
                        onKeyDown={(e) => handleKeyDown(index, e)}
                        style={{
                          width: 45,
                          height: 45,
                          textAlign: 'center',
                          fontSize: 20,
                          fontWeight: 600,
                          borderRadius: 8,
                          border: `1px solid ${C.border}`,
                          background: digit ? C.greenL : C.surface2,
                        }}
                      />
                    ))}
                  </div>

                  <button
                    onClick={handleVerifyCode}
                    disabled={loading || code.join('').length !== 6}
                    style={{
                      width: '100%',
                      padding: '14px',
                      borderRadius: 10,
                      border: 'none',
                      background: code.join('').length === 6 ? C.green : C.surface2,
                      color: code.join('').length === 6 ? 'white' : C.text2,
                      fontSize: 14,
                      fontWeight: 600,
                      cursor: loading || code.join('').length !== 6 ? 'not-allowed' : 'pointer',
                      opacity: loading ? 0.7 : 1,
                      marginBottom: 15,
                    }}
                  >
                    {loading ? <Loader size={18} className="spin" /> : 'Vérifier le code'}
                  </button>

                  {/* Compte à rebours et bouton de renvoi */}
                  <div style={{ textAlign: 'center' }}>
                    {canResend ? (
                      <button
                        onClick={handleResendCode}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: C.green,
                          fontSize: 12,
                          cursor: 'pointer',
                          textDecoration: 'underline',
                        }}
                      >
                        Renvoyer le code
                      </button>
                    ) : (
                      <span style={{ fontSize: 12, color: C.text3 }}>
                        Code valide pendant {countdown} secondes
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* ============================================ */}
              {/* ÉTAPE 3 : CRÉATION DU COMPTE (MOT DE PASSE) */}
              {/* ============================================ */}
              {step === 'password' && (
                <div>
                  {/* Champ : Nom complet */}
                  <div style={{ marginBottom: 20 }}>
                    <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
                      Nom complet
                    </label>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '12px',
                      background: C.surface2,
                      borderRadius: 10,
                      border: `1px solid ${C.border}`,
                    }}>
                      <User size={18} color={C.text3} />
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Jean Dupont"
                        style={{
                          flex: 1,
                          border: 'none',
                          background: 'transparent',
                          outline: 'none',
                          fontSize: 14,
                          color: C.text,
                        }}
                      />
                    </div>
                  </div>

                  {/* Champ : Mot de passe */}
                  <div style={{ marginBottom: 20 }}>
                    <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
                      Mot de passe
                    </label>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '12px',
                      background: C.surface2,
                      borderRadius: 10,
                      border: `1px solid ${C.border}`,
                    }}>
                      <Lock size={18} color={C.text3} />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        style={{
                          flex: 1,
                          border: 'none',
                          background: 'transparent',
                          outline: 'none',
                          fontSize: 14,
                          color: C.text,
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                      >
                        {showPassword ? <EyeOff size={18} color={C.text3} /> : <Eye size={18} color={C.text3} />}
                      </button>
                    </div>
                  </div>

                  {/* Champ : Confirmation du mot de passe */}
                  <div style={{ marginBottom: 20 }}>
                    <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
                      Confirmer le mot de passe
                    </label>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '12px',
                      background: C.surface2,
                      borderRadius: 10,
                      border: `1px solid ${C.border}`,
                    }}>
                      <Lock size={18} color={C.text3} />
                      <input
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        style={{
                          flex: 1,
                          border: 'none',
                          background: 'transparent',
                          outline: 'none',
                          fontSize: 14,
                          color: C.text,
                        }}
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleCompleteRegistration}
                    disabled={loading}
                    style={{
                      width: '100%',
                      padding: '14px',
                      borderRadius: 10,
                      border: 'none',
                      background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
                      color: 'white',
                      fontSize: 14,
                      fontWeight: 600,
                      cursor: loading ? 'wait' : 'pointer',
                      opacity: loading ? 0.7 : 1,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 8,
                    }}
                  >
                    {loading ? <Loader size={18} className="spin" /> : <UserPlus size={18} />}
                    {loading ? 'Création...' : 'Créer mon compte'}
                  </button>
                </div>
              )}

              {/* ============================================ */}
              {/* LIEN VERS LA PAGE DE CONNEXION */}
              {/* ============================================ */}
              {step === 'email' && (
                <p style={{
                  marginTop: 20,
                  fontSize: 12,
                  color: C.text3,
                  textAlign: 'center',
                }}>
                  Déjà un compte ?{' '}
                  <Link href="/login" style={{ color: C.green, textDecoration: 'none', fontWeight: 600 }}>
                    Se connecter
                  </Link>
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}