// app/forgot-password/page.tsx
'use client';

/**
 * ============================================================
 * PAGE MOT DE PASSE OUBLIÉ - PV MONITOR
 * ============================================================
 * Cette page permet aux utilisateurs de demander un lien de
 * réinitialisation de mot de passe.
 * 
 * Fonctionnalités :
 * - Formulaire de saisie d'email
 * - Validation du format email
 * - Appel API pour envoyer la demande
 * - Message de succès avec instructions
 * - Gestion des erreurs
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState } from 'react';
import Link from 'next/link';
import { Mail, ArrowLeft, Send, AlertCircle, CheckCircle, Loader } from 'lucide-react';
import { forgotPassword } from '@/lib/api';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function ForgotPasswordPage() {
  // ==========================================================
  // ÉTATS
  // ==========================================================
  const [email, setEmail] = useState('');           // Email saisi par l'utilisateur
  const [loading, setLoading] = useState(false);    // État de chargement
  const [error, setError] = useState('');            // Message d'erreur
  const [success, setSuccess] = useState(false);     // État de succès (email envoyé)

  // ==========================================================
  // VALIDATION DE L'EMAIL
  // ==========================================================
  
  /**
   * Expression régulière pour valider le format d'un email
   * Vérifie la présence d'un @ et d'un point après le @
   */
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // ==========================================================
  // GESTION DE LA SOUMISSION DU FORMULAIRE
  // ==========================================================
  
  /**
   * Traite la soumission du formulaire
   * - Valide l'email
   * - Envoie la demande au serveur
   * - Affiche le résultat (succès/erreur)
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Réinitialisation des messages
    setError('');
    
    // ========================================================
    // VALIDATION DU CHAMP EMAIL
    // ========================================================
    
    // Vérification que l'email n'est pas vide
    if (!email) {
      setError('Veuillez entrer votre email');
      return;
    }

    // Vérification du format de l'email
    if (!emailRegex.test(email)) {
      setError('Format d\'email invalide');
      return;
    }

    // ========================================================
    // ENVOI DE LA DEMANDE AU SERVEUR
    // ========================================================
    
    setLoading(true);

    try {
      // Appel à l'API pour demander la réinitialisation
      const result = await forgotPassword(email);
      
      if (result) {
        // Succès : affichage du message de confirmation
        setSuccess(true);
      } else {
        // Échec : message d'erreur générique
        setError('Erreur lors de la demande');
      }
    } catch (err) {
      // Erreur réseau / serveur
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: `linear-gradient(135deg, ${C.green}10 0%, ${C.surface2} 100%)`,
      padding: '20px',
    }}>
      <div style={{ maxWidth: 400, width: '100%' }}>
        
        {/* ================================================== */}
        {/* LOGO ET TITRE */}
        {/* ================================================== */}
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <div style={{
            width: 70,
            height: 70,
            background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
            borderRadius: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 15px',
            boxShadow: `0 10px 20px ${C.green}30`,
          }}>
            <Mail size={40} color="white" />
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, color: C.text }}>
            Mot de passe oublié ?
          </h1>
          <p style={{ fontSize: 14, color: C.text2, marginTop: 5 }}>
            Entrez votre email pour recevoir un lien de réinitialisation
          </p>
        </div>

        {/* ================================================== */}
        {/* CARTE PRINCIPALE */}
        {/* ================================================== */}
        <div style={{
          background: C.surface,
          borderRadius: 20,
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
          padding: 30,
          border: `1px solid ${C.border}`,
        }}>
          
          {/* ================================================ */}
          {/* AFFICHAGE CONDITIONNEL : SUCCÈS OU FORMULAIRE */}
          {/* ================================================ */}
          
          {success ? (
            /* -------------------------------------------------- */
            /* ÉTAT DE SUCCÈS : EMAIL ENVOYÉ */
            /* -------------------------------------------------- */
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <CheckCircle size={60} color={C.green} style={{ marginBottom: 20 }} />
              <h2 style={{ fontSize: 20, fontWeight: 600, color: C.green, marginBottom: 15 }}>
                Email envoyé !
              </h2>
              <p style={{ color: C.text2, marginBottom: 10 }}>
                Si un compte existe avec l'adresse <strong>{email}</strong>,
                vous recevrez un email avec les instructions.
              </p>
              <p style={{ color: C.text3, fontSize: 13, marginTop: 20 }}>
                Le lien expirera dans 30 minutes.
              </p>
              <Link href="/login" style={{
                display: 'inline-block',
                marginTop: 20,
                color: C.green,
                textDecoration: 'none',
                fontWeight: 600,
              }}>
                Retour à la connexion
              </Link>
            </div>
          ) : (
            /* -------------------------------------------------- */
            /* FORMULAIRE DE DEMANDE DE RÉINITIALISATION */
            /* -------------------------------------------------- */
            <form onSubmit={handleSubmit}>
              
              {/* AFFICHAGE DES ERREURS */}
              {error && (
                <div style={{
                  marginBottom: 20,
                  padding: '12px',
                  background: C.redL,
                  color: C.red,
                  borderRadius: 8,
                  fontSize: 13,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                }}>
                  <AlertCircle size={16} />
                  {error}
                </div>
              )}

              {/* ============================================== */}
              {/* CHAMP EMAIL */}
              {/* ============================================== */}
              <div style={{ marginBottom: 20 }}>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 6 }}>
                  Adresse email
                </label>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '12px',
                  background: C.surface2,
                  borderRadius: 10,
                  border: `1px solid ${C.border}`,
                }}>
                  <Mail size={18} color={C.text3} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="exemple@email.com"
                    style={{
                      flex: 1,
                      border: 'none',
                      background: 'transparent',
                      outline: 'none',
                      fontSize: 14,
                      color: C.text,
                    }}
                  />
                </div>
              </div>

              {/* ============================================== */}
              {/* BOUTON D'ENVOI */}
              {/* ============================================== */}
              <button
                type="submit"
                disabled={loading}
                style={{
                  width: '100%',
                  padding: '14px',
                  borderRadius: 10,
                  border: 'none',
                  background: `linear-gradient(135deg, ${C.green}, ${C.green}DD)`,
                  color: 'white',
                  fontSize: 14,
                  fontWeight: 600,
                  cursor: loading ? 'wait' : 'pointer',
                  opacity: loading ? 0.7 : 1,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                  marginBottom: 20,
                }}
              >
                {loading ? <Loader size={18} className="spin" /> : <Send size={18} />}
                {loading ? 'Envoi...' : 'Envoyer le lien'}
              </button>

              {/* ============================================== */}
              {/* LIEN DE RETOUR */}
              {/* ============================================== */}
              <Link href="/login" style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 4,
                color: C.text2,
                textDecoration: 'none',
                fontSize: 13,
              }}>
                <ArrowLeft size={14} />
                Retour à la connexion
              </Link>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}