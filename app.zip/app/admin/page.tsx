'use client';

/**
 * ============================================================
 * PAGE D'ADMINISTRATION - PV MONITOR
 * ============================================================
 * Cette page permet de gérer :
 * - La configuration générale (seuils d'alerte, nettoyage)
 * - Les dispositifs ESP32 (ajout, modification, suppression)
 * - Les utilisateurs (gestion des comptes)
 * - La configuration email (notifications)
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import { useState, useEffect } from 'react';
import {
  getAdminConfig, updateConfig, fetchDevices, addDevice, updateDevice, deleteDevice,
  getEmailConfig, updateEmailConfig, testEmail, fetchUsers,
  addUser, updateUser, deleteUser, exportConfig, importConfig,
  deleteAllData, deleteOldData, getPanelConfig, updatePanelConfig,  // ← AJOUTER
  type Device, type User
} from '@/lib/api';
import { useDevice } from '@/contexts/DeviceContext';

// Icônes Lucide pour l'interface utilisateur
import { 
  Settings, Smartphone, Users, Mail,MapPin,
  Plus, Edit, Trash2, Save, RefreshCw,
  Loader, Check, X, AlertCircle, AlertTriangle, CheckCircle,
  MailCheck, Wrench, Clock, Calendar,
  User as UserIcon,
  UserPlus, Shield, Eye, Info, PlusCircle,
  Download, Upload, XCircle,
  Database, HardDrive, Activity, Bell,  // ← AJOUTE CES ICÔNES
  Radio, CalendarDays, Sliders,          // ← AJOUTE CES ICÔNES
  Layers, Archive, Filter, Sun, PanelTop                 // ← AJOUTE CES ICÔNES
} from 'lucide-react';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

// Type pour les onglets de la page d'administration
type TabType = 'general' | 'devices' | 'panels'| 'email' | 'users' ;

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function AdminPage() {
  // ==========================================================
  // ÉTATS GLOBAUX
  // ==========================================================
  const [activeTab, setActiveTab] = useState<TabType>('general'); // Onglet actif
  const [loading, setLoading] = useState(false);                  // État de chargement global
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null); // Messages utilisateur

  // ==========================================================
  // ÉTATS - CONFIGURATION GÉNÉRALE
  // ==========================================================
  const [config, setConfig] = useState({
    seuil_warning: 30,      // Seuil d'alerte warning (%)
    seuil_critical: 60,     // Seuil d'alerte critical (%)
    retention_days: 7,      // Jours de conservation des images
    cleanup_interval: 24,   // Intervalle de nettoyage (heures)
    latitude: undefined as number | undefined, 
    longitude: undefined as number | undefined,
  });

  // ==========================================================
  // ÉTATS - CONFIGURATION EMAIL
  // ==========================================================
  const [emailConfig, setEmailConfig] = useState({
    email_to: '',           // Email destinataire
    email_from: '',         // Email expéditeur
    smtp_host: 'smtp.gmail.com', // Serveur SMTP
    smtp_port: 587,         // Port SMTP
    has_password: false,    // Indique si un mot de passe est déjà configuré
  });
  const [emailPassword, setEmailPassword] = useState(''); // Mot de passe SMTP (temporaire)
  const [testingEmail, setTestingEmail] = useState(false); // État du test d'envoi

  // ==========================================================
  // ÉTATS - GESTION DES DISPOSITIFS (ESP32)
  // ==========================================================
  const [devices,       setDevices]       = useState<Device[]>([]);           // Liste des dispositifs
  const [showAddDevice, setShowAddDevice] = useState(false);      // Afficher/masquer formulaire
  const [editingDevice, setEditingDevice] = useState<Device | null>(null); // Dispositif en cours d'édition
  const [newDevice,     setNewDevice]     = useState<Partial<Device>>({   // Nouveau dispositif
    device_id: '',
    name: '',
    status: 'active',
    //latitude: undefined,    
   // longitude: undefined,   
   // zone: ''              
  });

  // ==========================================================
  // ÉTATS - GESTION DES UTILISATEURS
  // ==========================================================
  const [users,       setUsers]       = useState<User[]>([]);                 // Liste des utilisateurs
  const [showAddUser, setShowAddUser] = useState(false);          // Afficher/masquer formulaire
  const [editingUser, setEditingUser] = useState<User | null>(null); // Utilisateur en cours d'édition
  const [newUser,     setNewUser]     = useState<Partial<User>>({         // Nouvel utilisateur
    username: '',
    email: '',
    role: 'viewer',
    active: true,
  });


  // ==========================================================
// ÉTATS - SUPPRESSION DES DONNÉES (AJOUTER)
// ==========================================================
const [showDeleteModal,   setShowDeleteModal]   = useState(false);
const [deleteType,        setDeleteType]        = useState<'all' | 'old'>('all');
const [deleteCollection,  setDeleteCollection]  = useState('surveillance');
const [retentionDays,     setRetentionDays]     = useState(30);
const [deleteLoading,     setDeleteLoading]     = useState(false);
const [deleteConfirmText, setDeleteConfirmText] = useState('');


  // ==========================================================
// ÉTATS - CONFIGURATION DES PANNEAUX
// ==========================================================

const [panelConfig, setPanelConfig] = useState({
  panel_type: 'monocristallin',
  panel_capacity_kw: 3.0,
  panel_area_m2: 1.6,
  panel_efficiency: 0.20,
  tilt_angle: 30,
  azimuth: 180,
  degradation_rate: 0.5,
});
const [loadingPanels, setLoadingPanels] = useState(false);

  // ==========================================================
  // EFFETS DE BORD
  // ==========================================================
  
  /**
   * Rafraîchit les données quand la page redevient visible
   * Utile pour avoir des données à jour après un retour sur l'onglet
   */
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log('👁️ Page visible - Rechargement des données');
        loadUsers();
        loadDevices();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  /**
   * Chargement initial des données au montage du composant
   */
  useEffect(() => {
    loadConfig();
    loadDevices();
    loadEmailConfig();
    loadUsers();
    loadPanelConfig(); 
  }, []);

  // ==========================================================
  // FONCTIONS DE CHARGEMENT DES DONNÉES
  // ==========================================================

  /** Charge la configuration générale depuis l'API */
  const loadConfig = async () => {
    const data = await getAdminConfig();
    if (data) {
      setConfig({
        seuil_warning: data.seuil_warning || 30,
        seuil_critical: data.seuil_critical || 60,
        retention_days: data.retention_days || 7,
        cleanup_interval: data.cleanup_interval || 24,
        latitude: data.latitude,
        longitude: data.longitude,
      });
    }
  };

  /** Charge la liste des dispositifs depuis l'API */
  const loadDevices = async () => {
    const data = await fetchDevices();
    setDevices(data);
  };

  /** Charge la configuration email depuis l'API */
  const loadEmailConfig = async () => {
    const data = await getEmailConfig();
    if (data) {
      setEmailConfig({
        email_to: data.email_to || '',
        email_from: data.email_from || '',
        smtp_host: data.smtp_host || 'smtp.gmail.com',
        smtp_port: data.smtp_port || 587,
        has_password: data.has_password || false,
      });
    }
  };

  /** Charge la liste des utilisateurs depuis l'API */
  const loadUsers = async () => {
    const data = await fetchUsers();
    setUsers(data);
  };
/** Charge la configuration des panneaux */
const loadPanelConfig = async () => {
  try {
    const data = await getPanelConfig();
    if (data) {
      setPanelConfig({
        panel_type: data.panel_type || 'monocristallin',
        panel_capacity_kw: data.panel_capacity_kw ?? 3.0,
        panel_area_m2: data.panel_area_m2 ?? 1.6,
        panel_efficiency: data.panel_efficiency ?? 0.20,
        tilt_angle: data.tilt_angle ?? 30,
        azimuth: data.azimuth ?? 180,
        degradation_rate: data.degradation_rate ?? 0.5,
      });
    }
  } catch (error) {
    console.error('❌ Erreur chargement config:', error);
  }
};
/** Sauvegarde la configuration des panneaux */
const handleSavePanelConfig = async () => {
  setLoadingPanels(true);
  try {
    const success = await updatePanelConfig(panelConfig);
    if (success) {
      setMessage({ text: 'Configuration sauvegardée', type: 'success' });
    } else {
      setMessage({ text: 'Erreur lors de la sauvegarde', type: 'error' });
    }
  } catch (error) {
    setMessage({ text: 'Erreur de connexion', type: 'error' });
  } finally {
    setLoadingPanels(false);
    setTimeout(() => setMessage(null), 3000);
  }
};
  // ==========================================================
  // FONCTIONS DE GESTION - CONFIGURATION GÉNÉRALE
  // ==========================================================

  /** Sauvegarde la configuration générale */
  const handleSaveConfig = async () => {
    setLoading(true);
    const success = await updateConfig(config);
    if (success) {
      setMessage({ text: 'Configuration sauvegardée', type: 'success' });
    } else {
      setMessage({ text: 'Erreur lors de la sauvegarde', type: 'error' });
    }
    setLoading(false);
    setTimeout(() => setMessage(null), 3000);
  };

  // ==========================================================
  // FONCTIONS DE GESTION - EMAIL
  // ==========================================================

  /** Sauvegarde la configuration email */
  const handleSaveEmail = async () => {
    setLoading(true);
    const configToSave = {
      email_to: emailConfig.email_to,
      ...(emailConfig.email_from ? { email_from: emailConfig.email_from } : {}),
      ...(emailConfig.smtp_host ? { smtp_host: emailConfig.smtp_host } : {}),
      ...(emailConfig.smtp_port ? { smtp_port: emailConfig.smtp_port } : {}),
      ...(emailPassword ? { smtp_password: emailPassword } : {}),
    };
    const success = await updateEmailConfig(configToSave);
    if (success) {
      setMessage({ text: 'Configuration email sauvegardée', type: 'success' });
      setEmailPassword('');
      await loadEmailConfig();
    } else {
      setMessage({ text: 'Erreur lors de la sauvegarde', type: 'error' });
    }
    setLoading(false);
    setTimeout(() => setMessage(null), 3000);
  };

  /** Teste l'envoi d'email avec la configuration actuelle */
  const handleTestEmail = async () => {
    setTestingEmail(true);
    const success = await testEmail();
    setMessage({ 
      text: success ? 'Email de test envoyé' : 'Échec de l\'envoi', 
      type: success ? 'success' : 'error' 
    });
    setTestingEmail(false);
    setTimeout(() => setMessage(null), 3000);
  };

  // ==========================================================
  // FONCTIONS DE GESTION - DISPOSITIFS (ESP32)
  // ==========================================================

  /** Ajoute un nouveau dispositif */
  const handleAddDevice = async () => {
    // Vérifier que l'ID est présent
    if (!newDevice.device_id || newDevice.device_id.trim() === '') {
      setMessage({ text: 'Veuillez entrer un ID de dispositif', type: 'error' });
      setTimeout(() => setMessage(null), 3000);
      return;
    }
    
    setLoading(true);
    
    const deviceToAdd = {
      device_id: newDevice.device_id.trim(),
      name: newDevice.name?.trim() || newDevice.device_id.trim(),
      status: newDevice.status || 'active',
      //latitude: newDevice.latitude,    
      //longitude: newDevice.longitude,
      //zone: newDevice.zone 
    };
    
    console.log('📤 Ajout device:', deviceToAdd);
    
    const device = await addDevice(deviceToAdd);
    setLoading(false);
    
    if (device) {
      setDevices([...devices, device]);
      setShowAddDevice(false);
      resetNewDevice();
      setMessage({ text: '✅ Dispositif ajouté avec succès', type: 'success' });
    } else {
      setMessage({ text: '❌ Erreur : ID déjà utilisé ou invalide', type: 'error' });
    }
    setTimeout(() => setMessage(null), 3000);
  };

  /** Prépare l'édition d'un dispositif */
  const handleEditDevice = (device: Device) => {
    setEditingDevice(device);
    setNewDevice({
      device_id: device.device_id,
      name: device.name,
      status: device.status,
     //latitude: device.latitude,    
     // longitude: device.longitude,  
      //zone: device.zone            
    });
    setShowAddDevice(true);
  };

  /** Met à jour un dispositif existant */
  const handleUpdateDevice = async () => {
    if (!editingDevice || !newDevice.device_id) return;
    
    setLoading(true);
    const updated = await updateDevice(editingDevice.device_id, newDevice);
    setLoading(false);
    
    if (updated) {
      setDevices(devices.map(d => d.device_id === editingDevice.device_id ? updated : d));
      setShowAddDevice(false);
      setEditingDevice(null);
      resetNewDevice();
      setMessage({ text: 'Dispositif mis à jour avec succès', type: 'success' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  /** Supprime un dispositif */
  const handleDeleteDevice = async (deviceId: string) => {
    if (confirm('Voulez-vous vraiment supprimer ce dispositif ?\nCette action est irréversible.')) {
      setLoading(true);
      const success = await deleteDevice(deviceId);
      setLoading(false);
      
      if (success) {
        setDevices(devices.filter(d => d.device_id !== deviceId));
        setMessage({ text: '✅ Dispositif supprimé avec succès', type: 'success' });
      } else {
        setMessage({ text: '❌ Erreur lors de la suppression', type: 'error' });
      }
      setTimeout(() => setMessage(null), 3000);
    }
  };

  /** Réinitialise le formulaire de dispositif */
  const resetNewDevice = () => {
    setNewDevice({
      device_id: '',
      name: '',
      status: 'active',
     // latitude: newDevice.latitude,   
     // longitude: newDevice.longitude, 
     // zone: newDevice.zone    
    });
  };

  /** Change le statut d'un dispositif */
  const handleDeviceStatusChange = async (deviceId: string, status: string) => {
    console.log('📤 Changement de statut pour:', deviceId, '→', status);
    
    setLoading(true);
    const updated = await updateDevice(deviceId, { status: status as any });
    setLoading(false);
    
    if (updated) {
      setDevices(devices.map(d => d.device_id === deviceId ? updated : d));
      
      const statusMessages = {
        active: '✅ Device activé - Il peut maintenant envoyer des données',
        maintenance: '🔧 Device en maintenance - Envoi bloqué temporairement',
        offline: '📴 Device hors ligne - Envoi bloqué'
      };
      
      setMessage({ 
        text: statusMessages[status as keyof typeof statusMessages] || `Statut mis à jour: ${status}`, 
        type: 'success' 
      });
      setTimeout(() => setMessage(null), 3000);
    } else {
      setMessage({ text: 'Erreur lors de la mise à jour du statut', type: 'error' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  // ==========================================================
  // FONCTIONS DE GESTION - UTILISATEURS
  // ==========================================================

  /** Ajoute un nouvel utilisateur */
  const handleAddUser = async () => {
    if (!newUser.username || !newUser.email) return;
    
    setLoading(true);
    const user = await addUser(newUser);
    setLoading(false);
    
    if (user) {
      setUsers([...users, user]);
      setShowAddUser(false);
      setNewUser({
        username: '',
        email: '',
        role: 'viewer',
        active: true,
      });
      setMessage({ text: 'Utilisateur ajouté avec succès', type: 'success' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  /** Prépare l'édition d'un utilisateur */
  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setNewUser(user);
    setShowAddUser(true);
  };

  /** Met à jour un utilisateur existant */
  const handleUpdateUser = async () => {
    if (!editingUser || !editingUser.id) return;
    
    setLoading(true);
    const updated = await updateUser(editingUser.id, newUser);
    setLoading(false);
    
    if (updated) {
      setUsers(users.map(u => u.id === editingUser.id ? updated : u));
      setShowAddUser(false);
      setEditingUser(null);
      setNewUser({
        username: '',
        email: '',
        role: 'viewer',
        active: true,
      });
      setMessage({ text: 'Utilisateur mis à jour', type: 'success' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  /** Supprime un utilisateur */
  const handleDeleteUser = async (userId: string) => {
    if (confirm('Voulez-vous vraiment supprimer cet utilisateur ?')) {
      setLoading(true);
      const success = await deleteUser(userId);
      setLoading(false);
      
      if (success) {
        setUsers(users.filter(u => u.id !== userId));
        setMessage({ text: 'Utilisateur supprimé', type: 'success' });
        setTimeout(() => setMessage(null), 3000);
      }
    }
  };

  // ==========================================================
  // FONCTIONS DE GESTION - CONFIGURATION
  // ==========================================================

  /** Exporte la configuration */
  const handleExportConfig = async () => {
    await exportConfig();
  };

  /** Importe une configuration depuis un fichier */
  const handleImportConfig = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setLoading(true);
    const success = await importConfig(file);
    setLoading(false);
    
    if (success) {
      setMessage({ text: 'Configuration importée avec succès', type: 'success' });
      await loadConfig();
    } else {
      setMessage({ text: 'Erreur lors de l\'import', type: 'error' });
    }
    setTimeout(() => setMessage(null), 3000);
  };

  // ==========================================================
// FONCTIONS DE SUPPRESSION DES DONNÉES
// ==========================================================

const handleDeleteAllData = async () => {
  if (deleteConfirmText !== 'SUPPRIMER') {
    setMessage({ text: 'Tapez "SUPPRIMER" pour confirmer', type: 'error' });
    setTimeout(() => setMessage(null), 3000);
    return;
  }
  
  setDeleteLoading(true);
  try {
    const result = await deleteAllData(deleteCollection);
    if (result) {
      setMessage({ text: `${result.message} (${result.deleted_count} éléments supprimés)`, type: 'success' });
      // Rafraîchir les données
      if (deleteCollection === 'surveillance') {
        // Recharger les stats si nécessaire
      } else if (deleteCollection === 'devices') {
        await loadDevices();
      }
    } else {
      setMessage({ text: 'Erreur lors de la suppression', type: 'error' });
    }
  } catch (error) {
    console.error('❌ Erreur suppression:', error);
    setMessage({ text: 'Erreur lors de la suppression', type: 'error' });
  } finally {
    setDeleteLoading(false);
    setShowDeleteModal(false);
    setDeleteConfirmText('');
  }
  setTimeout(() => setMessage(null), 3000);
};

const handleDeleteOldData = async () => {
  setDeleteLoading(true);
  try {
    const result = await deleteOldData(retentionDays);
    if (result) {
      setMessage({ 
        text: `${result.message}\n📊 Mesures supprimées: ${result.deleted_measurements}\n📋 Interventions supprimées: ${result.deleted_interventions}`, 
        type: 'success' 
      });
    } else {
      setMessage({ text: 'Erreur lors de la suppression', type: 'error' });
    }
  } catch (error) {
    console.error('❌ Erreur suppression:', error);
    setMessage({ text: 'Erreur lors de la suppression', type: 'error' });
  } finally {
    setDeleteLoading(false);
    setShowDeleteModal(false);
    setDeleteConfirmText('');
  }
  setTimeout(() => setMessage(null), 3000);
};

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <div>
      {/* ====================================================== */}
      {/* EN-TÊTE DE LA PAGE */}
      {/* ====================================================== */}
      {/*<div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
          <Settings size={24} color={C.green} />
          Administration
        </h1>
        <div style={{ display: 'flex', gap: 8 }}>
          {/* Input caché pour l'import de fichier */}
         {/* <input
            type="file"
            id="import-file"
            accept=".json"
            style={{ display: 'none' }}
            onChange={handleImportConfig}
          />
          {/* Bouton d'export */}
          {/*<button
            onClick={handleExportConfig}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: C.surface,
              color: C.text,
              fontSize: 13,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <Download size={16} />
            Exporter config
          </button>
          {/* Bouton d'import */}
          {/*<button
            onClick={() => document.getElementById('import-file')?.click()}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              border: `1px solid ${C.border}`,
              background: C.surface,
              color: C.text,
              fontSize: 13,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <Upload size={16} />
            Importer
          </button>
        </div>
      </div>*/}

      {/* ====================================================== */}
      {/* MESSAGE DE STATUT (SUCCÈS/ERREUR) */}
      {/* ====================================================== */}
      {message && (
        <div style={{
          marginBottom: 20,
          padding: '12px 16px',
          borderRadius: 8,
          background: message.type === 'success' ? C.greenL : C.redL,
          color: message.type === 'success' ? C.green : C.red,
          fontSize: 13,
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
        }}>
          {message.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {message.text}
        </div>
      )}

      {/* ====================================================== */}
      {/* ONGLETS DE NAVIGATION */}
      {/* ====================================================== */}
      <div style={{
        display: 'flex',
        gap: 8,
        marginBottom: 20,
        borderBottom: `1px solid ${C.border}`,
        paddingBottom: 8,
        overflowX: 'auto',
        flexWrap: 'wrap',
      }}>
        {[
          { id: 'general', label: 'Général',      icon: Settings },
          { id: 'devices', label: 'Dispositifs',  icon: Smartphone },
          { id: 'panels',  label: 'Panneaux',     icon: PanelTop }, 
          { id: 'email',   label: 'Email',        icon: Mail },
          { id: 'users',   label: 'Utilisateurs', icon: Users },
          
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              style={{
                padding: '10px 16px',
                borderRadius: 8,
                border: 'none',
                background: activeTab === tab.id ? C.green : 'transparent',
                color: activeTab === tab.id ? 'white' : C.text2,
                fontSize: 13,
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                whiteSpace: 'nowrap',
              }}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ====================================================== */}
      {/* CONTENU DES ONGLETS */}
      {/* ====================================================== */}

      {/* ------------------------------------------------------ */}
      {/* ONGLET 1 : CONFIGURATION GÉNÉRALE */}
      {/* ------------------------------------------------------ */}
      {activeTab === 'general' && (
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Settings size={18} color={C.green} />
            Configuration générale
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            {/* Seuils d'alerte */}
            <div>
              <h3 style={{ fontSize: 14, fontWeight: 600, color: C.text2, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
                <AlertTriangle size={16} color={C.amber} />
                Seuils d'alerte
              </h3>

              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                  Seuil Warning (%)
                </label>
                <input
                  type="number"
                  value={config.seuil_warning}
                  onChange={(e) => setConfig({ ...config, seuil_warning: Number(e.target.value) })}
                  min={0}
                  max={100}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: 8,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>

              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                  Seuil Critical (%)
                </label>
                <input
                  type="number"
                  value={config.seuil_critical}
                  onChange={(e) => setConfig({ ...config, seuil_critical: Number(e.target.value) })}
                  min={0}
                  max={100}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: 8,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>
            </div>

            {/* Nettoyage automatique */}
            <div>
              <h3 style={{ fontSize: 14, fontWeight: 600, color: C.text2, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
                <RefreshCw size={16} color={C.blue} />
                Nettoyage automatique
              </h3>

              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                  Rétention images (jours)
                </label>
                <input
                  type="number"
                  value={config.retention_days}
                  onChange={(e) => setConfig({ ...config, retention_days: Number(e.target.value) })}
                  min={1}
                  max={30}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: 8,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>

              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                  Intervalle nettoyage (heures)
                </label>
                <input
                  type="number"
                  value={config.cleanup_interval}
                  onChange={(e) => setConfig({ ...config, cleanup_interval: Number(e.target.value) })}
                  min={1}
                  max={168}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: 8,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>
            </div>
                  {/* ========== NOUVEAU : Localisation du champ PV ========== */}
      <div style={{ gridColumn: 'span 2' }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, color: C.text2, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
          <MapPin size={16} color={C.purple} />
          Localisation du champ PV
        </h3>
        
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Latitude */}
          <div>
            <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
              📍 Latitude
            </label>
            <input
              type="number"
              step="0.000001"
              value={config.latitude || ''}
              onChange={(e) => setConfig({ ...config, latitude: e.target.value ? parseFloat(e.target.value) : undefined })}
              placeholder="Ex: 36.8065"
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: 8,
                border: `1px solid ${C.border}`,
                background: C.surface2,
                color: C.text,
                fontSize: 14,
              }}
            />
            <p style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>
              Latitude du site (ex: 36.8065 pour Tunis)
            </p>
          </div>

          {/* Longitude */}
          <div>
            <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
              📍 Longitude
            </label>
            <input
              type="number"
              step="0.000001"
              value={config.longitude || ''}
              onChange={(e) => setConfig({ ...config, longitude: e.target.value ? parseFloat(e.target.value) : undefined })}
              placeholder="Ex: 10.1815"
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: 8,
                border: `1px solid ${C.border}`,
                background: C.surface2,
                color: C.text,
                fontSize: 14,
              }}
            />
            <p style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>
              Longitude du site (ex: 10.1815 pour Tunis)
            </p>
          </div>
        </div>

        {/* Carte informative */}
        <div style={{
          marginTop: 12,
          padding: 12,
          background: C.blueL,
          borderRadius: 8,
          fontSize: 11,
          color: C.blue,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}>
          <MapPin size={14} />
          Ces coordonnées sont utilisées pour la récupération automatique des données d'irradiance (Open-Meteo)

        </div>
      </div>
    </div>
         

          <div style={{ marginTop: 20, textAlign: 'right' }}>
            <button
              onClick={handleSaveConfig}
              disabled={loading}
              style={{
                padding: '10px 24px',
                borderRadius: 8,
                border: 'none',
                background: C.green,
                color: 'white',
                fontSize: 13,
                fontWeight: 600,
                cursor: loading ? 'wait' : 'pointer',
                opacity: loading ? 0.7 : 1,
                display: 'inline-flex',
                alignItems: 'center',
                gap: 8,
              }}
            >
              {loading ? <Loader size={16} className="spin" /> : <Save size={16} />}
              {loading ? 'Sauvegarde...' : 'Sauvegarder'}
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------ */}
      {/* ONGLET 2 : GESTION DES DISPOSITIFS ESP32 */}
      {/* ------------------------------------------------------ */}
      {activeTab === 'devices' && (
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          {/* En-tête de l'onglet */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Smartphone size={18} color={C.green} />
              Gestion des dispositifs ESP
            </h2>
            <button
              onClick={() => {
                setEditingDevice(null);
                resetNewDevice();
                setShowAddDevice(true);
              }}
              style={{
                padding: '8px 16px',
                borderRadius: 8,
                border: 'none',
                background: C.green,
                color: 'white',
                fontSize: 13,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
              }}
            >
              <Plus size={16} />
              Ajouter un dispositif
            </button>
          </div>

          {/* Formulaire d'ajout/édition */}
          {showAddDevice && (
            <div style={{
              marginBottom: 20,
              padding: 20,
              background: C.surface2,
              borderRadius: 8,
            }}>
              <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
                <PlusCircle size={16} color={C.green} />
                {editingDevice ? 'Modifier le dispositif' : 'Nouveau dispositif ESP'}
              </h3>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {/* ID du device (requis) */}
                <div>
                  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                    ID du dispositif <span style={{ color: C.red }}>*</span>
                  </label>
                  <input
                    value={newDevice.device_id || ''}
                    onChange={(e) => setNewDevice({ ...newDevice, device_id: e.target.value })}
                    disabled={!!editingDevice}
                  
                    style={{
                      width: '100%',
                      padding: '10px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: editingDevice ? C.surface : C.surface2,
                      color: C.text,
                      fontSize: 14,
                    }}
                  />
                  <p style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>
                   
                  </p>
                </div>

                {/* Nom du device (optionnel) */}
                <div>
                  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                    Nom (optionnel)
                  </label>
                  <input
                    value={newDevice.name || ''}
                    onChange={(e) => setNewDevice({ ...newDevice, name: e.target.value })}
                    
                    style={{
                      width: '100%',
                      padding: '10px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                      fontSize: 14,
                    }}
                  />
                </div>

                {/* STATUT */}
                <div>
                  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                    Statut
                  </label>
                  <select
                    value={newDevice.status || 'active'}
                    onChange={(e) => setNewDevice({ ...newDevice, status: e.target.value as any })}
                    style={{
                      width: '100%',
                      padding: '10px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                    }}
                  >
                    <option value="active">✅ Actif (peut envoyer des données)</option>
                    <option value="maintenance">🔧 Maintenance (envoi bloqué)</option>
                    <option value="offline">📴 Hors ligne (envoi bloqué)</option>
                  </select>
                </div>
              </div>
           {/* Latitude 
<div>
  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
    📍 Latitude (optionnel)
  </label>
  <input
    type="number"
    step="0.000001"
    value={newDevice.latitude || ''}
    onChange={(e) => setNewDevice({ ...newDevice, latitude: e.target.value ? parseFloat(e.target.value) : undefined })}
    placeholder="Ex: 36.8065"
    style={{
      width: '100%',
      padding: '10px',
      borderRadius: 6,
      border: `1px solid ${C.border}`,
      background: C.surface2,
      color: C.text,
      fontSize: 14,
    }}
  />
  <p style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>
    Pour la récupération automatique de l'irradiance (Open-Meteo)

  </p>
</div>

{/* Longitude 
<div>
  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
    📍 Longitude (optionnel)
  </label>
  <input
    type="number"
    step="0.000001"
    value={newDevice.longitude || ''}
    onChange={(e) => setNewDevice({ ...newDevice, longitude: e.target.value ? parseFloat(e.target.value) : undefined })}
    placeholder="Ex: 10.1815"
    style={{
      width: '100%',
      padding: '10px',
      borderRadius: 6,
      border: `1px solid ${C.border}`,
      background: C.surface2,
      color: C.text,
      fontSize: 14,
    }}
  />
</div>

{/* Zone (optionnel) 
<div>
  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
    🗺️ Zone (optionnel)
  </label>
  <input
    type="text"
    value={newDevice.zone || ''}
    onChange={(e) => setNewDevice({ ...newDevice, zone: e.target.value })}
    placeholder="Ex: Zone A, Toiture Sud, etc."
    style={{
      width: '100%',
      padding: '10px',
      borderRadius: 6,
      border: `1px solid ${C.border}`,
      background: C.surface2,
      color: C.text,
      fontSize: 14,
    }}
  />
</div>*/}
              {/* Boutons du formulaire */}
              <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
                <button
                  onClick={editingDevice ? handleUpdateDevice : handleAddDevice}
                  style={{
                    padding: '10px 20px',
                    borderRadius: 6,
                    border: 'none',
                    background: C.green,
                    color: 'white',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                >
                  <Check size={14} />
                  {editingDevice ? 'Mettre à jour' : 'Ajouter'}
                </button>
                <button
                  onClick={() => {
                    setShowAddDevice(false);
                    setEditingDevice(null);
                    resetNewDevice();
                  }}
                  style={{
                    padding: '10px 20px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: 'transparent',
                    color: C.text2,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    fontSize: 13,
                  }}
                >
                  <X size={14} />
                  Annuler
                </button>
              </div>
            </div>
          )}

          {/* Liste des dispositifs */}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: `2px solid ${C.border}` }}>
                  <th style={{ textAlign: 'left', padding: '12px 8px' }}>ID</th>
                  <th style={{ textAlign: 'left', padding: '12px 8px' }}>Nom</th>
                  <th style={{ textAlign: 'left', padding: '12px 8px' }}>Statut</th>
                  <th style={{ textAlign: 'left', padding: '12px 8px' }}>Dernier heartbeat</th>
                  {/*<th style={{ textAlign: 'left', padding: '12px 8px' }}>Coordonnées</th>*/}
                  <th style={{ textAlign: 'left', padding: '12px 8px' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {devices.map(device => (
                  <tr key={device.device_id} style={{ borderBottom: `1px solid ${C.border}` }}>
                    <td style={{ padding: '12px 8px', fontWeight: 500 }}>{device.device_id}</td>
                    <td style={{ padding: '12px 8px' }}>{device.name || device.device_id}</td>
                    <td style={{ padding: '12px 8px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                        <select
                          value={device.status}
                          onChange={(e) => handleDeviceStatusChange(device.device_id, e.target.value)}
                          style={{
                            padding: '6px 10px',
                            borderRadius: 4,
                            border: `1px solid ${C.border}`,
                            background: device.status === 'active' ? C.greenL :
                                       device.status === 'maintenance' ? C.amberL : C.surface2,
                            color: device.status === 'active' ? C.green :
                                   device.status === 'maintenance' ? C.amber : C.text2,
                            fontWeight: 600,
                            cursor: 'pointer',
                            fontSize: 12,
                          }}
                        >
                          <option value="active">✅ Actif</option>
                          <option value="maintenance">🔧 Maintenance</option>
                          <option value="offline">📴 Hors ligne</option>
                        </select>
                        
                        {device.status !== 'active' && (
                          <span style={{ 
                            fontSize: 10, 
                            color: C.red, 
                            display: 'flex', 
                            alignItems: 'center', 
                            gap: 2 
                          }}>
                            <AlertCircle size={10} />
                            Envoi bloqué
                          </span>
                        )}
                      </div>
                    </td>
                    <td style={{ padding: '12px 8px' }}>
                      {device.last_heartbeat ? new Date(device.last_heartbeat).toLocaleString('fr-FR') : '-'}
                    </td>

                      {/* <td style={{ padding: '12px 8px' }}>
  {device.latitude && device.longitude ? (
    <span style={{ fontSize: 11, fontFamily: 'monospace' }}>
      {device.latitude.toFixed(4)}°, {device.longitude.toFixed(4)}°
    </span>
  ) : (
    <span style={{ color: C.text3, fontSize: 11 }}>Non défini</span>
  )}
</td>*/}
                    <td style={{ padding: '12px 8px' }}>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button 
                          onClick={() => handleEditDevice(device)}
                          style={{ 
                            color: C.blue, 
                            background: 'none', 
                            border: 'none', 
                            cursor: 'pointer',
                            padding: 4,
                            display: 'inline-flex',
                            alignItems: 'center',
                          }}
                          title="Modifier"
                        >
                          <Edit size={16} />
                        </button>
                        <button 
                          onClick={() => handleDeleteDevice(device.device_id)}
                          style={{ 
                            color: C.red, 
                            background: 'none', 
                            border: 'none', 
                            cursor: 'pointer',
                            padding: 4,
                            display: 'inline-flex',
                            alignItems: 'center',
                          }}
                          title="Supprimer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Légende des statuts */}
          <div style={{
            marginTop: 16,
            padding: 12,
            background: C.surface2,
            borderRadius: 8,
            display: 'flex',
            gap: 20,
            flexWrap: 'wrap',
            fontSize: 12,
            color: C.text2,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 12, height: 12, borderRadius: '50%', background: C.green }} />
              <span><strong>Actif</strong> : peut envoyer des données</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 12, height: 12, borderRadius: '50%', background: C.amber }} />
              <span><strong>Maintenance</strong> : envoi temporairement bloqué</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 12, height: 12, borderRadius: '50%', background: C.red }} />
              <span><strong>Hors ligne</strong> : envoi bloqué</span>
            </div>
          </div>
        </div>
      )}

{/* ==================================================== */}
{/* ONGLET 3 : CONFIGURATION DES PANNEAUX */}
{/* ==================================================== */}
{activeTab === 'panels' && (
  <div style={{
    background: C.surface,
    border: `1px solid ${C.border}`,
    borderRadius: 14,
    padding: 20,
  }}>
    <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
      <PanelTop size={18} color={C.orange} />
      Configuration des panneaux solaires
    </h2>

    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
      
      {/* Type de panneau */}
      <div>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
          Type de panneau
        </label>
        <select
          value={panelConfig.panel_type || 'monocristallin'}
          onChange={(e) => setPanelConfig({ ...panelConfig, panel_type: e.target.value })}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
          }}
        >
          <option value="monocristallin">Monocristallin</option>
          <option value="polycristallin">Polycristallin</option>
          <option value="couche_mince">Couche mince</option>
        </select>
      </div>

      {/* Puissance crête (kWc) */}
      <div>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
          Puissance crête (kWc)
        </label>
        <input
          type="number"
          step="0.1"
          min="0"
          value={panelConfig.panel_capacity_kw ?? 3.0}
          onChange={(e) => {
            const val = parseFloat(e.target.value);
            setPanelConfig({ ...panelConfig, panel_capacity_kw: isNaN(val) ? 0 : val });
          }}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
          }}
        />
      </div>

      {/* Surface (m²) */}
      <div>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
          Surface (m²)
        </label>
        <input
          type="number"
          step="0.1"
          min="0"
          value={panelConfig.panel_area_m2 ?? 1.6}
          onChange={(e) => {
            const val = parseFloat(e.target.value);
            setPanelConfig({ ...panelConfig, panel_area_m2: isNaN(val) ? 0 : val });
          }}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
          }}
        />
      </div>

      {/* Rendement (%) - CORRECTION ICI */}
<div>
  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
    Rendement (%)
  </label>
  <input
    type="number"
    step="0.5"
    min="0"
    max="30"
    value={panelConfig.panel_efficiency ? Math.round(panelConfig.panel_efficiency * 100) : 0}
    onChange={(e) => {
      const val = parseFloat(e.target.value);
      setPanelConfig({ 
        ...panelConfig, 
        panel_efficiency: isNaN(val) ? 0.20 : val / 100 
      });
    }}
    style={{
      width: '100%',
      padding: '10px',
      borderRadius: 8,
      border: `1px solid ${C.border}`,
      background: C.surface2,
      color: C.text,
    }}
  />
</div>

      {/* Inclinaison (degrés) */}
      <div>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
          Inclinaison (degrés)
        </label>
        <input
          type="number"
          step="5"
          min="0"
          max="90"
          value={panelConfig.tilt_angle ?? 0}
          onChange={(e) => {
            const val = parseInt(e.target.value);
            setPanelConfig({ ...panelConfig, tilt_angle: isNaN(val) ? 0 : val });
          }}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
          }}
        />
      </div>

      {/* Orientation (azimut) */}
      <div>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
          Orientation (azimut)
        </label>
        <select
          value={panelConfig.azimuth ?? 180}
          onChange={(e) => {
            const val = parseInt(e.target.value);
            setPanelConfig({ ...panelConfig, azimuth: isNaN(val) ? 180 : val });
          }}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
          }}
        >
          <option value="0">Nord (0°)</option>
          <option value="45">Nord-Est (45°)</option>
          <option value="90">Est (90°)</option>
          <option value="135">Sud-Est (135°)</option>
          <option value="180">Sud (180°) - Optimal</option>
          <option value="225">Sud-Ouest (225°)</option>
          <option value="270">Ouest (270°)</option>
          <option value="315">Nord-Ouest (315°)</option>
        </select>
      </div>

      {/* Dégradation annuelle (%) */}
      <div>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
          Dégradation annuelle (%)
        </label>
        <input
          type="number"
          step="0.1"
          min="0"
          max="2"
          value={panelConfig.degradation_rate ?? 0}
          onChange={(e) => {
            const val = parseFloat(e.target.value);
            setPanelConfig({ ...panelConfig, degradation_rate: isNaN(val) ? 0 : val });
          }}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
          }}
        />
      </div>
    </div>

    {/* Informations */}
    <div style={{
      marginTop: 20,
      padding: 16,
      background: C.orangeL,
      borderRadius: 10,
      border: `1px solid ${C.orange}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <Sun size={18} color={C.orange} />
        <span style={{ fontWeight: 600, color: C.orange }}>Calcul de la puissance théorique</span>
      </div>
      <p style={{ fontSize: 12, color: C.text2 }}>
        <strong>P_théorique = irradiance × Surface × Rendement</strong><br/>

        <br/>
        • Surface: {(panelConfig.panel_area_m2 ?? 1.6).toFixed(1)} m²<br/>
        • Rendement: {((panelConfig.panel_efficiency ?? 0.20) * 100).toFixed(1)}%<br/>
        • Coefficient: {((panelConfig.panel_area_m2 ?? 1.6) * (panelConfig.panel_efficiency ?? 0.20)).toFixed(2)} m² × %<br/>
        <br/>
        Exemple : avec 1000 W/m² d'irradiance → Puissance théorique = {(1000 * (panelConfig.panel_area_m2 ?? 1.6) * (panelConfig.panel_efficiency ?? 0.20)).toFixed(0)} W

      </p>
    </div>

    {/* Bouton de sauvegarde */}
    <div style={{ marginTop: 20, textAlign: 'right' }}>
      <button
        onClick={handleSavePanelConfig}
        disabled={loadingPanels}
        style={{
          padding: '10px 24px',
          borderRadius: 8,
          border: 'none',
          background: C.green,
          color: 'white',
          fontSize: 13,
          fontWeight: 600,
          cursor: loadingPanels ? 'wait' : 'pointer',
          display: 'inline-flex',
          alignItems: 'center',
          gap: 8,
        }}
      >
        {loadingPanels ? <Loader size={16} className="spin" /> : <Save size={16} />}
        {loadingPanels ? 'Sauvegarde...' : 'Sauvegarder'}
      </button>
    </div>
  </div>
)}
      {/* ------------------------------------------------------ */}
      {/* ONGLET 4 : GESTION DES UTILISATEURS */}
      {/* ------------------------------------------------------ */}
      {activeTab === 'users' && (
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          {/* En-tête de l'onglet */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Users size={18} color={C.green} />
              Gestion des utilisateurs
            </h2>
            <button
              onClick={() => {
                setEditingUser(null);
                setNewUser({
                  username: '',
                  email: '',
                  role: 'viewer',
                  active: true,
                });
                setShowAddUser(true);
              }}
              style={{
                padding: '8px 16px',
                borderRadius: 8,
                border: 'none',
                background: C.green,
                color: 'white',
                fontSize: 13,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
              }}
            >
              <UserPlus size={16} />
              Ajouter un utilisateur
            </button>
          </div>

          {/* Formulaire d'ajout/édition utilisateur */}
          {showAddUser && (
            <div style={{
              marginBottom: 20,
              padding: 20,
              background: C.surface2,
              borderRadius: 8,
            }}>
              <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
                <UserPlus size={16} color={C.green} />
                {editingUser ? 'Modifier l\'utilisateur' : 'Nouvel utilisateur'}
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  <label style={{ fontSize: 12, color: C.text3 }}>Nom d'utilisateur *</label>
                  <input
                    value={newUser.username}
                    onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '8px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                      marginTop: 4,
                    }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: C.text3 }}>Email *</label>
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '8px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                      marginTop: 4,
                    }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: C.text3 }}>Rôle</label>
                  <select
                    value={newUser.role}
                    onChange={(e) => setNewUser({ ...newUser, role: e.target.value as any })}
                    style={{
                      width: '100%',
                      padding: '8px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                      marginTop: 4,
                    }}
                  >
                    <option value="admin">Administrateur</option>
                    <option value="user">Technicien</option>
                    <option value="viewer">Observateur</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: C.text3 }}>Statut</label>
                  <select
                    value={newUser.active ? 'active' : 'inactive'}
                    onChange={(e) => setNewUser({ ...newUser, active: e.target.value === 'active' })}
                    style={{
                      width: '100%',
                      padding: '8px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                      marginTop: 4,
                    }}
                  >
                    <option value="active">Actif</option>
                    <option value="inactive">Inactif</option>
                  </select>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                <button
                  onClick={editingUser ? handleUpdateUser : handleAddUser}
                  style={{
                    padding: '8px 16px',
                    borderRadius: 6,
                    border: 'none',
                    background: C.green,
                    color: 'white',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  <Check size={14} />
                  {editingUser ? 'Mettre à jour' : 'Ajouter'}
                </button>
                <button
                  onClick={() => {
                    setShowAddUser(false);
                    setEditingUser(null);
                  }}
                  style={{
                    padding: '8px 16px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: 'transparent',
                    color: C.text2,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  <X size={14} />
                  Annuler
                </button>
              </div>
            </div>
          )}

          {/* Liste des utilisateurs */}
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${C.border}` }}>
                <th style={{ textAlign: 'left', padding: '12px 8px' }}>Utilisateur</th>
                <th style={{ textAlign: 'left', padding: '12px 8px' }}>Email</th>
                <th style={{ textAlign: 'left', padding: '12px 8px' }}>Rôle</th>
                <th style={{ textAlign: 'left', padding: '12px 8px' }}>Dernière connexion</th>
                <th style={{ textAlign: 'left', padding: '12px 8px' }}>Statut</th>
                <th style={{ textAlign: 'left', padding: '12px 8px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                  <td style={{ padding: '12px 8px', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <UserIcon size={14} />
                    {user.username}
                  </td>
                  <td style={{ padding: '12px 8px' }}>{user.email}</td>
                  <td style={{ padding: '12px 8px' }}>
                    <span style={{
                      background: user.role === 'admin' ? C.blueL :
                                 user.role === 'user' ? C.greenL : C.amberL,
                      color: user.role === 'admin' ? C.blue :
                             user.role === 'user' ? C.green : C.amber,
                      padding: '4px 8px',
                      borderRadius: 4,
                      fontSize: 12,
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 4,
                    }}>
                      {user.role === 'admin' && <Shield size={12} />}
                      {user.role === 'user' && <Wrench size={12} />}
                      {user.role === 'viewer' && <Eye size={12} />}
                      {user.role === 'admin' && 'Administrateur'}
                      {user.role === 'user' && 'Technicien'}
                      {user.role === 'viewer' && 'Observateur'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 8px' }}>
                    {user.last_login ? (
                      <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Calendar size={12} />
                        {new Date(user.last_login).toLocaleDateString('fr-FR')}
                      </span>
                    ) : '-'}
                  </td>
                  <td style={{ padding: '12px 8px' }}>
                    <span style={{ 
                      color: user.active ? C.green : C.red,
                      display: 'flex',
                      alignItems: 'center',
                      gap: 4,
                    }}>
                      {user.active ? <CheckCircle size={12} /> : <XCircle size={12} />}
                      {user.active ? 'Actif' : 'Inactif'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 8px' }}>
                    <button 
                      onClick={() => handleEditUser(user)}
                      style={{ color: C.blue, background: 'none', border: 'none', cursor: 'pointer', marginRight: 8 }}
                    >
                      <Edit size={14} />
                    </button>
                    <button 
                      onClick={() => handleDeleteUser(user.id)}
                      style={{ color: C.red, background: 'none', border: 'none', cursor: 'pointer' }}
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ------------------------------------------------------ */}
      {/* ONGLET 5 : CONFIGURATION EMAIL */}
      {/* ------------------------------------------------------ */}
      {activeTab === 'email' && (
        <div style={{
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: 20,
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Mail size={18} color={C.green} />
            Configuration des notifications email
          </h2>

          <div style={{ maxWidth: 500 }}>
            {/* Email destinataire */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                Email destinataire *
              </label>
              <input
                type="email"
                value={emailConfig.email_to}
                onChange={(e) => setEmailConfig({ ...emailConfig, email_to: e.target.value })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  background: C.surface2,
                  color: C.text,
                }}
              />
            </div>

            {/* Email expéditeur */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                Email expéditeur (optionnel)
              </label>
              <input
                type="email"
                value={emailConfig.email_from}
                onChange={(e) => setEmailConfig({ ...emailConfig, email_from: e.target.value })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  background: C.surface2,
                  color: C.text,
                }}
              />
            </div>

            {/* Serveur SMTP */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                Serveur SMTP
              </label>
              <input
                value={emailConfig.smtp_host}
                onChange={(e) => setEmailConfig({ ...emailConfig, smtp_host: e.target.value })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  background: C.surface2,
                  color: C.text,
                }}
              />
            </div>

            {/* Port SMTP */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                Port SMTP
              </label>
              <input
                type="number"
                value={emailConfig.smtp_port}
                onChange={(e) => setEmailConfig({ ...emailConfig, smtp_port: Number(e.target.value) })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  background: C.surface2,
                  color: C.text,
                }}
              />
            </div>

            {/* Mot de passe SMTP */}
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>
                Mot de passe SMTP
                {emailConfig.has_password && !emailPassword && (
                  <span style={{ marginLeft: 8, fontSize: 11, color: C.green }}>
                    (déjà configuré)
                  </span>
                )}
              </label>
              <input
                type="password"
                value={emailPassword}
                onChange={(e) => setEmailPassword(e.target.value)}
                placeholder={emailConfig.has_password ? "•••••••• (laisser vide pour conserver)" : "Mot de passe"}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  background: C.surface2,
                  color: C.text,
                }}
              />
            </div>

            {/* Boutons d'action */}
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={handleTestEmail}
                disabled={testingEmail}
                style={{
                  padding: '10px 20px',
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  background: C.surface2,
                  color: C.text2,
                  fontSize: 13,
                  cursor: testingEmail ? 'wait' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                {testingEmail ? <Loader size={14} className="spin" /> : <MailCheck size={14} />}
                {testingEmail ? 'Envoi...' : 'Tester'}
              </button>
              <button
                onClick={handleSaveEmail}
                disabled={loading}
                style={{
                  padding: '10px 20px',
                  borderRadius: 8,
                  border: 'none',
                  background: C.green,
                  color: 'white',
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: loading ? 'wait' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                {loading ? <Loader size={14} className="spin" /> : <Save size={14} />}
                {loading ? 'Sauvegarde...' : 'Sauvegarder'}
              </button>
            </div>
          </div>
        </div>
      )}


{/* ==================================================== */}
{/* SECTION GESTION DES DONNÉES (UNIFIÉE) */}
{/* ==================================================== */}
<div style={{
  background: C.surface,
  border: `1px solid ${C.border}`,
  borderRadius: 14,
  padding: 20,
  marginTop: 20,
}}>
  <h2 style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
    <Trash2 size={18} color={C.red} />
    Gestion des données
  </h2>
  
  <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
    
    {/* ================================================ */}
    {/* 1. CHOIX DE LA COLLECTION À VIDER */}
    {/* ================================================ */}
    <div>
      <label style={{ 
        fontSize: 13, 
        fontWeight: 600, 
        color: C.text, 
        display: 'flex', 
        alignItems: 'center', 
        gap: 6,
        marginBottom: 12 
      }}>
        <Database size={16} color={C.blue} />
        Quelle donnée voulez-vous supprimer ?
      </label>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        {[
          { id: 'surveillance', label: 'Mesures (historique)', color: C.blue, icon: Database },
          //{ id: 'devices', label: 'Devices ESP32', color: C.purple, icon: Smartphone },
          { id: 'interventions', label: 'Interventions', color: C.amber, icon: Wrench },
          { id: 'alerts', label: 'Alertes', color: C.red, icon: Bell },
        ].map((option) => {
          const Icon = option.icon;
          return (
            <label
              key={option.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '8px 16px',
                borderRadius: 8,
                background: deleteCollection === option.id ? `${option.color}20` : C.surface2,
                border: `1px solid ${deleteCollection === option.id ? option.color : C.border}`,
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}
            >
              <input
                type="radio"
                name="deleteCollection"
                value={option.id}
                checked={deleteCollection === option.id}
                onChange={(e) => setDeleteCollection(e.target.value)}
                style={{ accentColor: option.color }}
              />
              <Icon size={16} color={deleteCollection === option.id ? option.color : C.text3} />
              <span style={{ fontSize: 13, color: deleteCollection === option.id ? option.color : C.text2 }}>
                {option.label}
              </span>
            </label>
          );
        })}
      </div>
    </div>

    {/* ================================================ */}
    {/* 2. TYPE DE SUPPRESSION */}
    {/* ================================================ */}
    <div>
      <label style={{ 
        fontSize: 13, 
        fontWeight: 600, 
        color: C.text, 
        display: 'flex', 
        alignItems: 'center', 
        gap: 6,
        marginBottom: 12 
      }}>
        <Sliders size={16} color={C.text2} />
        Comment voulez-vous supprimer ?
      </label>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        
        {/* Option 1 : Supprimer tout */}
        <label
          style={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '12px 16px',
            borderRadius: 8,
            background: deleteType === 'all' ? C.redL : C.surface2,
            border: `1px solid ${deleteType === 'all' ? C.red : C.border}`,
            cursor: 'pointer',
          }}
        >
          <input
            type="radio"
            name="deleteType"
            value="all"
            checked={deleteType === 'all'}
            onChange={() => setDeleteType('all')}
            style={{ accentColor: C.red }}
          />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Trash2 size={20} color={deleteType === 'all' ? C.red : C.text3} />
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: deleteType === 'all' ? C.red : C.text }}>
                Supprimer TOUT
              </div>
              <div style={{ fontSize: 11, color: C.text3 }}>
                Supprime définitivement toutes les données de cette collection
              </div>
            </div>
          </div>
        </label>
        
        {/* Option 2 : Supprimer les anciennes */}
        <label
          style={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '12px 16px',
            borderRadius: 8,
            background: deleteType === 'old' ? C.amberL : C.surface2,
            border: `1px solid ${deleteType === 'old' ? C.amber : C.border}`,
            cursor: 'pointer',
          }}
        >
          <input
            type="radio"
            name="deleteType"
            value="old"
            checked={deleteType === 'old'}
            onChange={() => setDeleteType('old')}
            style={{ accentColor: C.amber }}
          />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Archive size={20} color={deleteType === 'old' ? C.amber : C.text3} />
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: deleteType === 'old' ? C.amber : C.text }}>
                Supprimer les données plus anciennes
              </div>
              <div style={{ fontSize: 11, color: C.text3 }}>
                Ne conserve que les X derniers jours
              </div>
            </div>
          </div>
        </label>
      </div>
    </div>

    {/* ================================================ */}
    {/* 3. NOMBRE DE JOURS (si suppression ancienne) */}
    {/* ================================================ */}
    {deleteType === 'old' && (
      <div style={{
        background: C.surface2,
        borderRadius: 10,
        padding: 16,
        border: `1px solid ${C.border}`,
      }}>
        <label style={{ 
          fontSize: 12, 
          color: C.text3, 
          display: 'flex', 
          alignItems: 'center', 
          gap: 6,
          marginBottom: 8 
        }}>
          <CalendarDays size={14} color={C.amber} />
          Conserver les données des derniers :
        </label>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <input
            type="range"
            value={retentionDays}
            onChange={(e) => setRetentionDays(Number(e.target.value))}
            min={1}
            max={365}
            style={{ flex: 1, height: 4, borderRadius: 2, accentColor: C.amber }}
          />
          <div style={{
            background: C.surface,
            padding: '6px 12px',
            borderRadius: 6,
            border: `1px solid ${C.border}`,
            minWidth: 80,
            textAlign: 'center',
            display: 'flex',
            alignItems: 'center',
            gap: 4,
          }}>
            <Clock size={12} color={C.amber} />
            <span style={{ fontSize: 14, fontWeight: 600, color: C.amber }}>{retentionDays}</span>
            <span style={{ fontSize: 11, color: C.text3 }}>jours</span>
          </div>
        </div>
        <div style={{ fontSize: 11, color: C.text3, marginTop: 8, display: 'flex', alignItems: 'center', gap: 4 }}>
          <Info size={12} />
          Les données plus anciennes que {retentionDays} jours seront supprimées
        </div>
      </div>
    )}

    {/* ================================================ */}
    {/* 4. BOUTON DE SUPPRESSION */}
    {/* ================================================ */}
    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
      <button
        onClick={() => setShowDeleteModal(true)}
        disabled={loading}
        style={{
          padding: '12px 24px',
          borderRadius: 8,
          border: 'none',
          background: C.red,
          color: 'white',
          fontSize: 14,
          fontWeight: 600,
          cursor: loading ? 'wait' : 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          opacity: loading ? 0.7 : 1,
        }}
      >
        <Trash2 size={18} />
        Supprimer
      </button>
    </div>
  </div>
</div>

{/* ==================================================== */}
{/* MODAL DE CONFIRMATION SUPPRESSION */}
{/* ==================================================== */}
{showDeleteModal && (
  <div style={{
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  }}>
    <div style={{
      background: C.surface,
      borderRadius: 14,
      padding: 24,
      width: 500,
      maxWidth: '90%',
      boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
        <AlertTriangle size={28} color={C.red} />
        <h3 style={{ fontSize: 18, fontWeight: 700, color: C.red }}>Confirmation de suppression</h3>
      </div>
      
      {/* Récapitulatif de ce qui va être supprimé */}
      <div style={{
        background: C.surface2,
        borderRadius: 10,
        padding: 16,
        marginBottom: 20,
      }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: 10, background: C.redL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Trash2 size={20} color={C.red} />
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 6 }}>
              {deleteCollection === 'surveillance' && <Database size={14} color={C.blue} />}
              {deleteCollection === 'devices' && <Smartphone size={14} color={C.purple} />}
              {deleteCollection === 'interventions' && <Wrench size={14} color={C.amber} />}
              {deleteCollection === 'alerts' && <Bell size={14} color={C.red} />}
              {deleteCollection === 'surveillance' && 'Mesures (historique)'}
              {deleteCollection === 'devices' && 'Devices ESP32'}
              {deleteCollection === 'interventions' && 'Interventions'}
              {deleteCollection === 'alerts' && 'Alertes'}
            </div>
            <div style={{ fontSize: 12, color: C.text3, marginTop: 2 }}>
              {deleteType === 'all' 
                ? '⚠️ Toutes les données seront supprimées définitivement'
                : `⚠️ Les données plus anciennes que ${retentionDays} jours seront supprimées`
              }
            </div>
          </div>
        </div>
        
        {deleteType === 'old' && deleteCollection !== 'devices' && (
          <div style={{
            padding: 10,
            background: C.amberL,
            borderRadius: 8,
            fontSize: 12,
            color: C.amber,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <Info size={14} />
            <strong>Information :</strong> Les {retentionDays} derniers jours seront conservés.
          </div>
        )}
        
        {deleteType === 'all' && (
          <div style={{
            padding: 10,
            background: C.redL,
            borderRadius: 8,
            fontSize: 12,
            color: C.red,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <AlertCircle size={14} />
            <strong>Attention :</strong> Cette action est irréversible !
          </div>
        )}
      </div>
      
      <div style={{ marginBottom: 20 }}>
        <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 8 }}>
          Tapez <strong style={{ color: C.red }}>"SUPPRIMER"</strong> pour confirmer :
        </label>
        <input
          type="text"
          value={deleteConfirmText}
          onChange={(e) => setDeleteConfirmText(e.target.value.toUpperCase())}
          placeholder="SUPPRIMER"
          style={{
            width: '100%',
            padding: '12px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            fontSize: 14,
            textAlign: 'center',
            letterSpacing: 2,
            fontWeight: 600,
          }}
        />
      </div>
      
      <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
        <button
          onClick={() => {
            setShowDeleteModal(false);
            setDeleteConfirmText('');
          }}
          style={{
            padding: '10px 20px',
            borderRadius: 8,
            border: `1px solid ${C.border}`,
            background: 'transparent',
            color: C.text2,
            fontSize: 13,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}
        >
          <X size={14} />
          Annuler
        </button>
        <button
          onClick={deleteType === 'all' ? handleDeleteAllData : handleDeleteOldData}
          disabled={deleteConfirmText !== 'SUPPRIMER' || deleteLoading}
          style={{
            padding: '10px 24px',
            borderRadius: 8,
            border: 'none',
            background: deleteConfirmText === 'SUPPRIMER' && !deleteLoading ? C.red : C.surface2,
            color: deleteConfirmText === 'SUPPRIMER' && !deleteLoading ? 'white' : C.text3,
            fontSize: 13,
            fontWeight: 600,
            cursor: deleteConfirmText === 'SUPPRIMER' && !deleteLoading ? 'pointer' : 'not-allowed',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          {deleteLoading ? <Loader size={16} className="spin" /> : <Trash2 size={16} />}
          {deleteLoading ? 'Suppression...' : 'Confirmer la suppression'}
        </button>
      </div>
    </div>
  </div>
)}
    </div>
  );
}