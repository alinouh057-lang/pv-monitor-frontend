'use client';

/**
 * ============================================================
 * DASHBOARD PV MONITOR — Page principale
 * ============================================================
 * Affiche en temps réel :
 *  - KPIs : ensablement IA, puissance, pertes, performance, production, température
 *  - Image live ESP32 + jauge d'ensablement avec seuils
 *  - Graphiques : puissance réelle vs théorique, évolution de l'ensablement
 *  - Télemétrie : tension, courant, irradiance, puissance
 *  - Statistiques globales
 *  - Upload manuel pour analyse IA d'image
 *
 * Fonctionnalités clés :
 *  - Auto-refresh toutes les 30 secondes
 *  - Détection état backend / ESP32
 *  - Filtre par période (24h, 7j, 30j, tout)
 *  - Valeurs sécurisées (fallbacks anti-NaN)
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================

// React
import { useState, useEffect, useCallback, useMemo } from 'react';

// Recharts (graphiques)
import {
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Area, AreaChart, ComposedChart, Line,
} from 'recharts';

// API & types
import {
  fetchLatest, fetchHistory, fetchStats, fetchHeartbeat, getPanelConfig,
  fmtTime, fmtDateTime, statusColor, statusBg,
  type Measurement, type Stats,
} from '@/lib/api';

// Contextes React
import { useRefresh } from '@/contexts/RefreshContext';
import { useDashboardReset } from '@/contexts/DashboardContext';

// Design tokens (palette centralisée)
import { C } from '@/lib/colors';

// Icônes Lucide
import {
  Tag, Zap, TrendingDown, Target, Camera, Satellite,
  Search, TrendingUp, BarChart3, Power, Sun,
  Plug, Activity, WifiOff, Upload, Loader,
  Thermometer, AlertTriangle, AlertCircle, CheckCircle,
  Info, RefreshCw, Database,
} from 'lucide-react';

// ============================================================
// UTILITAIRES
// ============================================================

/**
 * Parse un timestamp MongoDB vers un objet Date.
 * Supporte : { $date: "..." } | objet Date | chaîne ISO 8601
 * Retourne null si le format est invalide.
 */
function parseMongoDate(timestamp: any): Date | null {
  if (!timestamp) return null;

  // Format MongoDB natif : { $date: "2024-01-15T10:30:00Z" }
  if (typeof timestamp === 'object' && timestamp !== null && timestamp.$date) {
    return new Date(timestamp.$date);
  }

  // Déjà un objet Date
  if (timestamp instanceof Date) {
    return isNaN(timestamp.getTime()) ? null : timestamp;
  }

  // Chaîne ISO 8601
  if (typeof timestamp === 'string') {
    const date = new Date(timestamp);
    return isNaN(date.getTime()) ? null : date;
  }

  return null;
}

// ============================================================
// SOUS-COMPOSANTS (UI réutilisables)
// ============================================================

/**
 * KpiCard — Carte métrique principale
 * Affiche : icône, valeur, unité, label, badge d'état
 * Utilisée pour les 6 KPIs en haut du dashboard.
 */
function KpiCard({ icon: Icon, label, value, unit, badge, accentColor, delay = '0s' }: {
  icon: React.ElementType;
  label: string;
  value: string;
  unit: string;
  badge: string;
  accentColor: string;
  delay?: string;
}) {
  return (
    <div
      className="fade-up"
      style={{
        background: C.surface,
        border: `1px solid ${C.border}`,
        borderRadius: 14,
        padding: '18px 20px',
        boxShadow: '0 1px 3px rgba(13,82,52,.06), 0 4px 16px rgba(13,82,52,.05)',
        position: 'relative',
        overflow: 'hidden',
        animationDelay: delay,
      }}
    >
      {/* Bande colorée supérieure */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: 3, background: accentColor, borderRadius: '14px 14px 0 0',
      }} />

      {/* Icône */}
      <div style={{ fontSize: 20, marginBottom: 10 }}>
        <Icon size={24} color={accentColor} />
      </div>

      {/* Valeur */}
      <div>
        <span style={{
          fontFamily: 'Sora, sans-serif', fontSize: 26, fontWeight: 800,
          color: C.text, letterSpacing: '-.5px',
        }}>
          {value}
        </span>
        <span style={{ fontSize: 12, color: C.text3, marginLeft: 3 }}>{unit}</span>
      </div>

      {/* Label */}
      <div style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>{label}</div>

      {/* Badge */}
      <div style={{
        display: 'inline-block', marginTop: 7, padding: '3px 9px',
        borderRadius: 99, fontSize: 10.5, fontWeight: 600,
        background: `${accentColor}18`, color: accentColor,
      }}>
        {badge}
      </div>
    </div>
  );
}

/**
 * SoilingGauge — Jauge d'ensablement
 * Barre de progression avec 3 seuils colorés :
 *  - Clean   (< 30%)  → vert
 *  - Warning (30-60%)  → ambre
 *  - Critical (> 60%)  → rouge
 */
function SoilingGauge({ level, status, confidence }: {
  level: number; status: string; confidence?: number;
}) {
  const color = statusColor(status);
  const safeLevel = typeof level === 'number' && !isNaN(level) ? level : 0;
  const safeConfidence = typeof confidence === 'number' && !isNaN(confidence) ? confidence : 0;

  const segments = [
    { label: 'Clean', max: 30, color: C.green },
    { label: 'Warning', max: 60, color: C.amber },
    { label: 'Critical', max: 100, color: C.red },
  ];

  const statusIcon = {
    Clean: <CheckCircle size={14} />,
    Warning: <AlertCircle size={14} />,
    Critical: <AlertTriangle size={14} />,
  }[status] ?? <Info size={14} />;

  return (
    <div>
      {/* Valeur + badge de statut */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        alignItems: 'center', marginBottom: 6,
      }}>
        <span style={{ fontFamily: 'Sora, sans-serif', fontSize: 28, fontWeight: 800, color }}>
          {safeLevel.toFixed(1)}%
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {confidence && (
            <span style={{ fontSize: 11, color: C.text3 }}>
              Confiance: {(safeConfidence * 100).toFixed(0)}%
            </span>
          )}
          <span style={{
            padding: '4px 12px', borderRadius: 99, fontSize: 12, fontWeight: 700,
            background: statusBg(status), color,
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            {statusIcon} {status}
          </span>
        </div>
      </div>

      {/* Barre de progression */}
      <div style={{
        height: 10, borderRadius: 99, background: C.surface2,
        overflow: 'hidden', position: 'relative',
      }}>
        <div style={{
          height: '100%', width: `${safeLevel}%`,
          background: `linear-gradient(90deg, ${C.green}, ${color})`,
          borderRadius: 99, transition: 'width .8s ease',
        }} />
        {/* Marqueurs de seuil */}
        {segments.map(s => (
          <div key={s.label} style={{
            position: 'absolute', top: 0, left: `${s.max}%`,
            height: '100%', width: 1, background: C.border,
            transform: 'translateX(-50%)',
          }} />
        ))}
      </div>

      {/* Labels de seuil */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5 }}>
        {segments.map(s => (
          <span key={s.label} style={{ fontSize: 10, color: C.text3 }}>{s.label}</span>
        ))}
      </div>
    </div>
  );
}

/**
 * TeleItem — Cellule de télemétrie
 * Affiche une mesure électrique dans une petite carte (voltage, courant, etc.)
 */
function TeleItem({ icon: Icon, value, unit, label }: {
  icon: React.ElementType; value: number; unit: string; label: string;
}) {
  const safeValue = typeof value === 'number' && !isNaN(value) ? value : 0;
  const display = unit === '' ? '--' : `${safeValue.toFixed(unit === 'A' ? 2 : 1)} ${unit}`;

  return (
    <div style={{ background: 'var(--surface2)', borderRadius: 10, padding: '11px', textAlign: 'center' }}>
      <div style={{ fontFamily: 'Sora, sans-serif', fontSize: 19, fontWeight: 700, color: 'var(--text)' }}>
        {display}
      </div>
      <div style={{
        fontSize: 10, color: 'var(--text3)', marginTop: 3,
        textTransform: 'uppercase', letterSpacing: '.5px',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
      }}>
        <Icon size={12} />
        {label}
      </div>
    </div>
  );
}

/**
 * UploadZone — Zone de glisser-déposer pour analyse IA
 * Accepte JPG/PNG, envoie à l'endpoint d'analyse et retourne le résultat.
 */
function UploadZone({ onResult }: { onResult: (r: any) => void }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (file: File) => {
    setLoading(true);
    setError(null);
    try {
      const { analyzeImage } = await import('@/lib/api');
      const result = await analyzeImage(file);

      if (result?.error) {
        setError(`Erreur: ${result.message || 'Échec de l\'analyse'}`);
      } else {
        onResult(result);
      }
    } catch {
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  const isError = !!error;

  return (
    <label
      style={{
        display: 'block', border: `2px dashed ${isError ? '#c0392b' : '#d8e8d8'}`,
        borderRadius: 11, padding: '22px 14px', textAlign: 'center',
        cursor: 'pointer', background: isError ? '#fdecea' : '#edf4ed',
        color: isError ? '#c0392b' : '#7aaa88', transition: 'var(--tr)',
      }}
      onMouseEnter={e => {
        if (!isError) {
          (e.currentTarget as HTMLLabelElement).style.borderColor = '#1a7f4f';
          (e.currentTarget as HTMLLabelElement).style.background = '#e4f3ea';
        }
      }}
      onMouseLeave={e => {
        if (!isError) {
          (e.currentTarget as HTMLLabelElement).style.borderColor = '#d8e8d8';
          (e.currentTarget as HTMLLabelElement).style.background = '#edf4ed';
        }
      }}
    >
      <input
        type="file" accept=".jpg,.jpeg,.png" style={{ display: 'none' }}
        onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }}
      />
      {loading ? (
        <span style={{
          fontSize: 13, color: '#1a7f4f',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          <Loader size={16} className="spin" /> Analyse IA en cours…
        </span>
      ) : isError ? (
        <span style={{
          fontSize: 13, color: '#c0392b',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          <AlertCircle size={16} /> {error}
        </span>
      ) : (
        <>
          <Upload size={32} style={{ marginBottom: 8, opacity: 0.7 }} />
          <div style={{ fontSize: 12.5, fontWeight: 500 }}>Glisser une image ici</div>
          <div style={{ fontSize: 10.5, marginTop: 2 }}>JPG / PNG → Analyse IA immédiate</div>
        </>
      )}
    </label>
  );
}

/**
 * CustomTooltip — Tooltip personnalisé pour les graphiques Recharts
 * Affiche la date et toutes les séries de données avec leur couleur.
 */
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;

  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`,
      borderRadius: 10, padding: '12px 16px', fontSize: 12,
      boxShadow: '0 4px 16px rgba(13,82,52,.10)',
    }}>
      <div style={{ fontWeight: 700, color: C.text, marginBottom: 8 }}>{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          marginBottom: 4, color: p.color,
        }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: p.color }} />
          <span style={{ flex: 1 }}>{p.name}:</span>
          <b>{p.value?.toFixed(1)}{p.unit}</b>
        </div>
      ))}
    </div>
  );
};

/**
 * TimeRangeSelector — Sélecteur de période
 * Boutons radio stylisés : 24h | 7j | 30j | Tout
 */
function TimeRangeSelector({ value, onChange }: {
  value: string; onChange: (range: string) => void;
}) {
  const ranges = [
    { id: '24h', label: '24h' },
    { id: '7d',  label: '7j'  },
    { id: '30d', label: '30j' },
    { id: 'all', label: 'Tout' },
  ];

  return (
    <div style={{ display: 'flex', gap: 4, background: C.surface2, borderRadius: 6, padding: 2 }}>
      {ranges.map(range => (
        <button
          key={range.id}
          onClick={() => onChange(range.id)}
          style={{
            padding: '4px 12px', borderRadius: 4, border: 'none',
            background: value === range.id ? C.green : 'transparent',
            color: value === range.id ? 'white' : C.text2,
            fontSize: 11, fontWeight: 600, cursor: 'pointer', transition: 'var(--tr)',
          }}
        >
          {range.label}
        </button>
      ))}
    </div>
  );
}

/**
 * StatCard — Carte de statistique
 * Petites cartes pour la section "Statistiques globales" (mesures totales, moyennes…)
 */
function StatCard({
  value, unit, label, color, icon: Icon, decimals = 0,
}: {
  value: number; unit: string; label: string;
  color: string; icon: React.ElementType; decimals?: number;
}) {
  const formatted = typeof value === 'number' && !isNaN(value) ? value.toFixed(decimals) : '0';

  return (
    <div style={{
      background: C.surface2, borderRadius: 12, padding: '12px 8px',
      textAlign: 'center', transition: 'transform 0.2s ease, background 0.2s ease',
      cursor: 'default',
    }}>
      <div style={{
        fontFamily: 'Sora, sans-serif', fontSize: 20, fontWeight: 700, color,
        display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 2,
        marginBottom: 4,
      }}>
        <span>{formatted}</span>
        {unit && <span style={{ fontSize: 11, color: C.text3, fontWeight: 500 }}>{unit}</span>}
      </div>
      <div style={{
        fontSize: 10, color: C.text3, marginTop: 4,
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
      }}>
        <Icon size={11} color={color} />
        {label}
      </div>
    </div>
  );
}

// ============================================================
// COMPOSANT PRINCIPAL — Dashboard
// ============================================================
export default function Dashboard() {

  // ─── Contextes ────────────────────────────────────────────
  const { autoRefresh, setLastUpdate, refreshKey } = useRefresh();
  const { isReset, clearResetFlag } = useDashboardReset();

  // ─── États ────────────────────────────────────────────────
  const [latest, setLatest]           = useState<Measurement | null>(null);
  const [historyData, setHistoryData] = useState<Measurement[]>([]);
  const [stats, setStats]             = useState<Stats | null>(null);
  const [uploadResult, setUploadResult] = useState<any>(null);
  const [loading, setLoading]         = useState(true);
  const [connected, setConnected]     = useState(true);
  const [esp32Online, setEsp32Online] = useState(false);
  const [timeRange, setTimeRange]     = useState('24h');
  const [panelConfig, setPanelConfig] = useState({
    area: 1.6,
    efficiency: 0.20,
  });

  const REFRESH_INTERVAL = 30_000; // 30 secondes

  // ─── Valeurs par défaut pour les moyennes ─────────────────
  const defaultAverages = {
    avg_power: 0, avg_soiling: 0, avg_voltage: 0,
    avg_current: 0, avg_irradiance: 0, avg_temperature: 0,
  };

  // ==========================================================
  // EFFETS DE BORD (Hooks — ordre fixe, pas de conditionnels)
  // ==========================================================

  /** Réinitialisation du dashboard si demandé par le contexte */
  useEffect(() => {
    if (isReset) {
      setLatest(null);
      setHistoryData([]);
      setStats(null);
      setUploadResult(null);
      setEsp32Online(false);
      setConnected(true);
      clearResetFlag();
    }
  }, [isReset, clearResetFlag]);

  /** Chargement de la configuration des panneaux (surface, rendement) */
  useEffect(() => {
    (async () => {
      try {
        const config = await getPanelConfig();
        if (config) {
          setPanelConfig({
            area: config.panel_area_m2 ?? 1.6,
            efficiency: config.panel_efficiency ?? 0.20,
          });
        }
      } catch {
        /* valeurs par défaut déjà en place */
      }
    })();
  }, []);

  /** Chargement initial des données + auto-refresh périodique */
  const load = useCallback(async () => {
    try {
      const [l, h, s, hb] = await Promise.all([
        fetchLatest(),
        fetchHistory(0, 0),
        fetchStats(),
        fetchHeartbeat(),
      ]);

      setLatest(l);

      if (h && Array.isArray(h.data)) {
        setHistoryData(h.data);
      } else {
        setHistoryData([]);
      }

      if (s) setStats(s);
      setEsp32Online(hb);
      setConnected(true);
      setLastUpdate(new Date());
    } catch {
      setConnected(false);
      setHistoryData([]);
    } finally {
      setLoading(false);
    }
  }, [setLastUpdate]);

  useEffect(() => {
    load();
    let interval: NodeJS.Timeout | null = null;
    if (autoRefresh) {
      interval = setInterval(load, REFRESH_INTERVAL);
    }
    return () => { if (interval) clearInterval(interval); };
  }, [load, autoRefresh]);

  /** Rechargement manuel déclenché par le contexte RefreshContext */
  useEffect(() => {
    if (refreshKey > 0) load();
  }, [refreshKey, load]);

  // ─── Données du graphique (useMemo — AVANT tout return) ──
  const chartData = useMemo(() => {
    if (!historyData || historyData.length === 0) return [];

    let filtered = historyData;

    // Filtrage par période (sauf "all")
    if (timeRange !== 'all') {
      const hoursMap: Record<string, number> = { '24h': 24, '7d': 168, '30d': 720 };
      const hours = hoursMap[timeRange] ?? 24;
      const cutoff = new Date(Date.now() - hours * 3_600_000);

      filtered = historyData.filter(d => {
        const date = parseMongoDate(d.timestamp);
        return date ? date >= cutoff : false;
      });
    }

    // Transformation pour les graphiques
    return filtered.map(d => {
      const power = d.electrical_data?.power_output || 0;
      const irradiance = d.electrical_data?.irradiance || 0;
      const theoretical = irradiance * panelConfig.area * panelConfig.efficiency;

      return {
        time: fmtTime(d.timestamp),
        power: Number(power.toFixed(1)),
        theoretical: Number(theoretical.toFixed(1)),
        soiling: Number((d.ai_analysis?.soiling_level || 0).toFixed(1)),
        loss: Number((Math.max(0, theoretical - power)).toFixed(1)),
      };
    }).reverse();
  }, [historyData, timeRange, panelConfig]);

  // ==========================================================
  // ÉCRAN DE CHARGEMENT (return conditionnel — APRÈS tous les hooks)
  // ==========================================================
  if (loading) {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        height: '60vh', flexDirection: 'column', gap: 12,
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%',
          border: `3px solid ${C.greenL}`, borderTop: `3px solid ${C.green}`,
          animation: 'spin 1s linear infinite',
        }} />
        <span style={{ color: C.text3, fontSize: 13 }}>Connexion au backend…</span>
      </div>
    );
  }

  // ==========================================================
  // DONNÉES DÉRIVÉES (calculs à partir des états)
  // ==========================================================

  // Analyse IA (fallbacks si pas de données)
  const ai = latest?.ai_analysis ?? {
    soiling_level: 0, status: 'Clean', confidence: 0, model_version: '—',
  };

  // Données électriques (fallbacks)
  const ed = latest?.electrical_data ?? {
    voltage: 0, current: 0, power_output: 0, irradiance: 0, temperature: 0,
  };

  // Image base64 de l'ESP32
  const b64 = latest?.media?.image_b64;

  // Flag : pas de données disponibles
  const noData = !esp32Online || !latest;

  // ─── Calculs avancés ──────────────────────────────────────

  // Puissance théorique = irradiance × surface × rendement
  const theoreticalPower = (ed.irradiance || 0) * panelConfig.area * panelConfig.efficiency;

  // Perte estimée due à l'ensablement
  const loss = Math.max(0, theoreticalPower - (ed.power_output || 0));

  // Couleur dynamique du statut d'ensablement
  const statusColorValue = statusColor(ai.status || 'Clean');

  // Production journalière estimée (moyenne × 24h / 1000 → kWh)
  const dailyProduction = stats?.averages?.avg_power
    ? (stats.averages.avg_power || 0) * 24 / 1000
    : 0;

  // Performance Ratio (%)
  const performanceRatio = theoreticalPower > 0
    ? ((ed.power_output || 0) / theoreticalPower) * 100
    : 0;

  // Température du module (fallback 25°C)
  const temperature = ed.temperature || 25;

  // Averages avec fallbacks
  const averages = stats?.averages || defaultAverages;

  // Accès sécurisé au nombre total de mesures
  // (compatible ancien type number ET nouveau type objet)
  const totalMeasurements = typeof stats?.total === 'number'
    ? stats.total
    : (stats?.total as any)?.count ?? 0;

  /** Formateur : affiche '--' si pas de données, sinon la valeur formatée */
  const fmt = (v: number, dec = 0) => {
    if (noData) return '--';
    if (typeof v !== 'number' || isNaN(v)) return '0';
    return v.toFixed(dec);
  };

  // Upload : fusionne le résultat upload avec les données live si présent
  const effectiveAi = uploadResult?.ai_analysis
    ? {
        soiling_level: uploadResult.ai_analysis.soiling_level ?? ai.soiling_level,
        status: uploadResult.ai_analysis.status ?? ai.status,
        confidence: uploadResult.ai_analysis.confidence ?? ai.confidence,
        model_version: uploadResult.ai_analysis.model_version ?? ai.model_version,
      }
    : ai;

  // ==========================================================
  // RENDU JSX
  // ==========================================================
  return (
    <div>

      {/* ─── En-tête : titre, indicateur live, sélecteur période ─── */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        alignItems: 'center', marginBottom: 20,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <h1 style={{
            fontSize: 20, fontWeight: 700, color: C.text,
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <Sun size={24} color={C.amber} />
            Dashboard PV
          </h1>
          {esp32Online && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: C.greenL, padding: '4px 10px',
              borderRadius: 99, fontSize: 11, color: C.green,
            }}>
              <span style={{
                width: 6, height: 6, borderRadius: '50%', background: C.green,
                animation: 'pulse-ring 1.5s ease-out infinite',
              }} />
              Live · {latest?.timestamp ? fmtDateTime(latest.timestamp) : ''}
            </div>
          )}
        </div>
        <TimeRangeSelector value={timeRange} onChange={setTimeRange} />
      </div>

      {/* ─── Bannière d'alerte : backend ou ESP32 hors ligne ─── */}
      {(!connected || noData) && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderLeft: `4px solid ${C.amber}`,
          borderRadius: 12, padding: '14px 18px', marginBottom: 20,
        }}>
          <WifiOff size={22} color={C.amber} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, color: C.amber, fontSize: 14 }}>
              {!connected ? 'Backend inaccessible' : 'ESP32 non connecté'}
            </div>
            <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
              {!connected
                ? 'Impossible de joindre le serveur — vérifier que uvicorn tourne'
                : 'Carte hors tension ou WiFi perdu'}
            </div>
          </div>
          <button onClick={load} style={{
            padding: '6px 12px', borderRadius: 6,
            border: `1px solid ${C.amber}`, background: C.amberL,
            color: C.amber, fontSize: 12, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <RefreshCw size={12} />
            Réessayer
          </button>
        </div>
      )}

      {/* ─── 6 KPIs principaux ─── */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)',
        gap: 16, marginBottom: 20,
      }}>
        <KpiCard
          icon={Tag} label="ENSABLEMENT IA"
          value={fmt(ai.soiling_level, 1)} unit={noData ? '' : '%'}
          badge={noData ? 'En attente' : `${ai.status || 'Clean'}`}
          accentColor={noData ? C.text3 : statusColorValue}
          delay="0s"
        />
        <KpiCard
          icon={Zap} label="PUISSANCE"
          value={fmt(ed.power_output)} unit={noData ? '' : 'W'}
          badge={noData ? 'En attente' : 'Réelle'}
          accentColor={noData ? C.text3 : C.blue}
          delay=".05s"
        />
        <KpiCard
          icon={TrendingDown} label="PERTE"
          value={fmt(loss)} unit={noData ? '' : 'W'}
          badge={noData ? 'En attente' : 'Estimée'}
          accentColor={noData ? C.text3 : loss > 30 ? C.red : C.amber}
          delay=".10s"
        />
        <KpiCard
          icon={Target} label="PERFORMANCE"
          value={noData ? '--' : performanceRatio.toFixed(0)} unit={noData ? '' : '%'}
          badge={noData ? 'En attente' : 'PR'}
          accentColor={noData ? C.text3 : performanceRatio > 80 ? C.green : C.amber}
          delay=".15s"
        />
        <KpiCard
          icon={Sun} label="PROD. JOURNALIÈRE"
          value={noData ? '--' : dailyProduction.toFixed(1)} unit={noData ? '' : 'kWh'}
          badge={noData ? 'En attente' : 'Estimée'}
          accentColor={noData ? C.text3 : C.purple}
          delay=".20s"
        />
        <KpiCard
          icon={Thermometer} label="TEMPÉRATURE"
          value={noData ? '--' : temperature.toFixed(1)} unit="°C"
          badge={noData ? 'En attente' : 'Module'}
          accentColor={noData ? C.text3 : C.blue}
          delay=".25s"
        />
      </div>

      {/* ─── Grille principale : 2 colonnes ─── */}
      <div style={{ display: 'grid', gridTemplateColumns: '340px 1fr', gap: 16 }}>

        {/* ============ COLONNE GAUCHE ============ */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* ─── Image ESP32 + Jauge d'ensablement ─── */}
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 14, padding: 20,
          }}>
            {/* Section image */}
            <div style={{
              fontSize: 9.5, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
              <Camera size={14} /> IMAGE ESP32
            </div>
            {b64 ? (
              <img
                src={`data:image/jpeg;base64,${b64}`} alt="panneau"
                style={{ width: '100%', borderRadius: 9, objectFit: 'cover', maxHeight: 190 }}
              />
            ) : (
              <div style={{
                background: C.surface2, borderRadius: 9,
                padding: '32px 14px', textAlign: 'center', color: C.text3,
              }}>
                <Satellite size={32} style={{ marginBottom: 6, opacity: 0.7 }} />
                <div style={{ fontSize: 13, fontWeight: 500 }}>En attente ESP32…</div>
                <div style={{ fontSize: 10, marginTop: 3, fontFamily: 'monospace' }}>
                  POST /api/v1/ingest
                </div>
              </div>
            )}

            <div style={{ height: 1, background: C.border, margin: '16px 0' }} />

            {/* Section jauge d'ensablement */}
            <div style={{
              fontSize: 9.5, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
              <BarChart3 size={14} /> NIVEAU ENSABLEMENT
            </div>
            <SoilingGauge
              level={ai.soiling_level}
              status={ai.status}
              confidence={ai.confidence}
            />
          </div>

          {/* ─── Télemétrie ─── */}
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 14, padding: 20,
          }}>
            <div style={{
              fontSize: 9.5, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.blue }} />
              <Activity size={14} /> TÉLÉMÉTRIE
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9 }}>
              <TeleItem icon={Zap}   value={noData ? 0 : ed.voltage}      unit={noData ? '' : 'V'}    label="Tension" />
              <TeleItem icon={Plug}  value={noData ? 0 : ed.current}      unit={noData ? '' : 'A'}    label="Courant" />
              <TeleItem icon={Sun}   value={noData ? 0 : ed.irradiance}   unit={noData ? '' : 'W/m²'} label="Irradiance" />
              <TeleItem icon={Power} value={noData ? 0 : ed.power_output} unit={noData ? '' : 'W'}    label="Puissance" />
            </div>
          </div>

          {/* ─── Upload manuel (analyse IA) ─── */}
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 14, padding: 20,
          }}>
            <div style={{
              fontSize: 9.5, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
              <Search size={14} /> ANALYSE MANUELLE
            </div>
            <UploadZone onResult={setUploadResult} />
            {uploadResult && (
              <div style={{
                background: C.surface2, borderRadius: 9,
                padding: 11, marginTop: 9,
              }}>
                <div style={{
                  height: 3, background: statusColor(uploadResult.status),
                  borderRadius: 2, marginBottom: 8,
                }} />
                {uploadResult.image_b64 && (
                  <img
                    src={`data:image/jpeg;base64,${uploadResult.image_b64}`}
                    alt="analyse"
                    style={{
                      width: '100%', borderRadius: 7,
                      maxHeight: 130, objectFit: 'cover', marginBottom: 8,
                    }}
                  />
                )}
                <span style={{
                  fontFamily: 'Sora', fontSize: 22, fontWeight: 800,
                  color: statusColor(uploadResult.status),
                }}>
                  {uploadResult.soiling_level?.toFixed(1)}%
                </span>
                <span style={{ fontSize: 13, color: C.text2, marginLeft: 6 }}>
                  — {uploadResult.status}
                </span>
                <div style={{ fontSize: 11, color: C.text3, marginTop: 2 }}>
                  Confiance : {uploadResult.confidence?.toFixed(1)}%
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ============ COLONNE DROITE ============ */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* ─── Graphique : Puissance réelle vs Théorique ─── */}
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 14, padding: 20,
            boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
          }}>
            <div style={{
              fontSize: 10, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <TrendingUp size={14} color={C.green} />
              PUISSANCE : RÉELLE vs THÉORIQUE
            </div>

            {chartData.length === 0 ? (
              <div style={{
                height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: C.surface2, borderRadius: 8, color: C.text3, fontSize: 13,
              }}>
                <Activity size={20} style={{ marginRight: 8, opacity: 0.5 }} />
                Aucune donnée disponible
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="gPow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={C.green} stopOpacity={0.2} />
                      <stop offset="95%" stopColor={C.green} stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="gTheo" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={C.blue} stopOpacity={0.15} />
                      <stop offset="95%" stopColor={C.blue} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} strokeOpacity={0.6} />
                  <XAxis
                    dataKey="time" stroke={C.text3}
                    tick={{ fontSize: 10, fill: C.text3 }} tickLine={false}
                    axisLine={{ stroke: C.border }} padding={{ left: 10, right: 10 }}
                  />
                  <YAxis
                    stroke={C.text3} tick={{ fontSize: 10, fill: C.text3 }}
                    tickLine={false} axisLine={false} unit="W" width={40}
                  />
                  <Tooltip content={<CustomTooltip />} cursor={{ stroke: C.border, strokeWidth: 1 }} />
                  <Area
                    type="monotone" dataKey="power" stroke={C.green} strokeWidth={2.5}
                    fill="url(#gPow)" name="Puissance réelle" unit="W"
                    activeDot={{ r: 4, fill: C.green }}
                  />
                  <Line
                    type="monotone" dataKey="theoretical" stroke={C.blue} strokeWidth={2}
                    strokeDasharray="5 5" name="Puissance théorique" unit="W" dot={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* ─── Graphique : Évolution de l'ensablement ─── */}
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 14, padding: 20,
          }}>
            <div style={{
              fontSize: 10, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <TrendingDown size={14} color={C.amber} />
              ÉVOLUTION DE L'ENSABLEMENT
            </div>

            {chartData.length === 0 ? (
              <div style={{
                height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: C.surface2, borderRadius: 8, color: C.text3, fontSize: 13,
              }}>
                <Activity size={20} style={{ marginRight: 8, opacity: 0.5 }} />
                Aucune donnée disponible
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="gSoil" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={C.amber} stopOpacity={0.25} />
                      <stop offset="95%" stopColor={C.amber} stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} strokeOpacity={0.6} />
                  <XAxis
                    dataKey="time" stroke={C.text3}
                    tick={{ fontSize: 10, fill: C.text3 }} tickLine={false}
                    axisLine={{ stroke: C.border }} padding={{ left: 10, right: 10 }}
                  />
                  <YAxis
                    stroke={C.text3} tick={{ fontSize: 10, fill: C.text3 }}
                    tickLine={false} axisLine={false} unit="%" domain={[0, 100]} width={35}
                  />
                  <Tooltip content={<CustomTooltip />} cursor={{ stroke: C.border, strokeWidth: 1 }} />
                  <Area
                    type="monotone" dataKey="soiling" stroke={C.amber} strokeWidth={2.5}
                    fill="url(#gSoil)" name="Ensablement" unit="%"
                    activeDot={{ r: 4, fill: C.amber }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* ─── Statistiques globales ─── */}
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 14, padding: 20,
          }}>
            <div style={{
              fontSize: 10, fontWeight: 700, color: C.text3,
              letterSpacing: 1, textTransform: 'uppercase',
              marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <BarChart3 size={14} color={C.blue} />
              STATISTIQUES GLOBALES
            </div>

            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12,
            }}>
              <StatCard
                value={totalMeasurements}
                unit="" label="Mesures totales"
                color={C.green} icon={Database}
              />
              <StatCard
                value={averages.avg_power ?? 0}
                unit="W" label="Puissance moy."
                color={C.blue} icon={Zap} decimals={0}
              />
              <StatCard
                value={averages.avg_soiling ?? 0}
                unit="%" label="Ensablement moy."
                color={C.amber} icon={AlertTriangle} decimals={1}
              />
              <StatCard
                value={averages.avg_voltage ?? 0}
                unit="V" label="Tension moy."
                color={C.purple} icon={Activity} decimals={1}
              />
            </div>
          </div>

          {/* ─── Configuration panneaux & Analyse IA ─── */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16,
          }}>
            {/* Configuration panneaux */}
            <div style={{
              background: C.surface, border: `1px solid ${C.border}`,
              borderRadius: 14, padding: '16px 20px',
              boxShadow: '0 1px 3px rgba(13,82,52,.06), 0 4px 16px rgba(13,82,52,.05)',
            }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
              }}>
                <Tag size={16} color={C.green} />
                <span style={{ fontSize: 12, fontWeight: 600, color: C.text2 }}>
                  Configuration Panneaux
                </span>
              </div>
              <div style={{
                display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, fontSize: 11,
              }}>
                <div>
                  <span style={{ color: C.text3 }}>Surface</span><br />
                  <span style={{
                    fontFamily: 'Sora, sans-serif', fontWeight: 700, color: C.text,
                  }}>
                    {panelConfig.area} m²
                  </span>
                </div>
                <div>
                  <span style={{ color: C.text3 }}>Rendement</span><br />
                  <span style={{
                    fontFamily: 'Sora, sans-serif', fontWeight: 700, color: C.text,
                  }}>
                    {(panelConfig.efficiency * 100).toFixed(0)}%
                  </span>
                </div>
              </div>
            </div>

            {/* Analyse IA */}
            <div style={{
              background: C.surface, border: `1px solid ${C.border}`,
              borderRadius: 14, padding: '16px 20px',
              boxShadow: '0 1px 3px rgba(13,82,52,.06), 0 4px 16px rgba(13,82,52,.05)',
            }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
              }}>
                <Search size={16} color={C.green} />
                <span style={{ fontSize: 12, fontWeight: 600, color: C.text2 }}>
                  Analyse IA
                </span>
              </div>
              <div style={{
                display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, fontSize: 11,
              }}>
                <div>
                  <span style={{ color: C.text3 }}>Pertes estimées</span><br />
                  <span style={{
                    fontFamily: 'Sora, sans-serif', fontWeight: 700,
                    color: loss > 10 ? C.red : C.text,
                  }}>
                    {fmt(loss, 1)} W
                  </span>
                </div>
                <div>
                  <span style={{ color: C.text3 }}>Performance</span><br />
                  <span style={{
                    fontFamily: 'Sora, sans-serif', fontWeight: 700,
                    color: performanceRatio > 80 ? C.green : C.amber,
                  }}>
                    {performanceRatio.toFixed(0)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
