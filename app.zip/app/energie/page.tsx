'use client';

/**
 * ============================================================
 * ANALYSE ÉNERGÉTIQUE — PV Monitor
 * ============================================================
 * Analyse détaillée de la performance énergétique du panneau :
 *  - Puissance réelle vs théorique (graphique combiné)
 *  - Tension & courant (graphique double axe)
 *  - Tableau des pertes par niveau d'ensablement
 *  - KPIs : mesures, puissance moyenne, PR, specific yield, pertes, dégradation
 *
 * Fonctionnalités :
 *  - Auto-refresh toutes les 30 secondes
 *  - Filtre par période (24h, 7j, 30j, 3 mois, tout)
 *  - Valeurs sécurisées (fallbacks anti-NaN)
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================

// React
import { useState, useEffect, useCallback, useMemo } from 'react';

// Recharts
import {
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  LineChart, Line, ComposedChart, Area,
} from 'recharts';

// API & types
import {
  getPanelConfig, fetchHistory, fetchStats, fmtTime,
  type Measurement, type Stats,
} from '@/lib/api';

// Contextes
import { useRefresh } from '@/contexts/RefreshContext';
import { useDashboardReset } from '@/contexts/DashboardContext';

// Design tokens
import { C } from '@/lib/colors';

// Icônes Lucide
import {
  Hash, Zap, TrendingDown, TrendingUp, Gauge, Activity,
  ClipboardList, Target, Award, Percent,
  AlertTriangle, AlertCircle, CheckCircle, Info,
} from 'lucide-react';

// ============================================================
// UTILITAIRES
// ============================================================

/**
 * Parse un timestamp MongoDB vers un objet Date.
 * Supporte : { $date: "..." } | objet Date | chaîne ISO 8601
 */
function parseMongoDate(timestamp: any): Date | null {
  if (!timestamp) return null;

  // Format MongoDB natif
  if (typeof timestamp === 'object' && timestamp !== null && timestamp.$date) {
    return new Date(timestamp.$date);
  }

  // Déjà un objet Date
  if (timestamp instanceof Date) {
    return isNaN(timestamp.getTime()) ? null : timestamp;
  }

  // Chaîne ISO 8601
  if (typeof timestamp === 'string') {
    const date = new Date(timestamp);
    return isNaN(date.getTime()) ? null : date;
  }

  return null;
}

/**
 * Formate un timestamp de façon sécurisée.
 * Fallback sur toLocaleTimeString si fmtTime échoue.
 */
const safeFmtTime = (timestamp: string): string => {
  try {
    const formatted = fmtTime(timestamp);
    if (formatted && formatted !== '--:--') return formatted;

    const date = new Date(timestamp);
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '--:--';
  }
};

// ============================================================
// CONSTANTES MÉTIER
// ============================================================

/** Mapping période → heures (pour le filtrage des données) */
const RANGE_HOURS: Record<string, number> = {
  '24h': 24,
  '7d':  168,
  '30d': 720,
  '90d': 2160,
};

/**
 * Tableau de référence : pertes estimées par niveau d'ensablement.
 * Affiché dans la section tableau en bas de page.
 */
const LOSS_TABLE = [
  { level: '0%',   label: 'Propre',   loss: 0,  remaining: 400, action: 'Aucune action',      color: C.green,  icon: CheckCircle },
  { level: '25%',  label: 'Léger',    loss: 15, remaining: 340, action: 'Surveiller',          color: C.greenM, icon: Info },
  { level: '50%',  label: 'Moyen',    loss: 35, remaining: 260, action: 'Planifier nettoyage', color: C.amber,  icon: AlertTriangle },
  { level: '75%',  label: 'Fort',     loss: 60, remaining: 160, action: 'Nettoyage urgent',    color: '#ef6c00', icon: AlertTriangle },
  { level: '100%', label: 'Complet',  loss: 80, remaining: 80,  action: 'Immédiat',            color: C.red,    icon: AlertCircle },
];

/** Données par défaut pour le graphique principal (quand pas de données réelles) */
const EMPTY_CHART = [
  { time: '00:00', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
  { time: '04:00', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
  { time: '08:00', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
  { time: '12:00', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
  { time: '16:00', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
  { time: '20:00', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
  { time: '23:59', power: 0, pth: 0, loss: 0, volt: 0, curr: 0 },
];

/** Profil journalier par défaut (quand pas de données) */
const EMPTY_HOURLY = [
  { hour: '00h', avgPower: 0 },
  { hour: '04h', avgPower: 0 },
  { hour: '08h', avgPower: 0 },
  { hour: '12h', avgPower: 0 },
  { hour: '16h', avgPower: 0 },
  { hour: '20h', avgPower: 0 },
  { hour: '23h', avgPower: 0 },
];

// ============================================================
// SOUS-COMPOSANTS (UI réutilisables)
// ============================================================

/** Carte conteneur avec ombre portée */
const Card = ({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) => (
  <div style={{
    background: C.surface, border: `1px solid ${C.border}`,
    borderRadius: 14, padding: 20,
    boxShadow: '0 1px 3px rgba(13,82,52,.06), 0 4px 16px rgba(13,82,52,.05)',
    ...style,
  }}>{children}</div>
);

/** Titre de section avec point coloré, icône et slot droit optionnel */
const CardTitle = ({ dot = C.green, icon: Icon, text, right }: {
  dot?: string; icon: React.ElementType; text: string; right?: React.ReactNode;
}) => (
  <div style={{
    fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1,
    textTransform: 'uppercase', marginBottom: 14,
    display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'space-between',
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{ width: 5, height: 5, borderRadius: '50%', background: dot }} />
      <Icon size={14} />
      {text}
    </div>
    {right}
  </div>
);

/** Point de légende avec option traitillé */
const LegendDot = ({ color, label, dashed = false }: { color: string; label: string; dashed?: boolean }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
    <div style={{
      width: 10, height: 10, borderRadius: 2,
      background: color,
      ...(dashed && { background: 'transparent', border: `1.5px dashed ${color}` }),
    }} />
    <span style={{ fontSize: 10, color: C.text2 }}>{label}</span>
  </div>
);

/** État vide affiché quand un graphique n'a pas de données */
const EmptyState = ({ icon: Icon, title, message }: {
  icon: React.ElementType; title: string; message: string;
}) => (
  <div style={{
    height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: C.surface2, borderRadius: 10, color: C.text3,
  }}>
    <div style={{ textAlign: 'center' }}>
      <Icon size={48} style={{ marginBottom: 16, opacity: 0.5 }} />
      <div style={{ fontSize: 14, fontWeight: 500 }}>{title}</div>
      <div style={{ fontSize: 12, marginTop: 8 }}>{message}</div>
    </div>
  </div>
);

/** Tooltip personnalisé pour les graphiques Recharts */
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;

  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`,
      borderRadius: 10, padding: '12px 16px', fontSize: 12,
      boxShadow: '0 4px 16px rgba(13,82,52,.10)',
    }}>
      <div style={{ fontWeight: 700, color: C.text, marginBottom: 6 }}>{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={`${p.name}-${i}`} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          marginBottom: 2, color: p.color,
        }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: p.color }} />
          {p.name}: <b>{p.value?.toFixed(1)}{p.unit}</b>
        </div>
      ))}
    </div>
  );
};

/** Carte KPI pour les 6 métriques en haut de page */
function KpiCard({ icon: Icon, label, value, unit, accentColor }: {
  icon: React.ElementType; label: string; value: string;
  unit: string; accentColor: string;
}) {
  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
      padding: '18px 20px', boxShadow: '0 1px 3px rgba(13,82,52,.06)',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Bande colorée */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: 3, background: accentColor, borderRadius: '14px 14px 0 0',
      }} />

      {/* Icône */}
      <div style={{ fontSize: 20, marginBottom: 10 }}>
        <Icon size={24} color={accentColor} />
      </div>

      {/* Valeur */}
      <div>
        <span style={{ fontFamily: 'Sora, sans-serif', fontSize: 26, fontWeight: 800, color: C.text }}>
          {value}
        </span>
        <span style={{ fontSize: 12, color: C.text3, marginLeft: 3 }}>{unit}</span>
      </div>

      {/* Label */}
      <div style={{ fontSize: 11, color: C.text3, marginTop: 4 }}>{label}</div>
    </div>
  );
}

/** Sélecteur de période (boutons radio stylisés) */
const TimeRangeSelector = ({ value, onChange }: {
  value: string; onChange: (range: string) => void;
}) => {
  const ranges = [
    { id: '24h',  label: '24h' },
    { id: '7d',   label: '7j' },
    { id: '30d',  label: '30j' },
    { id: '90d',  label: '3 mois' },
    { id: 'all',  label: 'Tout' },
  ];

  return (
    <div style={{ display: 'flex', gap: 4, background: C.surface2, borderRadius: 6, padding: 2 }}>
      {ranges.map(range => (
        <button
          key={range.id}
          onClick={() => onChange(range.id)}
          style={{
            padding: '4px 12px', borderRadius: 4, border: 'none',
            background: value === range.id ? C.green : 'transparent',
            color: value === range.id ? 'white' : C.text2,
            fontSize: 11, fontWeight: 600, cursor: 'pointer',
          }}
        >
          {range.label}
        </button>
      ))}
    </div>
  );
};

// ============================================================
// COMPOSANT PRINCIPAL — Analyse Énergétique
// ============================================================
export default function EnergiePage() {

  // ─── Contextes ────────────────────────────────────────────
  const { autoRefresh, setLastUpdate, refreshKey } = useRefresh();
  const { isReset, clearResetFlag } = useDashboardReset();

  // ─── États ────────────────────────────────────────────────
  const [historyData, setHistoryData] = useState<Measurement[]>([]);
  const [stats, setStats]             = useState<Stats | null>(null);
  const [timeRange, setTimeRange]     = useState('all');
  const [loading, setLoading]         = useState(true);
  const [panelConfig, setPanelConfig] = useState({
    area: 1.6,
    efficiency: 0.20,
  });

  const REFRESH_INTERVAL = 30_000;

  // ==========================================================
  // EFFETS DE BORD (ordre fixe — avant tout return)
  // ==========================================================

  /** Reset si demandé par le contexte */
  useEffect(() => {
    if (isReset) {
      setHistoryData([]);
      setStats(null);
      clearResetFlag();
    }
  }, [isReset, clearResetFlag]);

  /** Chargement de la configuration des panneaux */
  useEffect(() => {
    (async () => {
      try {
        const config = await getPanelConfig();
        if (config) {
          setPanelConfig({
            area: config.panel_area_m2 ?? 1.6,
            efficiency: config.panel_efficiency ?? 0.20,
          });
        }
      } catch {
        /* valeurs par défaut déjà en place */
      }
    })();
  }, []);

  /** Chargement des données + auto-refresh */
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [h, s] = await Promise.all([
        fetchHistory(0, 0),
        fetchStats(),
      ]);

      if (h && Array.isArray(h.data)) {
        setHistoryData(h.data);
      } else {
        setHistoryData([]);
      }

      if (s) setStats(s);
      setLastUpdate(new Date());
    } catch {
      setHistoryData([]);
    } finally {
      setLoading(false);
    }
  }, [setLastUpdate]);

  useEffect(() => {
    load();
    let interval: NodeJS.Timeout | null = null;
    if (autoRefresh) interval = setInterval(load, REFRESH_INTERVAL);
    return () => { if (interval) clearInterval(interval); };
  }, [load, autoRefresh]);

  /** Rechargement manuel via refreshKey */
  useEffect(() => {
    if (refreshKey > 0) load();
  }, [refreshKey, load]);

  // ==========================================================
  // DONNÉES DÉRIVÉES (useMemo — avant tout return)
  // ==========================================================

  /** Données filtrées selon la période sélectionnée */
  const filteredHistory = useMemo(() => {
    if (!historyData.length) return [];
    if (timeRange === 'all') return historyData;

    const hours = RANGE_HOURS[timeRange] ?? 720;
    const cutoff = new Date(Date.now() - hours * 3_600_000);

    return historyData.filter(d => {
      const date = parseMongoDate(d.timestamp);
      return date ? date >= cutoff : false;
    });
  }, [historyData, timeRange]);

  /** Données formatées pour le graphique principal */
  const chartData = useMemo(() => {
    if (!filteredHistory.length) return EMPTY_CHART;

    return filteredHistory
      .filter(d => d?.timestamp)
      .map(d => {
        const power = d.electrical_data?.power_output || 0;
        const irradiance = d.electrical_data?.irradiance || 0;
        const pth = irradiance * panelConfig.area * panelConfig.efficiency;

        return {
          time: safeFmtTime(d.timestamp),
          power: Number(power.toFixed(1)),
          pth: Number(pth.toFixed(1)),
          loss: Number(Math.max(0, pth - power).toFixed(1)),
          volt: Number((d.electrical_data?.voltage || 0).toFixed(1)),
          curr: Number((d.electrical_data?.current || 0).toFixed(2)),
        };
      })
      .reverse();
  }, [filteredHistory, panelConfig]);

  /** Profil journalier moyen (puissance par heure) */
  const hourlyProfile = useMemo(() => {
    if (!filteredHistory.length) return EMPTY_HOURLY;

    const buckets: Record<number, { power: number; count: number }> = {};

    for (const d of filteredHistory) {
      try {
        const hour = new Date(d.timestamp).getHours();
        if (!buckets[hour]) buckets[hour] = { power: 0, count: 0 };
        buckets[hour].power += d.electrical_data.power_output;
        buckets[hour].count++;
      } catch {
        /* timestamp invalide — ignoré */
      }
    }

    const profile = Object.entries(buckets)
      .map(([hour, { power, count }]) => ({
        hour: `${hour}h`,
        avgPower: count > 0 ? Number((power / count).toFixed(1)) : 0,
      }))
      .sort((a, b) => parseInt(a.hour) - parseInt(b.hour));

    return profile.length ? profile : EMPTY_HOURLY;
  }, [filteredHistory]);

  /** Répartition des pertes par catégorie (pie chart) */
  const lossData = useMemo(() => {
    if (!filteredHistory.length) {
      return [
        { name: 'Ensablement', value: 0, color: C.amber },
        { name: 'Température', value: 0, color: C.red },
        { name: 'Ombrage', value: 0, color: C.blue },
        { name: 'Autres', value: 0, color: C.text3 },
      ];
    }

    const n = filteredHistory.length;
    const avgSoiling = filteredHistory.reduce((a, d) => a + (d.ai_analysis.soiling_level || 0), 0) / n;
    const avgTemp = filteredHistory.reduce((a, d) => a + (d.electrical_data.temperature || 25), 0) / n;

    const tempLoss = Math.min(30, Math.max(0, (avgTemp - 25) * 2));
    const soilingLoss = avgSoiling * 0.8;
    const shadingLoss = 5 + Math.random() * 5; // Simulation (à remplacer par calcul réel)
    const otherLoss = Math.max(0, 100 - soilingLoss - tempLoss - shadingLoss);

    return [
      { name: 'Ensablement',  value: Math.round(soilingLoss),  color: C.amber },
      { name: 'Température',  value: Math.round(tempLoss),     color: C.red },
      { name: 'Ombrage',      value: Math.round(shadingLoss),   color: C.blue },
      { name: 'Autres',       value: Math.round(otherLoss),     color: C.text3 },
    ];
  }, [filteredHistory]);

  // ==========================================================
  // MÉTRIQUES CALCULÉES
  // ==========================================================

  const n = filteredHistory.length;

  // Moyennes électriques
  const avgP = n
    ? filteredHistory.reduce((a, d) => a + d.electrical_data.power_output, 0) / n
    : 0;
  const avgV = n
    ? filteredHistory.reduce((a, d) => a + d.electrical_data.voltage, 0) / n
    : 0;
  const avgC = n
    ? filteredHistory.reduce((a, d) => a + d.electrical_data.current, 0) / n
    : 0;

  // Énergie totale (kWh)
  const totalEnergy = filteredHistory.reduce(
    (a, d) => a + d.electrical_data.power_output, 0
  ) / 1000;

  const totalTheoretical = filteredHistory.reduce(
    (a, d) => a + (d.electrical_data.irradiance * panelConfig.area * panelConfig.efficiency), 0
  ) / 1000;

  const totalLoss = Math.max(0, totalTheoretical - totalEnergy);

  // Performance Ratio (%)
  const performanceRatio = totalTheoretical > 0
    ? (totalEnergy / totalTheoretical) * 100
    : 0;

  // Specific Yield (kWh/kWp/jour)
  const specificYield = stats?.averages?.avg_power
    ? (stats.averages.avg_power * 24 / 1000)
    : 0;

  // Taux de dégradation (%/an) — valeur standard pour panneaux PV
  const degradationRate = -0.5;

  // Valeurs max pour l'axe Y du graphique
  const maxPower = Math.max(...chartData.map(d => d.power), 0);
  const maxPth = Math.max(...chartData.map(d => d.pth), 0);
  const maxY = Math.max(maxPower, maxPth, 100) * 1.1;

  // Flags pour l'état vide
  const hasNoData = chartData.length === 0
    || chartData.every(d => d.power === 0 && d.pth === 0);
  const hasNoElectrical = chartData.length === 0
    || chartData.every(d => d.volt === 0 && d.curr === 0);

  // ==========================================================
  // RENDU JSX
  // ==========================================================
  return (
    <div>

      {/* ─── En-tête : titre + sélecteur de période ─── */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        alignItems: 'center', marginBottom: 20,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <h1 style={{
            fontSize: 20, fontWeight: 700, color: C.text,
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <Zap size={24} color={C.blue} />
            Analyse Énergétique
          </h1>
          <TimeRangeSelector value={timeRange} onChange={setTimeRange} />
        </div>
      </div>

      {/* ─── 6 KPIs ─── */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)',
        gap: 16, marginBottom: 20,
      }}>
        <KpiCard
          icon={Hash} label="MESURES"
          value={String(n)} unit=""
          accentColor={C.green}
        />
        <KpiCard
          icon={Zap} label="PUISSANCE MOY."
          value={avgP.toFixed(1)} unit="W"
          accentColor={C.blue}
        />
        <KpiCard
          icon={Target} label="PERFORMANCE RATIO"
          value={performanceRatio.toFixed(1)} unit="%"
          accentColor={C.purple}
        />
        <KpiCard
          icon={Award} label="SPECIFIC YIELD"
          value={specificYield.toFixed(2)} unit="kWh/kWp"
          accentColor={C.purple}
        />
        <KpiCard
          icon={TrendingDown} label="PERTE TOTALE"
          value={totalLoss.toFixed(2)} unit="kWh"
          accentColor={C.red}
        />
        <KpiCard
          icon={Percent} label="DÉGRADATION"
          value={degradationRate.toFixed(1)} unit="%/an"
          accentColor={C.amber}
        />
      </div>

      {/* ─── Graphique principal : Puissance réelle vs théorique ─── */}
      <div style={{ marginBottom: 16 }}>
        <Card>
          <CardTitle
            icon={TrendingUp}
            text="Puissance réelle vs théorique"
            right={
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <LegendDot color={C.green} label="Réelle" />
                <LegendDot color={C.blue} label="Théorique" dashed />
                <LegendDot color={C.amber} label="Perte" />
              </div>
            }
          />

          {hasNoData ? (
            <EmptyState
              icon={Zap}
              title="Aucune donnée disponible"
              message={loading ? 'Chargement en cours…' : 'Aucune mesure dans la période sélectionnée'}
            />
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <ComposedChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis
                  dataKey="time" stroke={C.text3}
                  tick={{ fontSize: 10 }} interval="preserveStartEnd" tickMargin={8}
                />
                <YAxis
                  yAxisId="left" stroke={C.text3}
                  tick={{ fontSize: 10 }} unit="W"
                  domain={[0, 'auto']} tickMargin={8}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ stroke: C.border, strokeWidth: 1 }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11, paddingTop: 8 }} />
                <Area
                  yAxisId="left" type="monotone" dataKey="loss"
                  fill={C.amber} fillOpacity={0.3} stroke={C.amber} strokeWidth={1}
                  name="Perte" unit="W" isAnimationActive={false}
                />
                <Line
                  yAxisId="left" type="monotone" dataKey="power"
                  stroke={C.green} strokeWidth={2.5} dot={false}
                  name="Puissance réelle" unit="W" isAnimationActive={false}
                />
                <Line
                  yAxisId="left" type="monotone" dataKey="pth"
                  stroke={C.blue} strokeWidth={2} strokeDasharray="5 5" dot={false}
                  name="Puissance théorique" unit="W" isAnimationActive={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      {/* ─── Graphique : Tension & Courant ─── */}
      <div style={{ marginBottom: 16 }}>
        <Card>
          <CardTitle icon={Gauge} text="Tension & Courant" dot={C.blue} />

          {hasNoElectrical ? (
            <EmptyState
              icon={Gauge}
              title="Données non disponibles"
              message="Données de tension / courant non disponibles pour cette période"
            />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis
                  dataKey="time" stroke={C.text3}
                  tick={{ fontSize: 10 }} padding={{ left: 10, right: 10 }}
                  interval="preserveStartEnd" minTickGap={30}
                />
                <YAxis
                  yAxisId="left" stroke={C.blue}
                  tick={{ fontSize: 10 }} unit="V" domain={[0, 'auto']}
                />
                <YAxis
                  yAxisId="right" orientation="right" stroke={C.green}
                  tick={{ fontSize: 10 }} unit="A" domain={[0, 'auto']}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Line
                  yAxisId="left" type="monotone" dataKey="volt"
                  stroke={C.blue} strokeWidth={2} dot={false}
                  name="Tension" unit="V"
                />
                <Line
                  yAxisId="right" type="monotone" dataKey="curr"
                  stroke={C.green} strokeWidth={2} dot={false}
                  name="Courant" unit="A"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      {/* ─── Tableau : Pertes par niveau d'ensablement ─── */}
      <Card>
        <CardTitle icon={ClipboardList} text="Pertes par niveau d'ensablement" />
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
          <thead>
            <tr>
              {['Niveau', 'Label', 'Perte', 'Restante', 'Action'].map(h => (
                <th key={h} style={{
                  padding: '8px 12px', fontSize: 10, fontWeight: 700, color: C.text3,
                  textTransform: 'uppercase', letterSpacing: 0.7,
                  borderBottom: `1px solid ${C.border}`, textAlign: 'left',
                }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {LOSS_TABLE.map((row, i) => {
              const RowIcon = row.icon;
              return (
                <tr key={row.level} style={{ background: i % 2 === 0 ? C.surface2 : C.surface }}>
                  <td style={{ padding: '9px 12px' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
                      <span style={{
                        width: 8, height: 8, borderRadius: '50%',
                        background: row.color, display: 'inline-block',
                      }} />
                      {row.level}
                    </span>
                  </td>
                  <td style={{ padding: '9px 12px' }}>{row.label}</td>
                  <td style={{ padding: '9px 12px', fontWeight: 700, color: row.color }}>
                    {row.loss}%
                  </td>
                  <td style={{ padding: '9px 12px' }}>{row.remaining} W</td>
                  <td style={{
                    padding: '9px 12px', display: 'flex',
                    alignItems: 'center', gap: 4, fontWeight: 600, color: row.color,
                  }}>
                    <RowIcon size={12} />
                    {row.action}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
