// app/historique/page.tsx
'use client';

/**
 * ============================================================
 * PAGE HISTORIQUE DES MESURES - PV MONITOR
 * ============================================================
 * Cette page permet de consulter l'historique complet des mesures :
 * - Visualisation tabulaire avec pagination
 * - Filtres par statut, date, recherche textuelle
 * - Graphiques d'évolution (analyses par jour, puissance)
 * - Export CSV des données (sélection ou total)
 * - Statistiques globales et tendances
 * - Vue cartes alternative
 * ============================================================
 */

// ============================================================
// IMPORTS
// ============================================================
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { exportHistoryToPDF, exportHistoryToCSV } from '@/lib/exportHistory';

import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  PieChart, Pie, Cell,
} from 'recharts';
import { 
  fetchHistory, fetchStats, fmtDateTime, fmtTime, fmtDay, 
  statusColor, statusBg, type Measurement, type Stats 
} from '@/lib/api';
import { useRefresh } from '@/contexts/RefreshContext';
import { useDashboardReset } from '@/contexts/DashboardContext';

// Imports Lucide
import { 
  Calendar, Zap, BarChart3, ClipboardList, Download, 
  ChevronLeft, ChevronRight, Database, AlertCircle,
  CheckCircle, AlertTriangle, Filter, Search, X,
  TrendingUp, TrendingDown, Clock, Calendar as CalendarIcon,
  FileText, FileSpreadsheet, Eye, EyeOff,
  Percent, RefreshCw, Printer, Loader
} from 'lucide-react';

// ============================================================
// CONSTANTES DE STYLE
// ============================================================
import { C } from '@/lib/colors';

const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

// ============================================================
// COMPOSANTS UI RÉUTILISABLES
// ============================================================

/**
 * Tooltip personnalisé pour les graphiques
 */
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10,
      padding: '12px 16px', fontSize: 12, boxShadow: '0 4px 16px rgba(13,82,52,.10)'
    }}>
      <div style={{ fontWeight: 700, color: C.text, marginBottom: 6 }}>{label}</div>
      {payload.map((p: any, index: number) => (
        <div key={`${p.name}-${index}`} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2, color: p.color }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: p.color }} />
          {p.name}: <b>{p.value?.toFixed(1)}{p.unit}</b>
        </div>
      ))}
    </div>
  );
};

/**
 * Sélecteur de plage de dates (popup)
 */
const DateRangePicker = ({ startDate, endDate, onStartChange, onEndChange, onApply }: any) => {
  return (
    <div style={{
      position: 'absolute',
      top: '100%',
      right: 0,
      marginTop: 8,
      background: C.surface,
      border: `1px solid ${C.border}`,
      borderRadius: 10,
      padding: 16,
      boxShadow: '0 4px 16px rgba(13,82,52,.15)',
      zIndex: 1000,
      minWidth: 300,
    }}>
      <div style={{ marginBottom: 16 }}>
        <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>Date début</label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => onStartChange(e.target.value)}
          style={{
            width: '100%',
            padding: '8px 12px',
            borderRadius: 6,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
            fontSize: 12,
          }}
        />
      </div>
      <div style={{ marginBottom: 16 }}>
        <label style={{ fontSize: 11, color: C.text3, display: 'block', marginBottom: 4 }}>Date fin</label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => onEndChange(e.target.value)}
          style={{
            width: '100%',
            padding: '8px 12px',
            borderRadius: 6,
            border: `1px solid ${C.border}`,
            background: C.surface2,
            color: C.text,
            fontSize: 12,
          }}
        />
      </div>
      <button
        onClick={onApply}
        style={{
          width: '100%',
          padding: '8px',
          borderRadius: 6,
          border: 'none',
          background: C.green,
          color: 'white',
          fontSize: 12,
          fontWeight: 600,
          cursor: 'pointer',
        }}
      >
        Appliquer
      </button>
    </div>
  );
};

// ============================================================
// COMPOSANT PRINCIPAL
// ============================================================
export default function HistoriquePage() {
  // ==========================================================
  // CONTEXTES
  // ==========================================================
  const { autoRefresh, setLastUpdate, refreshKey } = useRefresh();
  const { isReset, clearResetFlag } = useDashboardReset();
  
  // ==========================================================
  // ÉTATS - DONNÉES PRINCIPALES
  // ==========================================================
  const [historyData, setHistoryData] = useState<{
    total: number;
    skip: number;
    limit: number;
    has_more: boolean;
    data: Measurement[];
  }>({
    total: 0,
    skip: 0,
    limit: 20,
    has_more: false,
    data: []
  });
  
  const [stats, setStats] = useState<Stats | null>(null);

  // ==========================================================
  // ÉTATS - FILTRES ET AFFICHAGE
  // ==========================================================
  const [filter, setFilter] = useState<string>('all');           // Filtre par statut
  const [searchTerm, setSearchTerm] = useState('');               // Recherche textuelle
  const [sortField, setSortField] = useState<'timestamp' | 'soiling' | 'power'>('timestamp');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [showDatePicker, setShowDatePicker] = useState(false);    // Affichage du sélecteur de dates
  const [startDate, setStartDate] = useState('');                  // Date début pour filtre
  const [endDate, setEndDate] = useState('');                      // Date fin pour filtre
  const [selectedRows, setSelectedRows] = useState<string[]>([]); // Lignes sélectionnées pour export
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table'); // Mode d'affichage
  const [currentPage, setCurrentPage] = useState(0);               // Page courante
  const [exportLoading, setExportLoading] = useState(false);       // État de l'export
  
  // ==========================================================
  // RÉFÉRENCES
  // ==========================================================
  const currentSkipRef = useRef(0);
  
  // ==========================================================
  // CONSTANTES
  // ==========================================================
  const REFRESH_INTERVAL = 30_000; // 30 secondes

  // ==========================================================
  // EFFETS DE BORD - RÉINITIALISATION
  // ==========================================================
  useEffect(() => {
    if (isReset) {
      setHistoryData({
        total: 0,
        skip: 0,
        limit: 20,
        has_more: false,
        data: []
      });
      setStats(null);
      setFilter('all');
      setSearchTerm('');
      setSelectedRows([]);
      setCurrentPage(0);
      currentSkipRef.current = 0;
      clearResetFlag();
    }
  }, [isReset, clearResetFlag]);

  // ==========================================================
  // FONCTIONS DE CHARGEMENT DES DONNÉES
  // ==========================================================

  /**
   * Charge les données depuis l'API
   * @param skip - Nombre d'éléments à sauter (pour pagination)
   */
  const load = useCallback(async (skip: number) => {
    try {
      const [h, s] = await Promise.all([
        fetchHistory(skip, 100),
        fetchStats()
      ]);
      
      if (h && h.data) {
        setHistoryData(h);
        currentSkipRef.current = skip;
      } else {
        console.warn('⚠️ fetchHistory n\'a pas retourné de données valides:', h);
        setHistoryData({
          total: 0,
          skip: skip,
          limit: 20,
          has_more: false,
          data: []
        });
        currentSkipRef.current = skip;
      }
      
      if (s) setStats(s);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('❌ Erreur chargement historique:', error);
      setHistoryData({
        total: 0,
        skip: skip,
        limit: 20,
        has_more: false,
        data: []
      });
      currentSkipRef.current = skip;
    }
  }, [setLastUpdate]);

  // ==========================================================
  // EFFETS DE BORD - CHARGEMENT INITIAL ET AUTO-REFRESH
  // ==========================================================
  
  /**
   * Chargement initial et mise en place de l'auto-refresh
   */
  useEffect(() => { 
    load(0);
    
    let interval: NodeJS.Timeout | null = null;
    
    if (autoRefresh) {
      interval = setInterval(() => {
        load(currentSkipRef.current);
      }, REFRESH_INTERVAL);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [load, autoRefresh]);

  /**
   * Rechargement manuel via refreshKey
   */
  useEffect(() => {
    if (refreshKey > 0) {
      load(currentSkipRef.current);
    }
  }, [refreshKey, load]);

  // ==========================================================
  // FONCTIONS DE PAGINATION
  // ==========================================================

  const handleNextPage = () => {
    const nextSkip = historyData.skip + historyData.limit;
    load(nextSkip);
    setCurrentPage(currentPage + 1);
  };

  const handlePrevPage = () => {
    const prevSkip = Math.max(0, historyData.skip - historyData.limit);
    load(prevSkip);
    setCurrentPage(currentPage - 1);
  };

  // ==========================================================
  // FONCTIONS DE TRI
  // ==========================================================

  const handleSort = (field: 'timestamp' | 'soiling' | 'power') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // ==========================================================
  // FONCTIONS DE SÉLECTION
  // ==========================================================

  const handleSelectAll = () => {
    if (selectedRows.length === filtered.length) {
      setSelectedRows([]);
    } else {
      setSelectedRows(filtered.map(d => d._id || ''));
    }
  };

  const handleSelectRow = (id: string) => {
    if (selectedRows.includes(id)) {
      setSelectedRows(selectedRows.filter(rowId => rowId !== id));
    } else {
      setSelectedRows([...selectedRows, id]);
    }
  };

  // ==========================================================
  // FONCTIONS D'EXPORT
  // ==========================================================

  /**
   /**
 * Export PDF des données affichées (ou sélectionnées)
 */
const handleExportPDF = async () => {
  setExportLoading(true);
  try {
    // Si des lignes sont sélectionnées, exporter seulement celles-ci
    const dataToExport = selectedRows.length > 0 
      ? filtered.filter(d => selectedRows.includes(d._id || ''))
      : filtered;
    
    // Créer un nouveau document PDF
    const doc = new jsPDF();
    
    // ===== 1. EN-TÊTE =====
    doc.setFontSize(18);
    doc.text('Rapport d\'historique des mesures', 14, 22);
    
    doc.setFontSize(11);
    doc.text(`Généré le ${new Date().toLocaleDateString('fr-FR')}`, 14, 30);
    doc.text(`${dataToExport.length} mesures exportées`, 14, 37);
    
    // ===== 2. PRÉPARATION DU TABLEAU =====
    const tableColumn = [
      'Date/Heure',
      'Device',
      'Statut',
      'Ensablement',
      'Confiance',
      'Puissance',
      'Tension',
      'Courant'
    ];
    
    const tableRows = dataToExport.map(d => [
      fmtDateTime(d.timestamp),
      d.device_id,
      d.ai_analysis.status,
      `${d.ai_analysis.soiling_level.toFixed(1)}%`,
      `${(d.ai_analysis.confidence * 100).toFixed(1)}%`,
      `${d.electrical_data.power_output.toFixed(1)} W`,
      `${d.electrical_data.voltage.toFixed(1)} V`,
      `${d.electrical_data.current.toFixed(2)} A`
    ]);
    
    // ===== 3. GÉNÉRATION DU TABLEAU =====
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 45,
      styles: { 
        fontSize: 8,
        cellPadding: 3,
      },
      headStyles: { 
        fillColor: [26, 127, 79], // Vert
        textColor: [255, 255, 255],
        fontStyle: 'bold',
      },
      alternateRowStyles: { 
        fillColor: [237, 244, 237] // Vert clair
      },
      // Coloration des statuts
      didParseCell: function(data) {
        if (data.section === 'body' && data.column.index === 2) {
          const status = data.cell.raw;
          if (status === 'Critical') {
            data.cell.styles.textColor = [192, 57, 43]; // Rouge
            data.cell.styles.fontStyle = 'bold';
          } else if (status === 'Warning') {
            data.cell.styles.textColor = [196, 125, 14]; // Orange
            data.cell.styles.fontStyle = 'bold';
          } else if (status === 'Clean') {
            data.cell.styles.textColor = [26, 127, 79]; // Vert
          }
        }
      }
    });
    
    // ===== 4. STATISTIQUES =====
    const finalY = (doc as any).lastAutoTable.finalY + 10;
    
    // Calculs des moyennes
    const avgSoiling = dataToExport.reduce((sum, d) => sum + d.ai_analysis.soiling_level, 0) / dataToExport.length;
    const avgPower = dataToExport.reduce((sum, d) => sum + d.electrical_data.power_output, 0) / dataToExport.length;
    const criticalCount = dataToExport.filter(d => d.ai_analysis.status === 'Critical').length;
    const warningCount = dataToExport.filter(d => d.ai_analysis.status === 'Warning').length;
    const cleanCount = dataToExport.filter(d => d.ai_analysis.status === 'Clean').length;
    
    doc.setFontSize(10);
    doc.text('Résumé statistique :', 14, finalY);
    doc.text(`• Ensablement moyen : ${avgSoiling.toFixed(1)}%`, 20, finalY + 7);
    doc.text(`• Puissance moyenne : ${avgPower.toFixed(1)} W`, 20, finalY + 14);
    doc.text(`• Répartition : ${cleanCount} Clean · ${warningCount} Warning · ${criticalCount} Critical`, 20, finalY + 21);
    
    // ===== 5. PIED DE PAGE =====
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.text(
        `PV Monitor - Rapport généré le ${new Date().toLocaleDateString('fr-FR')} - Page ${i}/${pageCount}`,
        14,
        doc.internal.pageSize.height - 10
      );
    }
    
    // ===== 6. TÉLÉCHARGEMENT =====
    doc.save(`historique_${new Date().toISOString().split('T')[0]}_${dataToExport.length}mesures.pdf`);
    
  } catch (error) {
    console.error('❌ Erreur export PDF:', error);
    alert('Erreur lors de l\'export PDF');
  } finally {
    setExportLoading(false);
  }
};

/**
 * Export PDF de TOUTES les données (pas seulement la page courante)
 */

  // ==========================================================
  // TRAITEMENT DES DONNÉES (MÉMORISÉ)
  // ==========================================================

  /**
   * Filtrage et tri des données selon les critères
   */
  const filtered = useMemo(() => {
    return (historyData.data || [])
      .filter(d => {
        // Filtre par statut
        if (filter !== 'all' && d.ai_analysis.status !== filter) return false;
        
        // Filtre par recherche textuelle
        if (searchTerm) {
          const searchLower = searchTerm.toLowerCase();
          return d.device_id.toLowerCase().includes(searchLower) ||
                 fmtDateTime(d.timestamp).toLowerCase().includes(searchLower);
        }
        
        // Filtre par plage de dates
        if (startDate && endDate) {
          const date = new Date(d.timestamp);
          const start = new Date(startDate);
          const end = new Date(endDate);
          end.setHours(23, 59, 59);
          return date >= start && date <= end;
        }
        
        return true;
      })
      .sort((a, b) => {
        let aVal, bVal;
        switch (sortField) {
          case 'soiling':
            aVal = a.ai_analysis.soiling_level;
            bVal = b.ai_analysis.soiling_level;
            break;
          case 'power':
            aVal = a.electrical_data.power_output;
            bVal = b.electrical_data.power_output;
            break;
          default: // timestamp
            aVal = new Date(a.timestamp).getTime();
            bVal = new Date(b.timestamp).getTime();
        }
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
      });
  }, [historyData.data, filter, searchTerm, startDate, endDate, sortField, sortDirection]);

  /**
   * Données pour les graphiques journaliers
   */
  const chartData = useMemo(() => {
    return (stats?.daily ?? [])
      .filter(d => d && d.day)
      .map(d => ({
        day: fmtDay(d.day),
        count: d.count || 0,
        soiling: d.avg_soiling || 0,
        power: d.avg_power || 0,
      }));
  }, [stats]);

  /**
   * Calcul de la tendance d'ensablement
   */
  const trendSoiling = useMemo(() => {
    if (chartData.length < 2) return '0';
    const first = chartData[0].soiling;
    const last = chartData[chartData.length - 1].soiling;
    return first > 0 ? ((last - first) / first * 100).toFixed(1) : '0';
  }, [chartData]);

  /**
   * Calcul de la tendance de puissance
   */
  const trendPower = useMemo(() => {
    if (chartData.length < 2) return '0';
    const first = chartData[0].power;
    const last = chartData[chartData.length - 1].power;
    return first > 0 ? ((last - first) / first * 100).toFixed(1) : '0';
  }, [chartData]);

  // ==========================================================
  // RENDU DU COMPOSANT
  // ==========================================================
  return (
    <div>
      {/* ==================================================== */}
      {/* EN-TÊTE AVEC RECHERCHE */}
      {/* ==================================================== */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
          <Database size={24} color={C.green} />
          Historique des mesures
        </h1>
        
        <div style={{ display: 'flex', gap: 8 }}>
          
          {/* ================================================ */}
          {/* BARRE DE RECHERCHE */}
          {/* ================================================ */}
         {/*  <div style={{
            display: 'flex',
            alignItems: 'center',
            background: C.surface2,
            borderRadius: 8,
            padding: '0 8px',
          }}>
            <Search size={16} color={C.text3} />
            <input
              type="text"
              placeholder="Rechercher..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                padding: '8px',
                border: 'none',
                background: 'transparent',
                outline: 'none',
                fontSize: 13,
                width: 200,
              }}
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} style={{ border: 'none', background: 'transparent', cursor: 'pointer' }}>
                <X size={14} color={C.text3} />
              </button>
            )}
          </div>*/}

          {/* ================================================ */}
          {/* SÉLECTEUR DE VUE (TABLEAU / CARTES) */}
          {/* ================================================ */}
          <div style={{ display: 'flex', gap: 4, background: C.surface2, borderRadius: 6, padding: 2 }}>
            <button
              onClick={() => setViewMode('table')}
              style={{
                padding: '6px 12px',
                borderRadius: 4,
                border: 'none',
                background: viewMode === 'table' ? C.green : 'transparent',
                color: viewMode === 'table' ? 'white' : C.text2,
                cursor: 'pointer',
              }}
              title="Vue tableau"
            >
              <ClipboardList size={14} />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              style={{
                padding: '6px 12px',
                borderRadius: 4,
                border: 'none',
                background: viewMode === 'cards' ? C.green : 'transparent',
                color: viewMode === 'cards' ? 'white' : C.text2,
                cursor: 'pointer',
              }}
              title="Vue cartes"
            >
              <Eye size={14} />
            </button>
          </div>

          {/* ================================================ */}
          {/* FILTRE PAR DATE */}
          {/* ================================================ */}
          {/*  <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowDatePicker(!showDatePicker)}
              style={{
                padding: '6px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: startDate ? C.greenL : C.surface,
                color: startDate ? C.green : C.text2,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              <CalendarIcon size={14} />
              {startDate ? 'Dates' : 'Période'}
            </button>
            {showDatePicker && (
              <DateRangePicker
                startDate={startDate}
                endDate={endDate}
                onStartChange={setStartDate}
                onEndChange={setEndDate}
                onApply={() => {
                  setShowDatePicker(false);
                  load(0);
                }}
              />
            )}
          </div>*/}
        </div>
      </div>

      {/* ==================================================== */}
      {/* STATISTIQUES RAPIDES (CARTES EN HAUT) */}
      {/* ==================================================== */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 16, marginBottom: 20 }}>
        
        {/* Total mesures */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '16px', borderTop: `3px solid ${C.green}`,
        }}>
          <Database size={20} color={C.green} />
          <div style={{ fontFamily: 'Sora', fontSize: 24, fontWeight: 800, color: C.green, marginTop: 8 }}>
            {stats?.total ?? historyData.total}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Total mesures</div>
        </div>

        {/* Clean */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '16px', borderTop: `3px solid ${C.green}`,
        }}>
          <CheckCircle size={20} color={C.green} />
          <div style={{ fontFamily: 'Sora', fontSize: 24, fontWeight: 800, color: C.green, marginTop: 8 }}>
            {stats?.distribution?.Clean ?? 0}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Clean</div>
        </div>

        {/* Warning */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '16px', borderTop: `3px solid ${C.amber}`,
        }}>
          <AlertTriangle size={20} color={C.amber} />
          <div style={{ fontFamily: 'Sora', fontSize: 24, fontWeight: 800, color: C.amber, marginTop: 8 }}>
            {stats?.distribution?.Warning ?? 0}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Warning</div>
        </div>

        {/* Critical */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '16px', borderTop: `3px solid ${C.red}`,
        }}>
          <AlertCircle size={20} color={C.red} />
          <div style={{ fontFamily: 'Sora', fontSize: 24, fontWeight: 800, color: C.red, marginTop: 8 }}>
            {stats?.distribution?.Critical ?? 0}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Critical</div>
        </div>

        {/* Tendance ensablement */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '16px', borderTop: `3px solid ${C.blue}`,
        }}>
          <TrendingUp size={20} color={C.blue} />
          <div style={{ fontFamily: 'Sora', fontSize: 24, fontWeight: 800, color: C.blue, marginTop: 8 }}>
            {trendSoiling}%
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Tendance ensablement</div>
        </div>

        {/* Taux de propreté */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '16px', borderTop: `3px solid ${C.purple}`,
        }}>
          <Percent size={20} color={C.purple} />
          <div style={{ fontFamily: 'Sora', fontSize: 24, fontWeight: 800, color: C.purple, marginTop: 8 }}>
            {((stats?.distribution?.Clean ?? 0) / (stats?.total || 1) * 100).toFixed(0)}%
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Taux de propreté</div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* GRAPHIQUES */}
      {/* ==================================================== */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        
        {/* GRAPHIQUE : ANALYSES PAR JOUR */}
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
              <Calendar size={14} /> ANALYSES PAR JOUR
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 11, color: parseFloat(trendSoiling) > 0 ? C.red : C.green }}>
                {parseFloat(trendSoiling) > 0 ? '↗' : '↘'} {Math.abs(parseFloat(trendSoiling))}%
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
              <XAxis dataKey="day" stroke={C.text3} tick={{ fontSize: 10 }} padding={{ left: 10, right: 10 }} />
              <YAxis yAxisId="l" stroke={C.green} tick={{ fontSize: 10 }} />
              <YAxis yAxisId="r" orientation="right" stroke={C.amber} tick={{ fontSize: 10 }} unit="%" />
              <Tooltip content={<CustomTooltip />} />
              <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
              <Bar yAxisId="l" dataKey="count" fill={C.green} name="Analyses" radius={[4,4,0,0]} />
              <Line yAxisId="r" type="monotone" dataKey="soiling" stroke={C.amber} strokeWidth={2} name="Ensablement moy." unit="%" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* GRAPHIQUE : PUISSANCE JOURNALIÈRE */}
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.blue }} />
              <Zap size={14} /> PUISSANCE JOURNALIÈRE
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 11, color: parseFloat(trendPower) > 0 ? C.green : C.red }}>
                {parseFloat(trendPower) > 0 ? '↗' : '↘'} {Math.abs(parseFloat(trendPower))}%
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
              <defs>
                <linearGradient id="colorPower" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.blue} stopOpacity={0.3}/>
                  <stop offset="95%" stopColor={C.blue} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
              <XAxis dataKey="day" stroke={C.text3} tick={{ fontSize: 10 }} padding={{ left: 10, right: 10 }} />
              <YAxis stroke={C.text3} tick={{ fontSize: 10 }} unit="W" />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="power" stroke={C.blue} strokeWidth={2} fill="url(#colorPower)" name="Puissance moy." unit="W" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ==================================================== */}
      {/* TABLEAU / CARTES */}
      {/* ==================================================== */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 20 }}>
        
        {/* ================================================ */}
        {/* EN-TÊTE DE LA SECTION HISTORIQUE */}
        {/* ================================================ */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
            <ClipboardList size={14} /> HISTORIQUE — {filtered.length} AFFICHÉS / {historyData.total} TOTAL
          </div>
          
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            
            {/* ============================================ */}
            {/* FILTRES PAR STATUT */}
            {/* ============================================ */}
            <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
              <Filter size={14} color={C.text3} />
              {['all','Clean','Warning','Critical'].map(f => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  style={{
                    padding: '4px 10px',
                    borderRadius: 99,
                    fontSize: 11,
                    fontWeight: 600,
                    cursor: 'pointer',
                    border: 'none',
                    background: filter === f 
                      ? f === 'all' ? C.green 
                        : f === 'Clean' ? C.green 
                        : f === 'Warning' ? C.amber 
                        : C.red
                      : C.surface2,
                    color: filter === f ? '#fff' : C.text2,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                  }}
                >
                  {f === 'all' && 'Tous'}
                  {f === 'Clean' && <><CheckCircle size={12} /> Clean</>}
                  {f === 'Warning' && <><AlertTriangle size={12} /> Warning</>}
                  {f === 'Critical' && <><AlertCircle size={12} /> Critical</>}
                </button>
              ))}
            </div>

            {/* ============================================ */}
            {/* ACTIONS D'EXPORT */}
            {/* ============================================ */}
            
           {/* Boutons d'export */}
<div style={{ display: 'flex', gap: 8, marginBottom: 0 }}>
  {/* Export PDF sélection/page courante */}
  <button
    onClick={handleExportPDF}
    disabled={exportLoading}
    style={{
                padding: '1px 3px',
                borderRadius: 99,
                fontSize: 11,
                fontWeight: 600,
                cursor: 'pointer',
                border: `1.5px solid ${C.blue}`,
                color: C.blue,
                textDecoration: 'none',
                background: 'transparent',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
  >
    {exportLoading ? <Loader size={16} className="spin" /> : <Download size={16} />}
    {exportLoading ? 'Génération...' : 'Export PDF'}
  </button>
  
  
</div>
           
          </div>
        </div>

        {/* ================================================ */}
        {/* AFFICHAGE CONDITIONNEL : TABLEAU OU CARTES */}
        {/* ================================================ */}
        
        {viewMode === 'table' ? (
          /* ------------------------------------------------ */
          /* VUE TABLEAU */
          /* ------------------------------------------------ */
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
              <thead>
                <tr>
                  <th style={{ padding: '9px 13px', width: 30 }}>
                    <input
                      type="checkbox"
                      checked={selectedRows.length === filtered.length && filtered.length > 0}
                      onChange={handleSelectAll}
                    />
                  </th>
                  {['Timestamp','Device','Statut','Ensablement','Confiance','Puissance','Tension','Courant'].map(h => (
                    <th
                      key={h}
                      onClick={() => {
                        if (h === 'Ensablement') handleSort('soiling');
                        if (h === 'Puissance') handleSort('power');
                        if (h === 'Timestamp') handleSort('timestamp');
                      }}
                      style={{
                        padding: '9px 13px',
                        fontSize: 10,
                        fontWeight: 700,
                        color: C.text3,
                        textTransform: 'uppercase',
                        letterSpacing: .7,
                        borderBottom: `1px solid ${C.border}`,
                        textAlign: 'left',
                        whiteSpace: 'nowrap',
                        cursor: (h === 'Ensablement' || h === 'Puissance' || h === 'Timestamp') ? 'pointer' : 'default',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                        {h}
                        {sortField === 
                          (h === 'Ensablement' ? 'soiling' : 
                           h === 'Puissance' ? 'power' : 
                           h === 'Timestamp' ? 'timestamp' : '') && (
                          <span>{sortDirection === 'asc' ? '↑' : '↓'}</span>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan={9} style={{ padding: '28px', textAlign: 'center', color: C.text3 }}>Aucune donnée</td></tr>
                ) : filtered.map((doc, index) => {
                  const ai = doc.ai_analysis;
                  const ed = doc.electrical_data;
                  const sc = statusColor(ai.status);
                  const StatusIcon = ai.status === 'Clean' ? CheckCircle : 
                                     ai.status === 'Warning' ? AlertTriangle : AlertCircle;
                  return (
                    <tr key={`row-${doc._id || `${doc.timestamp}-${doc.device_id}`}-${index}`} style={{ background: index % 2 === 0 ? C.surface2 : C.surface }}>
                      <td style={{ padding: '9px 13px' }}>
                        <input
                          type="checkbox"
                          checked={selectedRows.includes(doc._id || '')}
                          onChange={() => handleSelectRow(doc._id || '')}
                        />
                      </td>
                      <td style={{ padding: '9px 13px', whiteSpace: 'nowrap', fontSize: 12 }}>
                        {fmtDateTime(doc.timestamp)}
                      </td>
                      <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontSize: 11.5 }}>
                        {doc.device_id}
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        <span style={{
                          padding: '3px 10px',
                          borderRadius: 99,
                          fontSize: 11,
                          fontWeight: 700,
                          background: statusBg(ai.status),
                          color: sc,
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                          width: 'fit-content'
                        }}>
                          <StatusIcon size={12} />
                          {ai.status}
                        </span>
                      </td>
                      <td style={{ padding: '9px 13px', fontWeight: 700, color: sc }}>
                        {ai.soiling_level.toFixed(1)}%
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        {(ai.confidence * 100).toFixed(1)}%
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        {ed.power_output.toFixed(1)} W
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        {ed.voltage.toFixed(1)} V
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        {ed.current.toFixed(2)} A
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          /* ------------------------------------------------ */
          /* VUE CARTES */
          /* ------------------------------------------------ */
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
            {filtered.slice(0, 12).map((doc, index) => {
              const ai = doc.ai_analysis;
              const ed = doc.electrical_data;
              const sc = statusColor(ai.status);
              const StatusIcon = ai.status === 'Clean' ? CheckCircle : 
                                 ai.status === 'Warning' ? AlertTriangle : AlertCircle;
              return (
                <div
                  key={`card-${doc._id || `${doc.timestamp}-${doc.device_id}`}-${index}`}
                  style={{
                    background: C.surface2,
                    border: `1px solid ${C.border}`,
                    borderRadius: 10,
                    padding: 16,
                    borderTop: `3px solid ${sc}`,
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <span style={{ fontSize: 11, color: C.text3 }}>
                      <Clock size={12} style={{ marginRight: 4 }} />
                      {fmtDateTime(doc.timestamp)}
                    </span>
                    <span style={{
                      padding: '3px 8px',
                      borderRadius: 99,
                      fontSize: 11,
                      fontWeight: 700,
                      background: statusBg(ai.status),
                      color: sc,
                      display: 'flex',
                      alignItems: 'center',
                      gap: 4,
                    }}>
                      <StatusIcon size={12} />
                      {ai.status}
                    </span>
                  </div>
                  
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ fontSize: 24, fontWeight: 800, color: sc }}>
                      {ai.soiling_level.toFixed(1)}%
                    </div>
                    <div style={{ fontSize: 11, color: C.text3 }}>Ensablement</div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{ed.power_output.toFixed(0)} W</div>
                      <div style={{ fontSize: 10, color: C.text3 }}>Puissance</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{ed.voltage.toFixed(1)} V</div>
                      <div style={{ fontSize: 10, color: C.text3 }}>Tension</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{ed.current.toFixed(2)} A</div>
                      <div style={{ fontSize: 10, color: C.text3 }}>Courant</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{(ai.confidence * 100).toFixed(0)}%</div>
                      <div style={{ fontSize: 10, color: C.text3 }}>Confiance</div>
                    </div>
                  </div>
                  
                  <div style={{ marginTop: 12, fontSize: 11, color: C.text2 }}>
                    {doc.device_id}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ================================================ */}
        {/* PAGINATION */}
        {/* ================================================ */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginTop: 16,
          paddingTop: 16,
          borderTop: `1px solid ${C.border}`
        }}>
          <div style={{ fontSize: 12, color: C.text3 }}>
            <span style={{ fontWeight: 600, color: C.text }}>{filtered.length}</span> éléments affichés
            {selectedRows.length > 0 && (
              <span style={{ marginLeft: 8, color: C.green }}>
                ({selectedRows.length} sélectionnés)
              </span>
            )}
          </div>
          
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={handlePrevPage}
              disabled={historyData.skip === 0}
              style={{
                padding: '6px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: historyData.skip === 0 ? C.surface2 : C.surface,
                color: historyData.skip === 0 ? C.text3 : C.text,
                cursor: historyData.skip === 0 ? 'not-allowed' : 'pointer',
                fontSize: 12,
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              <ChevronLeft size={14} /> Précédent
            </button>
            
            <span style={{
              padding: '6px 12px',
              background: C.surface2,
              borderRadius: 6,
              fontSize: 12,
              color: C.text2,
            }}>
              Page {Math.floor(historyData.skip / historyData.limit) + 1} / {Math.ceil(historyData.total / historyData.limit)}
            </span>
            
            <button
              onClick={handleNextPage}
              disabled={!historyData.has_more}
              style={{
                padding: '6px 12px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: !historyData.has_more ? C.surface2 : C.surface,
                color: !historyData.has_more ? C.text3 : C.text,
                cursor: !historyData.has_more ? 'not-allowed' : 'pointer',
                fontSize: 12,
                display: 'flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              Suivant <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}