// ============================================================
// PAGE MAINTENANCE - PV MONITOR
// ============================================================
// Cette page permet de gérer les interventions de maintenance
// sur les panneaux solaires (nettoyages, réparations, inspections).
// ============================================================
// 
// 📋 FONCTIONNALITÉS :
// - Affichage des alertes d'ensablement (Critical, Warning)
// - Analyse rapide d'image (upload + IA)
// - Gestion CRUD des interventions (ajout, modification, suppression)
// - Filtrage par statut (planifiée, en cours, terminée, annulée)
// - KPIs de maintenance (interventions totales, terminées, coûts)
// 
// 🧩 COMPOSANTS UTILISÉS :
// - CacheMonitor : Affiche les statistiques du cache IA
// - Icônes Lucide : Toute la bibliothèque d'icônes
// 
// 📦 CONTEXTES :
// - useRefresh : Gère le rafraîchissement automatique
// - useDashboardReset : Permet de réinitialiser le dashboard
// 
// 🔄 ÉTATS PRINCIPAUX :
// - historyData : Historique des mesures
// - interventions : Liste des interventions
// - result : Résultat de l'analyse d'image
// - formData : Données du formulaire d'intervention
// 
// ============================================================

'use client';

import { useState, useEffect, useCallback } from 'react';
import { 
  fetchHistory, fetchRecommendation, statusColor, statusBg, 
  fmtDateTime, analyzeImage, type Measurement, type Recommendation 
} from '@/lib/api';
import CacheMonitor from '@/components/CacheMonitor';
import { useRefresh } from '@/contexts/RefreshContext';
import { useDashboardReset } from '@/contexts/DashboardContext';
import { exportToPDF } from '@/lib/exportPdf';
// Imports des nouvelles fonctions API
import { 
  fetchInterventions, 
  createIntervention, 
  updateIntervention, 
  deleteIntervention,
  type Intervention 
} from '@/lib/api';

// Imports Lucide
import { 
  Bell, AlertTriangle, AlertCircle, CheckCircle, 
  Upload, Lightbulb, Wrench, Activity, Clock, 
  Loader, Camera, FileText, Calendar,
  TrendingUp, TrendingDown, Gauge, Target,
  Download, Plus, Edit, Trash2,
  Droplets, Wind, Calendar as CalendarIcon,
  User, Check,
  Filter, RefreshCw, Eye, Save, X
} from 'lucide-react';

// ============================================================
// 🎨 PALETTE DE COULEURS CONSTANTE
// ============================================================
import { C } from '@/lib/colors';

// ============================================================
// 📝 TYPES POUR LE FORMULAIRE D'INTERVENTION
// ============================================================

interface InterventionFormData {
  date: string;
  type: Intervention['type'];
  device_id: string;
  technician: string;
  notes: string;
  cost: number;
 // before_level: number;
 // after_level: number;
  status: Intervention['status'];
}

// Valeur par défaut du formulaire (nouvelle intervention)
const defaultFormData: InterventionFormData = {
  date: new Date().toISOString().split('T')[0], // Date du jour au format YYYY-MM-DD
  type: 'cleaning',
  device_id: '',
  technician: '',
  notes: '',
  cost: 0,
  //before_level: 0,
  //after_level: 0,
  status: 'planned' // Planifiée par défaut
};

// ============================================================
// 🏠 COMPOSANT PRINCIPAL
// ============================================================
export default function MaintenancePage() {
  // ==========================================================
  // 📦 ÉTATS (useState)
  // ==========================================================
  const { autoRefresh, setLastUpdate, refreshKey } = useRefresh();
  const { isReset, clearResetFlag } = useDashboardReset();
  
  const [historyData, setHistoryData] = useState<Measurement[]>([]);
  const [rec, setRec] = useState<Recommendation | null>(null);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedIntervention, setSelectedIntervention] = useState<Intervention | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [loadingInterventions, setLoadingInterventions] = useState(false);
  
  // Formulaire
  const [formData, setFormData] = useState<InterventionFormData>(defaultFormData);
  
  // Interventions (maintenant depuis l'API)
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  
  const REFRESH_INTERVAL = 30_000; // 30 secondes

  // ==========================================================
  // 🔄 FONCTIONS DE CHARGEMENT (useCallback)
  // ==========================================================

  /**
   * Charge la liste des interventions depuis l'API
   * Applique le filtre par statut si nécessaire
   */
  const loadInterventions = useCallback(async () => {
    setLoadingInterventions(true);
    try {
      console.log('🔄 Chargement des interventions depuis l\'API');
      const data = await fetchInterventions(
        undefined,  // deviceId (tous)
        filterStatus === 'all' ? undefined : filterStatus
      );
      setInterventions(data);
      console.log(`✅ ${data.length} interventions chargées`);
    } catch (error) {
      console.error('❌ Erreur chargement interventions:', error);
    } finally {
      setLoadingInterventions(false);
    }
  }, [filterStatus]);

  /**
   * Charge les données principales (historique + recommandation)
   */
  const load = useCallback(async () => {
    try {
      const [h, r] = await Promise.all([
        fetchHistory(0, 100),
        fetchRecommendation()
      ]);
      
      if (h && Array.isArray(h.data)) {
        setHistoryData(h.data);
      } else {
        console.warn('⚠️ fetchHistory n\'a pas retourné un tableau valide:', h);
        setHistoryData([]);
      }
      
      if (r) setRec(r);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('❌ Erreur chargement maintenance:', error);
      setHistoryData([]);
    }
  }, [setLastUpdate]);

  // ==========================================================
  // ⚡ EFFETS (useEffect)
  // ==========================================================

  /**
   * Effet de réinitialisation du dashboard
   */
  useEffect(() => {
    if (isReset) {
      setHistoryData([]);
      setRec(null);
      setResult(null);
      clearResetFlag();
    }
  }, [isReset, clearResetFlag]);

  /**
   * Chargement initial + rafraîchissement automatique
   */
  useEffect(() => { 
    load();
    loadInterventions();
    
    let interval: NodeJS.Timeout | null = null;
    
    if (autoRefresh) {
      interval = setInterval(() => {
        load();
        loadInterventions();
      }, REFRESH_INTERVAL);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [load, loadInterventions, autoRefresh]);

  /**
   * Recharge les interventions quand le filtre change
   */
  useEffect(() => {
    loadInterventions();
  }, [filterStatus, loadInterventions]);

  /**
   * Recharge quand refreshKey change (rafraîchissement manuel)
   */
  useEffect(() => {
    if (refreshKey > 0) {
      load();
      loadInterventions();
    }
  }, [refreshKey, load, loadInterventions]);

  // ==========================================================
  // 📊 DONNÉES CALCULÉES (dérivées des états)
  // ==========================================================

  // Alertes filtrées par statut
  const alerts = historyData.filter(d => ['Critical','Warning'].includes(d.ai_analysis.status));
  const critical = historyData.filter(d => d.ai_analysis.status === 'Critical').length;
  const warning = historyData.filter(d => d.ai_analysis.status === 'Warning').length;
  const clean = historyData.filter(d => d.ai_analysis.status === 'Clean').length;

  // Statistiques de maintenance
  const totalCost = interventions.reduce((sum, i) => sum + (i.status === 'completed' ? i.cost : 0), 0);
  const avgImprovement = interventions
    .filter(i => i.status === 'completed' && i.after_level < i.before_level)
    .reduce((sum, i) => sum + (i.before_level - i.after_level), 0) / 
    (interventions.filter(i => i.status === 'completed').length || 1);

  // Couleur de la recommandation
  const rc = rec?.color ?? C.green;

  // Les interventions filtrées (déjà filtrées par l'API)
  const filteredInterventions = interventions;

  // ==========================================================
  // 🎯 GESTIONNAIRES D'ÉVÉNEMENTS
  // ==========================================================

  /**
   * Analyse une image uploadée
   */
  const handleFile = async (file: File) => {
    setLoading(true);
    const r = await analyzeImage(file);
    setLoading(false);
    if (r) setResult(r);
  };

  /**
   * Ouvre le modal d'ajout d'intervention
   */
  const handleAddIntervention = () => {
    setSelectedIntervention(null);
    setFormData(defaultFormData);
    setShowAddModal(true);
  };

  /**
   * Ouvre le modal d'édition avec les données existantes
   */
  const handleEditIntervention = (intervention: Intervention) => {
    setSelectedIntervention(intervention);
    setFormData({
      date: intervention.date,
      type: intervention.type,
      device_id: intervention.device_id,
      technician: intervention.technician,
      notes: intervention.notes,
      cost: intervention.cost,
      //before_level: intervention.before_level,
      //after_level: intervention.after_level,
      status: intervention.status
    });
    setShowAddModal(true);
  };

  /**
   * Supprime une intervention après confirmation
   */
  const handleDeleteIntervention = async (id: string) => {
    if (confirm('Supprimer cette intervention ?')) {
      const success = await deleteIntervention(id);
      if (success) {
        setInterventions(interventions.filter(i => i.id !== id));
      }
    }
  };

  /**
   * Sauvegarde une intervention (création ou modification)
   */
  const handleSaveIntervention = async () => {
    setLoading(true);
    
    try {
      if (selectedIntervention) {
        // Édition
        console.log('✏️ Mise à jour intervention:', selectedIntervention.id, formData);
        const updated = await updateIntervention(selectedIntervention.id, formData);
        if (updated) {
          setInterventions(interventions.map(i => 
            i.id === selectedIntervention.id ? updated : i
          ));
        }
      } else {
        // Nouvelle
        console.log('➕ Création nouvelle intervention:', formData);
        const newIntervention = await createIntervention(formData);
        if (newIntervention) {
          setInterventions([...interventions, newIntervention]);
        }
      }
      setShowAddModal(false);
    } catch (error) {
      console.error('❌ Erreur lors de la sauvegarde:', error);
      alert('Erreur lors de la sauvegarde');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Met à jour le formulaire quand l'utilisateur change un champ
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  // ==========================================================
  // 🎨 RENDU DU COMPOSANT (JSX)
  // ==========================================================

  return (
    <div>
      {/* ===== EN-TÊTE ===== */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, display: 'flex', alignItems: 'center', gap: 8 }}>
          <Wrench size={24} color={C.blue} />
          Maintenance & Interventions
        </h1>
        <div style={{ display: 'flex', gap: 8 }}>
         {/*
          <button
            onClick={handleAddIntervention}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              border: 'none',
              background: C.green,
              color: 'white',
              fontSize: 13,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <Plus size={16} />
            Nouvelle intervention
          </button>
            */}
        </div>
      </div>

      {/* ===== BANNIÈRE RECOMMANDATION ===== */}
      {rec && (
        <div className="fade-up" style={{
          borderRadius: 13, padding: '16px 20px',
          display: 'flex', alignItems: 'center', gap: 14,
          marginBottom: 20, border: `1px solid ${C.border}`,
          borderLeft: `4px solid ${rc}`,
          background: `${rc}08`,
          justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ 
              width: 46, height: 46, borderRadius: 11, 
              background: `${rc}18`, 
              display: 'flex', alignItems: 'center', justifyContent: 'center', 
              flexShrink: 0 
            }}>
              <Bell size={24} color={rc} />
            </div>
            <div>
              <div style={{ fontFamily: 'Sora, sans-serif', fontSize: 17, fontWeight: 700, color: rc }}>
                {rec.action}
              </div>
              <div style={{ fontSize: 12.5, color: C.text2, marginTop: 2 }}>{rec.reason}</div>
            </div>
          </div>
          <button
            onClick={handleAddIntervention}
            style={{
              padding: '6px 12px',
              borderRadius: 6,
              border: `1px solid ${rc}`,
              background: 'transparent',
              color: rc,
              fontSize: 12,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 4,
            }}
          >
            <Plus size={12} />
            Planifier intervention
          </button>
        </div>
      )}

      {/* ===== CACHE MONITOR ===== */}
      <div style={{ marginBottom: 20 }}>
        <CacheMonitor />
      </div>

      {/* ===== KPIS MAINTENANCE (4 CARTES) ===== */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 20 }}>
        {/* Carte 1 : Interventions totales */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '18px 20px', borderTop: `3px solid ${C.blue}`,
        }}>
          <Wrench size={24} color={C.blue} />
          <div style={{ fontFamily: 'Sora', fontSize: 26, fontWeight: 800, color: C.blue, marginTop: 8 }}>
            {loadingInterventions ? '...' : interventions.length}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Interventions totales</div>
        </div>

        {/* Carte 2 : Interventions terminées */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '18px 20px', borderTop: `3px solid ${C.green}`,
        }}>
          <CheckCircle size={24} color={C.green} />
          <div style={{ fontFamily: 'Sora', fontSize: 26, fontWeight: 800, color: C.green, marginTop: 8 }}>
            {loadingInterventions ? '...' : interventions.filter(i => i.status === 'completed').length}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Terminées</div>
        </div>

        {/* Carte 3 : Interventions planifiées */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '18px 20px', borderTop: `3px solid ${C.amber}`,
        }}>
          <Calendar size={24} color={C.amber} />
          <div style={{ fontFamily: 'Sora', fontSize: 26, fontWeight: 800, color: C.amber, marginTop: 8 }}>
            {loadingInterventions ? '...' : interventions.filter(i => i.status === 'planned').length}
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Planifiées</div>
        </div>

        {/* Carte 4 : Amélioration moyenne */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
          padding: '18px 20px', borderTop: `3px solid ${C.purple}`,
        }}>
          <TrendingDown size={24} color={C.purple} />
          <div style={{ fontFamily: 'Sora', fontSize: 26, fontWeight: 800, color: C.purple, marginTop: 8 }}>
            {loadingInterventions ? '...' : avgImprovement.toFixed(0)}%
          </div>
          <div style={{ fontSize: 11, color: C.text3 }}>Amélioration moyenne</div>
        </div>
      </div>

      {/* ===== COMPTEURS D'ALERTES (3 CARTES) ===== */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 20 }}>
        {[
          { val: critical, label: 'Urgent (Critical)', icon: AlertTriangle, color: C.red },
          { val: warning, label: 'À surveiller (Warning)', icon: AlertCircle, color: C.amber },
          { val: clean, label: 'OK (Clean)', icon: CheckCircle, color: C.green },
        ].map((k, i) => (
          <div key={k.label} className="fade-up" style={{
            background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
            padding: '20px', textAlign: 'center',
            boxShadow: '0 1px 3px rgba(13,82,52,.06)',
            borderTop: `3px solid ${k.color}`,
            animationDelay: `${i * .05}s`,
          }}>
            <k.icon size={32} color={k.color} style={{ marginBottom: 8 }} />
            <div style={{ fontFamily: 'Sora', fontSize: 36, fontWeight: 800, color: k.color }}>{k.val}</div>
            <div style={{ fontSize: 12, color: C.text3, marginTop: 4 }}>{k.label}</div>
          </div>
        ))}
      </div>

      {/* ===== SECTION 2 COLONNES ===== */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* ===== COLONNE GAUCHE : ALERTES RÉCENTES ===== */}
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 20, boxShadow: '0 1px 3px rgba(13,82,52,.06)' }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.red }} />
            <AlertTriangle size={14} color={C.red} /> MESURES NÉCESSITANT ATTENTION ({alerts.length})
          </div>

          {alerts.length === 0 ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 13px', borderRadius: 9, border: `1px solid ${C.border}`, borderLeft: `3px solid ${C.green}` }}>
              <CheckCircle size={16} color={C.green} />
              <span style={{ fontSize: 13, fontWeight: 600, color: C.green }}>Aucune alerte récente</span>
            </div>
          ) : (
            alerts.slice(0, 8).map((doc, i) => {
              const sc = statusColor(doc.ai_analysis.status);
              const Icon = doc.ai_analysis.status === 'Critical' ? AlertCircle : 
                          doc.ai_analysis.status === 'Warning' ? AlertTriangle : CheckCircle;
              return (
                <div key={i} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 11,
                  padding: '11px 13px', borderRadius: 9,
                  border: `1px solid ${C.border}`,
                  borderLeft: `3px solid ${sc}`,
                  marginBottom: 7,
                }}>
                  <div style={{ width: 7, height: 7, borderRadius: '50%', background: sc, flexShrink: 0, marginTop: 5 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <Icon size={14} color={sc} />
                      <span style={{ fontWeight: 700, fontSize: 12.5, color: sc }}>{doc.ai_analysis.status}</span>
                      <span style={{ fontSize: 12, color: C.text2 }}>— {doc.ai_analysis.soiling_level.toFixed(1)}%</span>
                    </div>
                    <div style={{ fontSize: 10.5, color: C.text3, marginTop: 1 }}>
                      {fmtDateTime(doc.timestamp)} · {doc.device_id}
                    </div>
                  </div>
                  <button
                    onClick={handleAddIntervention}
                    style={{
                      padding: '4px 8px',
                      borderRadius: 4,
                      border: 'none',
                      background: C.surface2,
                      color: C.text2,
                      fontSize: 10,
                      cursor: 'pointer',
                    }}
                  >
                    Planifier
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* ===== COLONNE DROITE : ANALYSE RAPIDE D'IMAGE ===== */}
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 20, boxShadow: '0 1px 3px rgba(13,82,52,.06)' }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green }} />
            <Camera size={14} /> ANALYSE IMAGE RAPIDE
          </div>
          <label style={{
            display: 'block', border: `2px dashed ${C.border}`, borderRadius: 11,
            padding: '22px 14px', textAlign: 'center', cursor: 'pointer',
            background: C.surface2, color: C.text3, transition: 'var(--tr)',
          }}
          onMouseEnter={e => { const el = e.currentTarget as HTMLLabelElement; el.style.borderColor = C.green; el.style.background = C.greenL; }}
          onMouseLeave={e => { const el = e.currentTarget as HTMLLabelElement; el.style.borderColor = C.border; el.style.background = C.surface2; }}
          >
            <input type="file" accept=".jpg,.jpeg,.png" style={{ display: 'none' }}
              onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} />
            {loading ? (
              <span style={{ fontSize: 13, color: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <Loader size={16} className="spin" /> Analyse IA en cours…
              </span>
            ) : (
              <>
                <Upload size={32} style={{ marginBottom: 8, opacity: 0.7 }} />
                <div style={{ fontSize: 12.5, fontWeight: 500 }}>Glisser une image ici</div>
                <div style={{ fontSize: 10.5, marginTop: 2 }}>JPG / PNG · Analyse immédiate</div>
              </>
            )}
          </label>
          {result && (
            <div style={{ background: C.surface2, borderRadius: 9, padding: 11, marginTop: 9 }}>
              <div style={{ height: 3, background: statusColor(result.status), borderRadius: 2, marginBottom: 8 }} />
              {result.image_b64 && (
                <img src={`data:image/jpeg;base64,${result.image_b64}`}
                  alt="résultat" style={{ width: '100%', borderRadius: 7, maxHeight: 130, objectFit: 'cover', marginBottom: 8 }} />
              )}
              <span style={{ fontFamily: 'Sora', fontSize: 22, fontWeight: 800, color: statusColor(result.status) }}>
                {result.soiling_level?.toFixed(1)}%
              </span>
              <span style={{ fontSize: 13, color: C.text2, marginLeft: 6 }}>— {result.status}</span>
              <div style={{ fontSize: 11, color: C.text3, marginTop: 2 }}>
                Confiance : {result.confidence?.toFixed(1)}%
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ===== TABLEAU DES INTERVENTIONS ===== */}
      <div style={{ 
        marginTop: 20,
        background: C.surface, 
        border: `1px solid ${C.border}`, 
        borderRadius: 14, 
        padding: 20,
        boxShadow: '0 1px 3px rgba(13,82,52,.06)'
      }}>
        {/* En-tête du tableau avec filtres */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 9.5, fontWeight: 700, color: C.text3, letterSpacing: 1, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.purple }} />
            <FileText size={14} /> HISTORIQUE DES INTERVENTIONS
            {loadingInterventions && <Loader size={14} className="spin" />}
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            {/* Filtre par statut */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              style={{
                padding: '4px 8px',
                borderRadius: 6,
                border: `1px solid ${C.border}`,
                background: C.surface2,
                color: C.text,
                fontSize: 11,
              }}
            >
              <option value="all">Tous les statuts</option>
              <option value="planned">Planifiées</option>
              <option value="in_progress">En cours</option>
              <option value="completed">Terminées</option>
              <option value="cancelled">Annulées</option>
            </select>

         {/* Bouton d'export */}
<button
  onClick={() => {
    if (filteredInterventions.length === 0) {
      alert('Aucune donnée à exporter');
      return;
    }
    exportToPDF(filteredInterventions, 'Rapport des interventions');
  }}
  style={{
    padding: '4px 12px',
    borderRadius: 6,
    border: `1px solid ${C.border}`,
    background: 'transparent',
    color: C.text2,
    fontSize: 11,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: 4,
  }}
>
  <Download size={12} />
  Export PDF
</button>
          </div>
        </div>

        {/* Tableau responsive */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
            <thead>
              <tr>
                {['Date', 'Type', 'Dispositif', 'Technicien', 'Coût', 'Statut', 'Actions'].map(h => (
                  <th key={h} style={{
                    padding: '9px 13px',
                    fontSize: 10,
                    fontWeight: 700,
                    color: C.text3,
                    textTransform: 'uppercase',
                    letterSpacing: .7,
                    borderBottom: `1px solid ${C.border}`,
                    textAlign: 'left',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredInterventions.length === 0 ? (
                <tr><td colSpan={8} style={{ padding: '28px', textAlign: 'center', color: C.text3 }}>
                  {loadingInterventions ? 'Chargement...' : 'Aucune intervention'}
                </td></tr>
              ) : (
                filteredInterventions.map((inv, i) => {
                  // Déterminer la couleur du statut
                  const statusColor = {
                    planned: C.amber,
                    in_progress: C.blue,
                    completed: C.green,
                    cancelled: C.red
                  }[inv.status];
                  
                  // Icône selon le type
                  const typeIcon = {
                    cleaning: <Droplets size={12} />,
                    repair: <Wrench size={12} />,
                    inspection: <Eye size={12} />,
                    other: <Activity size={12} />
                  }[inv.type];

                  return (
                    <tr key={inv.id} style={{ background: i % 2 === 0 ? C.surface2 : C.surface }}>
                      <td style={{ padding: '9px 13px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          <CalendarIcon size={12} />
                          {new Date(inv.date).toLocaleDateString('fr-FR')}
                        </div>
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          {typeIcon}
                          {inv.type === 'cleaning' && 'Nettoyage'}
                          {inv.type === 'repair' && 'Réparation'}
                          {inv.type === 'inspection' && 'Inspection'}
                          {inv.type === 'other' && 'Autre'}
                        </div>
                      </td>
                      <td style={{ padding: '9px 13px', fontFamily: 'monospace' }}>{inv.device_id}</td>
                      <td style={{ padding: '9px 13px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          <User size={12} />
                          {inv.technician}
                        </div>
                      </td>
                    {/*  <td style={{ padding: '9px 13px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ color: C.red }}>{inv.before_level}%</span>
                          <TrendingDown size={12} color={C.text3} />
                          <span style={{ color: C.green }}>{inv.after_level}%</span>
                        </div>
                      </td>*/}
                      <td style={{ padding: '9px 13px' }}>{inv.cost} DT</td>
                      <td style={{ padding: '9px 13px' }}>
                        <span style={{
                          padding: '3px 8px',
                          borderRadius: 99,
                          fontSize: 10,
                          fontWeight: 600,
                          background: `${statusColor}18`,
                          color: statusColor,
                        }}>
                          {inv.status === 'planned' && 'Planifiée'}
                          {inv.status === 'in_progress' && 'En cours'}
                          {inv.status === 'completed' && 'Terminée'}
                          {inv.status === 'cancelled' && 'Annulée'}
                        </span>
                      </td>
                      <td style={{ padding: '9px 13px' }}>
                        <div style={{ display: 'flex', gap: 4 }}>
                          <button
                            onClick={() => handleEditIntervention(inv)}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.blue }}
                          >
                            <Edit size={14} />
                          </button>
                          <button
                            onClick={() => handleDeleteIntervention(inv.id)}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.red }}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Résumé des coûts */}
        <div style={{
          marginTop: 16,
          padding: 12,
          background: C.surface2,
          borderRadius: 8,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <span style={{ fontSize: 11, color: C.text2 }}>Coût total des interventions terminées</span>
          <span style={{ fontSize: 15, fontWeight: 700, color: C.green }}>{totalCost.toFixed(2)} DT</span>
        </div>
      </div>

      {/* ===== MODAL D'AJOUT/ÉDITION D'INTERVENTION ===== */}
      {showAddModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            background: C.surface,
            borderRadius: 14,
            padding: 24,
            width: 500,
            maxWidth: '90%',
            maxHeight: '90vh',
            overflowY: 'auto',
          }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 20 }}>
              {selectedIntervention ? 'Modifier' : 'Nouvelle'} intervention
            </h2>
            
            {/* Formulaire */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Date */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Date</label>
                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>

              {/* Type */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Type</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleInputChange}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                >
                  <option value="cleaning">Nettoyage</option>
                  <option value="repair">Réparation</option>
                  <option value="inspection">Inspection</option>
                  <option value="other">Autre</option>
                </select>
              </div>

              {/* Dispositif */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Dispositif</label>
                <input
                  type="text"
                  name="device_id"
                  value={formData.device_id}
                  onChange={handleInputChange}
                  placeholder="ESP32_ZONE_A1"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>

              {/* Technicien */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Technicien</label>
                <input
                  type="text"
                  name="technician"
                  value={formData.technician}
                  onChange={handleInputChange}
                  placeholder="Nom du technicien"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>

              {/* Coût */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Coût (DT)</label>
                <input
                  type="number"
                  name="cost"
                  value={formData.cost}
                  onChange={handleInputChange}
                  min={0}
                  step={1}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                />
              </div>

              {/* Niveaux avant/après 
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Avant (%)</label>
                  <input
                    type="number"
                    name="before_level"
                    value={formData.before_level}
                    onChange={handleInputChange}
                    min={0}
                    max={100}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                    }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Après (%)</label>
                  <input
                    type="number"
                    name="after_level"
                    value={formData.after_level}
                    onChange={handleInputChange}
                    min={0}
                    max={100}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: 6,
                      border: `1px solid ${C.border}`,
                      background: C.surface2,
                      color: C.text,
                    }}
                  />
                </div>
              </div>  */}

              {/* Statut */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Statut</label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                  }}
                >
                  <option value="planned">Planifiée</option>
                  <option value="in_progress">En cours</option>
                  <option value="completed">Terminée</option>
                  <option value="cancelled">Annulée</option>
                </select>
              </div>

              {/* Notes */}
              <div>
                <label style={{ fontSize: 12, color: C.text3, display: 'block', marginBottom: 4 }}>Notes</label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  rows={3}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 6,
                    border: `1px solid ${C.border}`,
                    background: C.surface2,
                    color: C.text,
                    resize: 'vertical',
                  }}
                />
              </div>
            </div>

            {/* Boutons du modal */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 20 }}>
              <button
                onClick={() => setShowAddModal(false)}
                style={{
                  padding: '10px 16px',
                  borderRadius: 6,
                  border: `1px solid ${C.border}`,
                  background: 'transparent',
                  color: C.text2,
                  fontSize: 13,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                <X size={14} />
                Annuler
              </button>
              <button
                onClick={handleSaveIntervention}
                disabled={loading}
                style={{
                  padding: '10px 16px',
                  borderRadius: 6,
                  border: 'none',
                  background: loading ? C.surface2 : C.green,
                  color: loading ? C.text3 : 'white',
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: loading ? 'wait' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                {loading ? <Loader size={14} className="spin" /> : <Save size={14} />}
                {loading ? 'Sauvegarde...' : 'Sauvegarder'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}